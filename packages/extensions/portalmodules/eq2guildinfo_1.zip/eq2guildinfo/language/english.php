<?php
 /*
 * Project:		EQdkp-Plus
 * License:		Creative Commons - Attribution-Noncommercial-Share Alike 3.0 Unported
 * Link:		http://creativecommons.org/licenses/by-nc-sa/3.0/
 * -----------------------------------------------------------------------
 * Began:		2008
 * Date:		$Date: 2013-01-04 23:03:33 +0100 (Fri, 04 Jan 2013) $
 * -----------------------------------------------------------------------
 * @author		$Author: hoofy_leon $
 * @copyright	2006-2011 EQdkp-Plus Developer Team
 * @link		http://eqdkp-plus.com
 * @package		eqdkp-plus
 * @version		$Rev: 12732 $
 * 
 * $Id: english.php 12732 2013-01-04 22:03:33Z hoofy_leon $
 */

if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

$lang = array();
?>