<?php
/*	Project:			EQdkp-Plus
 *	Package:			Eternal Palace Module - Portal
 *	CreatorsLink:		https://www.therisingphoenix.eu
 *	Usagelink:			https://www.therisingphoenix.eu
 *
 *	Copyright (C) 2019 Quinteras	
 *
 */

if ( !defined('EQDKP_INC') ){
	header('HTTP/1.0 404 Not Found');exit;
}

class eternalpalaceprogress_portal extends portal_generic {

	protected static $path		= 'eternalpalaceprogress';
	protected static $data		= array(
		'name'			=> 'WoW Eternal Palace Progress',
		'version'		=> '1.0.0',
		'author'		=> 'Quinteras',
		'icon'			=> 'fa-code',
		'contact'		=> 'aexis@outlook.de',
		'description'	=> 'Shows the actual progress of the Eternal Palace Raid',
		'multiple'		=> false,
		'lang_prefix'	=> 'eternalpalaceprogress_'
	);
	
	protected static $positions = array( 'left1', 'left2', 'right');
	public function get_settings($state){
		$settings	= array(
			'boss1'	=> array(
				'type'		=> 'dropdown',
				'class'		=> 'js_reload',
				'options'	=> array(
					'no'	=> $this->user->lang('eternalpalace_no'),
					'nhc'	=> $this->user->lang('eternalpalace_nhc'),
					'hc'	=> $this->user->lang('eternalpalace_hc'),
					'myth'	=> $this->user->lang('eternalpalace_myth'),
				),
			),
			'boss2'	=> array(
				'type'		=> 'dropdown',
				'class'		=> 'js_reload',
				'options'	=> array(
					'no'	=> $this->user->lang('eternalpalace_no'),
					'nhc'	=> $this->user->lang('eternalpalace_nhc'),
					'hc'	=> $this->user->lang('eternalpalace_hc'),
					'myth'	=> $this->user->lang('eternalpalace_myth'),
				),
			),	
			'boss3'	=> array(
				'type'		=> 'dropdown',
				'class'		=> 'js_reload',
				'options'	=> array(
					'no'	=> $this->user->lang('eternalpalace_no'),
					'nhc'	=> $this->user->lang('eternalpalace_nhc'),
					'hc'	=> $this->user->lang('eternalpalace_hc'),
					'myth'	=> $this->user->lang('eternalpalace_myth'),
				),
			),
			'boss4'	=> array(
				'type'		=> 'dropdown',
				'class'		=> 'js_reload',
				'options'	=> array(
					'no'	=> $this->user->lang('eternalpalace_no'),
					'nhc'	=> $this->user->lang('eternalpalace_nhc'),
					'hc'	=> $this->user->lang('eternalpalace_hc'),
					'myth'	=> $this->user->lang('eternalpalace_myth'),
				),
			),
			'boss5'	=> array(
				'type'		=> 'dropdown',
				'class'		=> 'js_reload',
				'options'	=> array(
					'no'	=> $this->user->lang('eternalpalace_no'),
					'nhc'	=> $this->user->lang('eternalpalace_nhc'),
					'hc'	=> $this->user->lang('eternalpalace_hc'),
					'myth'	=> $this->user->lang('eternalpalace_myth'),
				),
			),'boss6'	=> array(
				'type'		=> 'dropdown',
				'class'		=> 'js_reload',
				'options'	=> array(
					'no'	=> $this->user->lang('eternalpalace_no'),
					'nhc'	=> $this->user->lang('eternalpalace_nhc'),
					'hc'	=> $this->user->lang('eternalpalace_hc'),
					'myth'	=> $this->user->lang('eternalpalace_myth'),
				),
			),
			'boss7'	=> array(
				'type'		=> 'dropdown',
				'class'		=> 'js_reload',
				'options'	=> array(
					'no'	=> $this->user->lang('eternalpalace_no'),
					'nhc'	=> $this->user->lang('eternalpalace_nhc'),
					'hc'	=> $this->user->lang('eternalpalace_hc'),
					'myth'	=> $this->user->lang('eternalpalace_myth'),
				),
			),
			'boss8'	=> array(
				'type'		=> 'dropdown',
				'class'		=> 'js_reload',
				'options'	=> array(
					'no'	=> $this->user->lang('eternalpalace_no'),
					'nhc'	=> $this->user->lang('eternalpalace_nhc'),
					'hc'	=> $this->user->lang('eternalpalace_hc'),
					'myth'	=> $this->user->lang('eternalpalace_myth'),
				),
			),			);
		
		return $settings;
	}
	protected static $install	= array(
		'autoenable'		=> '0',
		'defaultposition'	=> 'left',
		'defaultnumber'		=> '7',
	);
	
	protected static $apiLevel = 20;

	public function output() {
		$Imagepath=$this->server_path."portal/eternalpalaceprogress/media/images/";
		$arrSettingsArray=array();
		$out="<table style='width:240px;background:url(".$Imagepath."eternalpalace.jpg);background-size:cover;'>";
		$actualBoss=1;		
		while($this->config('boss'.$actualBoss)){
			$arrSettingsArray .= $this->config('boss'.$actualBoss);
			if($this->config('boss'.$actualBoss) == "no"){$Down="<font color='red'>".$this->user->lang('eternalpalace_no')."</font>";}
			if($this->config('boss'.$actualBoss) == "nhc"){$Down="<font color='lime'>".$this->user->lang('eternalpalace_nhc')."</font>";}
			if($this->config('boss'.$actualBoss) == "hc"){$Down="<font color='violet'>".$this->user->lang('eternalpalace_hc')."</font>";}
			if($this->config('boss'.$actualBoss) == "myth"){$Down="<font color='aqua'>".$this->user->lang('eternalpalace_myth')."</font>";}
			$out.="<tr style='border-bottom: 1px solid white;'><td style='text-shadow:1px 1px 1px black;'><font color='white'>".$this->user->lang("eternalpalaceprogress_f_boss".$actualBoss)."</font></td><td>".$Down."</td></tr>";
			$actualBoss++;
		}		
		$out.="</table>";
		return $out;
	}
}
?>
