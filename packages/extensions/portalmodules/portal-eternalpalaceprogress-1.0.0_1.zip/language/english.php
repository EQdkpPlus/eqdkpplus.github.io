<?php
/*	Project:			EQdkp-Plus
 *	Package:			Eternal Palace Progress Module - Portal
 *	CreatorsLink:		https://www.therisingphoenix.eu
 *	Usagelink:			https://www.therisingphoenix.eu
 *
 *	Copyright (C) 2019 Quinteras	
 *
 */

if ( !defined('EQDKP_INC') ){
	header('HTTP/1.0 404 Not Found');exit;
}

$lang['eternalpalaceprogress']			= 'Eternal Palace Progress';
$lang['eternalpalaceprogress_name']		= 'Eternal Palace Progress';
$lang['eternalpalaceprogress_desc']		= 'Set up your progress here.';
$lang['eternalpalaceprogress_f_boss1']	= 'Abyssal Commander Sivara';
$lang['eternalpalaceprogress_f_boss2']	= 'Rage of Azshara';
$lang['eternalpalaceprogress_f_boss3']	= 'Underwater Monstrosity';
$lang['eternalpalaceprogress_f_boss4']	= 'Lady Precillia Ashvane';
$lang['eternalpalaceprogress_f_boss5']	= 'Orgozoa';
$lang['eternalpalaceprogress_f_boss6']	= 'The Queen\'s Court';
$lang['eternalpalaceprogress_f_boss7']	= 'Za\'qul, Herald of N\'Zoth';
$lang['eternalpalaceprogress_f_boss8']	= 'Queen Azshara';
$lang['eternalpalace_no']				= 'Open';
$lang['eternalpalace_nhc']				= 'Normal';
$lang['eternalpalace_hc']				= 'Heroic';
$lang['eternalpalace_myth']				= 'Mythic';
$lang['test']						= array('Open','Normal','Heroic','Mythic');
?>