<?php
/*	Project:			EQdkp-Plus
 *	Package:			Eternal Palace Progress Module - Portal
 *	CreatorsLink:		https://www.therisingphoenix.eu
 *	Usagelink:			https://www.therisingphoenix.eu
 *
 *	Copyright (C) 2019 Quinteras	
 *
 */

if ( !defined('EQDKP_INC') ){
	header('HTTP/1.0 404 Not Found');exit;
}

$lang['eternalpalaceprogress']			= 'Ewiger Palast Progress';
$lang['eternalpalaceprogress_name']		= 'Ewiger Palast Progress';
$lang['eternalpalaceprogress_desc']		= 'Stell hier deinen Progress ein.';
$lang['eternalpalaceprogress_f_boss1']	= 'Abyssalkommandantin Sivara';
$lang['eternalpalaceprogress_f_boss2']	= 'Schwarzwasserungetüm';
$lang['eternalpalaceprogress_f_boss3']	= 'Azsharas Glanz';
$lang['eternalpalaceprogress_f_boss4']	= 'Lady Aschenwind';
$lang['eternalpalaceprogress_f_boss5']	= 'Orgozoa';
$lang['eternalpalaceprogress_f_boss6']	= 'Der Hofstaat der Königin';
$lang['eternalpalaceprogress_f_boss7']	= 'Za\'qul, Herold von N\'Zoth';
$lang['eternalpalaceprogress_f_boss8']	= 'Königin Azshara';
$lang['eternalpalace_no']				= 'Offen';
$lang['eternalpalace_nhc']				= 'Normal';
$lang['eternalpalace_hc']				= 'Heroisch';
$lang['eternalpalace_myth']				= 'Mythisch';
$lang['test']						= array('Offen','Normal','Heroisch','Mythisch');
?>