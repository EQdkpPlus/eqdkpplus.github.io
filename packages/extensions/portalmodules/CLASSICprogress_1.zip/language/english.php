<?php
/*	Project:			EQdkp-Plus
 *	Package:			classic Progress Module - Portal
 *	CreatorsLink:		https://www.therisingphoenix.eu
 *	Usagelink:			https://www.therisingphoenix.eu
 *
 *	Copyright (C) 2019 Motrish/Quinteras​​​​	
 *
 */

if ( !defined('EQDKP_INC') ){
	header('HTTP/1.0 404 Not Found');exit;
}

$lang['classicprogress']				= 'Classic Progress';
$lang['classicprogress_name']			= 'Classic Progress';
$lang['classicprogress_desc']			= 'Insert your Raid Progress.';
$lang['classicprogress_f_boss1']		= 'Molten Core';
$lang['classicprogress_f_boss2']		= 'Onyxia&apos;s Lair';
$lang['classicprogress_f_boss3']		= 'Zul&apos;Gurub';
$lang['classicprogress_f_boss4']		= 'Ruins of Ahn&apos;Qiraj';
$lang['classicprogress_f_boss5']		= 'Tempel of Ahnapos;Qiraj ';
$lang['classicprogress_f_boss6']		= 'Naxxramas';
$lang['classic_0_10']					= '0/10';
$lang['classic_1_10']					= '1/10';
$lang['classic_2_10']					= '2/10';
$lang['classic_3_10']					= '3/10';
$lang['classic_4_10']					= '4/10';
$lang['classic_5_10']					= '5/10';
$lang['classic_6_10']					= '6/10';
$lang['classic_7_10']					= '7/10';
$lang['classic_8_10']					= '8/10';
$lang['classic_9_10']					= '9/10';
$lang['classic_10_10']					= 'CLEAR';
$lang['classic_0_7']					= '0/7';
$lang['classic_1_7']					= '0/7';
$lang['classic_2_7']					= '0/7';
$lang['classic_3_7']					= '0/7';
$lang['classic_4_7']					= '0/7';
$lang['classic_5_7']					= '0/7';
$lang['classic_6_7']					= '0/7';
$lang['classic_7_7']					= 'CLEAR';
$lang['classic_0_8']					= '0/8';
$lang['classic_1_8']					= '1/8';
$lang['classic_2_8']					= '2/8';
$lang['classic_3_8']					= '3/8';
$lang['classic_4_8']					= '4/8';
$lang['classic_5_8']					= '5/8';
$lang['classic_6_8']					= '6/8';
$lang['classic_7_8']					= '7/8';
$lang['classic_8_8']					= 'CLEAR';
$lang['classic_0_1']					= '0/1';
$lang['classic_1_1']					= 'CLEAR';
$lang['classic_0_15']					= '0/15';
$lang['classic_1_15']					= '1/15';
$lang['classic_2_15']					= '2/15';
$lang['classic_3_15']					= '3/15';
$lang['classic_4_15']					= '4/15';
$lang['classic_5_15']					= '5/15';
$lang['classic_6_15']					= '6/15';
$lang['classic_7_15']					= '7/15';
$lang['classic_8_15']					= '8/15';
$lang['classic_9_15']					= '9/15';
$lang['classic_10_15']					= '10/15';
$lang['classic_11_15']					= '11/15';
$lang['classic_12_15']					= '12/15';
$lang['classic_13_15']					= '13/15';
$lang['classic_14_15']					= '14/15';
$lang['classic_15_15']					= 'CLEAR';
?>