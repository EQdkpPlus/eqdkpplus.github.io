<?php
/*	Project:			EQdkp-Plus
 *	Package:			Ny'alotha Progress Module - Portal
 *	CreatorsLink:		https://www.therisingphoenix.eu
 *	Usagelink:			https://www.therisingphoenix.eu
 *
 *	Copyright (C) 2019 Quinteras	
 *
 */

if ( !defined('EQDKP_INC') ){
	header('HTTP/1.0 404 Not Found');exit;
}

$lang['nyalothaprogress']			= 'Ny\'alotha Progress';
$lang['nyalothaprogress_name']		= 'Ny\'alotha Progress';
$lang['nyalothaprogress_desc']		= 'Set up your progress here.';
$lang['nyalothaprogress_f_boss1']	= 'Wrathion';
$lang['nyalothaprogress_f_boss2']	= 'Maut';
$lang['nyalothaprogress_f_boss3']	= 'The Prophet Skitra';
$lang['nyalothaprogress_f_boss4']	= 'Dark Inquisitor Xanesh';
$lang['nyalothaprogress_f_boss5']	= 'The Hivemind';
$lang['nyalothaprogress_f_boss6']	= 'Shad\'har the Insatiable';
$lang['nyalothaprogress_f_boss7']	= 'Drest\'agath';
$lang['nyalothaprogress_f_boss8']	= 'Vexiona';
$lang['nyalothaprogress_f_boss9']	= 'Ra-den the Despoiled';
$lang['nyalothaprogress_f_boss10']	= 'Il\'gynoth, Corruption Reborn';
$lang['nyalothaprogress_f_boss11']	= 'Carapace of N\'Zoth';
$lang['nyalothaprogress_f_boss12']	= 'N\'Zoth the Corruptor';
$lang['nyalotha_no']				= 'Open';
$lang['nyalotha_nhc']				= 'Normal';
$lang['nyalotha_hc']				= 'Heroic';
$lang['nyalotha_myth']				= 'Mythic';
$lang['test']						= array('Open','Normal','Heroic','Mythic');
?>