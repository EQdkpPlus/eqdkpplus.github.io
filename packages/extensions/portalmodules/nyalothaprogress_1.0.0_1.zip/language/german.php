<?php
/*	Project:			EQdkp-Plus
 *	Package:			Eternal Palace Progress Module - Portal
 *	CreatorsLink:		https://www.therisingphoenix.eu
 *	Usagelink:			https://www.therisingphoenix.eu
 *
 *	Copyright (C) 2019 Quinteras	
 *
 */

if ( !defined('EQDKP_INC') ){
	header('HTTP/1.0 404 Not Found');exit;
}

$lang['nyalothaprogress']			= 'Ny\'alotha Progress';
$lang['nyalothaprogress_name']		= 'Ny\'alotha Progress';
$lang['nyalothaprogress_desc']		= 'Stell hier euren Fortschritt ein.';
$lang['nyalothaprogress_f_boss1']	= 'Furorion';
$lang['nyalothaprogress_f_boss2']	= 'Ma\'ut';
$lang['nyalothaprogress_f_boss3']	= 'Der Prophet Skitra';
$lang['nyalothaprogress_f_boss4']	= 'Dunkle Inquisitorin Xanesh';
$lang['nyalothaprogress_f_boss5']	= 'Das Schwarmbewusstsein';
$lang['nyalothaprogress_f_boss6']	= 'Shad\'har der Unersättliche';
$lang['nyalothaprogress_f_boss7']	= 'Drest\'agath';
$lang['nyalothaprogress_f_boss8']	= 'Vexiona';
$lang['nyalothaprogress_f_boss9']	= 'Ra-den der Entweihte';
$lang['nyalothaprogress_f_boss10']	= 'Il\'gynoth, Wiedergeborene Verderbnis';
$lang['nyalothaprogress_f_boss11']	= 'Panzer N\'Zoth';
$lang['nyalothaprogress_f_boss12']	= 'N\'Zoth der Verderber';
$lang['nyalotha_no']				= 'Open';
$lang['nyalotha_nhc']				= 'Normal';
$lang['nyalotha_hc']				= 'Heroic';
$lang['nyalotha_myth']				= 'Mythic';
$lang['test']						= array('Open','Normal','Heroic','Mythic');
?>