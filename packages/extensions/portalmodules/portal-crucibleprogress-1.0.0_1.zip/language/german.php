<?php
/*	Project:			EQdkp-Plus
 *	Package:			Tiegel der Stürme Progress Module - Portal
 *	CreatorsLink:		https://www.therisingphoenix.eu
 *	Usagelink:			https://www.therisingphoenix.eu
 *
 *	Copyright (C) 2019 Quinteras	
 *
 */

if ( !defined('EQDKP_INC') ){
	header('HTTP/1.0 404 Not Found');exit;
}

$lang['crucibleprogress']			= 'Tiegel der Stürme Fortschritt';
$lang['crucibleprogress_name']		= 'Tiegel der Stürme Progress';
$lang['crucibleprogress_desc']		= 'Stelle hier den aktuellen Raidfortschritt ein.';
$lang['crucibleprogress_f_boss1']	= 'Die rastlose Kabale';
$lang['crucibleprogress_f_boss2']	= 'Uu\'nat, Vorbote der Leere';
$lang['crucible_no']				= 'Offen';
$lang['crucible_nhc']				= 'Normal';
$lang['crucible_hc']				= 'Heroisch';
$lang['crucible_myth']				= 'Mythisch';
$lang['test']						= array('Open','Normal','Heroisch','Mythisch');
?>