<?php
/*	Project:			EQdkp-Plus
 *	Package:			Curcible of Storms Progress Module - Portal
 *	CreatorsLink:		https://www.therisingphoenix.eu
 *	Usagelink:			https://www.therisingphoenix.eu
 *
 *	Copyright (C) 2019 Quinteras	
 *
 */

if ( !defined('EQDKP_INC') ){
	header('HTTP/1.0 404 Not Found');exit;
}

$lang['crucibleprogress']			= 'Crucible of Storms Progress';
$lang['crucibleprogress_name']		= 'Crucible of Storms Progress';
$lang['crucibleprogress_desc']		= 'Set up your progress here.';
$lang['crucibleprogress_f_boss1']	= 'The Restless Cabal';
$lang['crucibleprogress_f_boss2']	= 'Uu\'nat, Harbinger of the Void';
$lang['crucible_no']				= 'Open';
$lang['crucible_nhc']				= 'Normal';
$lang['crucible_hc']				= 'Heroic';
$lang['crucible_myth']				= 'Mythic';
$lang['test']						= array('Open','Normal','Heroic','Mythic');
?>