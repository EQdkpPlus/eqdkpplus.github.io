<?php
/*	Project:			EQdkp-Plus
 *	Package:			Uldir Progress Module - Portal
 *	CreatorsLink:		https://www.domekologe.eu
 *	Usagelink:			https://www.wow-phoenix.eu
 *
 *	Copyright (C) 2018 Domekologe
 *
 */

if ( !defined('EQDKP_INC') ){
	header('HTTP/1.0 404 Not Found');exit;
}

class uldirprogress_portal extends portal_generic {

	protected static $path		= 'uldirprogress';
	protected static $data		= array(
		'name'			=> 'WoW Uldir Progress',
		'version'		=> '1.0.2',
		'author'		=> 'Domekologe',
		'icon'			=> 'fa-code',
		'contact'		=> 'community@domekologe.eu',
		'description'	=> 'Shows the actual progress of the Uldir Raid',
		'multiple'		=> false,
		'lang_prefix'	=> 'uldirprogress_'
	);
	
	protected static $positions = array( 'left1', 'left2', 'right');
	public function get_settings($state){
		$settings	= array(
			'boss1'	=> array(
				'type'		=> 'dropdown',
				'class'		=> 'js_reload',
				'options'	=> array(
					'no'	=> $this->user->lang('uldir_no'),
					'nhc'	=> $this->user->lang('uldir_nhc'),
					'hc'	=> $this->user->lang('uldir_hc'),
					'myth'	=> $this->user->lang('uldir_myth'),
				),
			),
			'boss2'	=> array(
				'type'		=> 'dropdown',
				'class'		=> 'js_reload',			
				'options'	=> array(
					'no'	=> $this->user->lang('uldir_no'),
					'nhc'	=> $this->user->lang('uldir_nhc'),
					'hc'	=> $this->user->lang('uldir_hc'),
					'myth'	=> $this->user->lang('uldir_myth'),
				),
			),
			'boss3'	=> array(
				'type'		=> 'dropdown',		
				'class'		=> 'js_reload',
				'options'	=> array(
					'no'	=> $this->user->lang('uldir_no'),
					'nhc'	=> $this->user->lang('uldir_nhc'),
					'hc'	=> $this->user->lang('uldir_hc'),
					'myth'	=> $this->user->lang('uldir_myth'),
				),
			),
			'boss4'	=> array(
				'type'		=> 'dropdown',	
				'class'		=> 'js_reload',			
				'options'	=> array(
					'no'	=> $this->user->lang('uldir_no'),
					'nhc'	=> $this->user->lang('uldir_nhc'),
					'hc'	=> $this->user->lang('uldir_hc'),
					'myth'	=> $this->user->lang('uldir_myth'),
				),
			),
			'boss5'	=> array(
				'type'		=> 'dropdown',	
				'class'		=> 'js_reload',			
				'options'	=> array(
					'no'	=> $this->user->lang('uldir_no'),
					'nhc'	=> $this->user->lang('uldir_nhc'),
					'hc'	=> $this->user->lang('uldir_hc'),
					'myth'	=> $this->user->lang('uldir_myth'),
				),
			),
			'boss6'	=> array(
				'type'		=> 'dropdown',	
				'class'		=> 'js_reload',			
				'options'	=> array(
					'no'	=> $this->user->lang('uldir_no'),
					'nhc'	=> $this->user->lang('uldir_nhc'),
					'hc'	=> $this->user->lang('uldir_hc'),
					'myth'	=> $this->user->lang('uldir_myth'),
				),
			),
			'boss7'	=> array(
				'type'		=> 'dropdown',	
				'class'		=> 'js_reload',			
				'options'	=> array(
					'no'	=> $this->user->lang('uldir_no'),
					'nhc'	=> $this->user->lang('uldir_nhc'),
					'hc'	=> $this->user->lang('uldir_hc'),
					'myth'	=> $this->user->lang('uldir_myth'),
				),
			),
			'boss8'	=> array(
				'type'		=> 'dropdown',	
				'class'		=> 'js_reload',			
				'options'	=> array(
					'no'	=> $this->user->lang('uldir_no'),
					'nhc'	=> $this->user->lang('uldir_nhc'),
					'hc'	=> $this->user->lang('uldir_hc'),
					'myth'	=> $this->user->lang('uldir_myth'),
				),
			),			
		);
		
		return $settings;
	}
	protected static $install	= array(
		'autoenable'		=> '0',
		'defaultposition'	=> 'left',
		'defaultnumber'		=> '7',
	);
	
	protected static $apiLevel = 20;

	public function output() {
		$Imagepath=$this->server_path."portal/uldirprogress/media/images/";
		$arrSettingsArray=array();
		$out="<table style='width:240px;background:url(".$Imagepath."uldir.jpg);background-size:cover;'>";
		$actualBoss=1;		
		while($this->config('boss'.$actualBoss)){
			$arrSettingsArray .= $this->config('boss'.$actualBoss);
			if($this->config('boss'.$actualBoss) == "no"){$Down="<font color='red'>".$this->user->lang('uldir_no')."</font>";}
			if($this->config('boss'.$actualBoss) == "nhc"){$Down="<font color='lime'>".$this->user->lang('uldir_nhc')."</font>";}
			if($this->config('boss'.$actualBoss) == "hc"){$Down="<font color='violet'>".$this->user->lang('uldir_hc')."</font>";}
			if($this->config('boss'.$actualBoss) == "myth"){$Down="<font color='aqua'>".$this->user->lang('uldir_myth')."</font>";}
			$out.="<tr style='border-bottom: 1px solid white;'><td style='text-shadow:1px 1px 1px black;'><font color='white'>".$this->user->lang("uldirprogress_f_boss".$actualBoss)."</font></td><td>".$Down."</td></tr>";
			$actualBoss++;
		}		
		$out.="</table>";
		return $out;
	}
}
?>
