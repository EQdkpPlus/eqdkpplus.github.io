<?php
/*	Project:			EQdkp-Plus
 *	Package:			Uldir Progress Module - Portal
 *	CreatorsLink:		https://www.domekologe.eu
 *	Usagelink:			https://www.wow-phoenix.eu
 *
 *	Copyright (C) 2018 Domekologe
 *
 */

if ( !defined('EQDKP_INC') ){
	header('HTTP/1.0 404 Not Found');exit;
}

$lang['uldirprogress']				= 'Uldir Aktueller Fortschritt';
$lang['uldirprogress_name']			= 'Uldir Progress';
$lang['uldirprogress_desc']			= 'Stelle hier den aktuellen Raidfortschritt ein.';
$lang['uldirprogress_f_boss1']		= 'Taloc der Korrupte';
$lang['uldirprogress_f_boss2']		= 'MUTTER';
$lang['uldirprogress_f_boss3']		= 'Fauliger Verschlinger';
$lang['uldirprogress_f_boss4']		= 'Zek\'voz';
$lang['uldirprogress_f_boss5']		= 'Vectis';
$lang['uldirprogress_f_boss6']		= 'Zul';
$lang['uldirprogress_f_boss7']		= 'Mythrax der Auflöser';
$lang['uldirprogress_f_boss8']		= 'G\'huun';
$lang['uldir_no']					= 'Offen';
$lang['uldir_nhc']					= 'Normal';
$lang['uldir_hc']					= 'Heroisch';
$lang['uldir_myth']					= 'Mythisch';
$lang['test']						= array('Open','Normal','Heroic','Mythic');
?>