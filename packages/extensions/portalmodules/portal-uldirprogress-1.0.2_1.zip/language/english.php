<?php
/*	Project:			EQdkp-Plus
 *	Package:			Uldir Progress Module - Portal
 *	CreatorsLink:		https://www.domekologe.eu
 *	Usagelink:			https://www.wow-phoenix.eu
 *
 *	Copyright (C) 2018 Domekologe
 *
 */

if ( !defined('EQDKP_INC') ){
	header('HTTP/1.0 404 Not Found');exit;
}

$lang['uldirprogress']				= 'Uldir actual progress';
$lang['uldirprogress_name']			= 'Uldir progress';
$lang['uldirprogress_desc']			= 'Take here the right value of your progress for each boss.';
$lang['uldirprogress_f_boss1']		= 'Taloc the Corrupted';
$lang['uldirprogress_f_boss2']		= 'MOTHER';
$lang['uldirprogress_f_boss3']		= 'Fetid Devourer';
$lang['uldirprogress_f_boss4']		= 'Zek\'voz';
$lang['uldirprogress_f_boss5']		= 'Vectis';
$lang['uldirprogress_f_boss6']		= 'Zul, Reborn';
$lang['uldirprogress_f_boss7']		= 'Mythrax the Unraveler';
$lang['uldirprogress_f_boss8']		= 'G\'huun';
$lang['uldir_no']					= 'open';
$lang['uldir_nhc']					= 'normal';
$lang['uldir_hc']					= 'heroic';
$lang['uldir_myth']					= 'mythic';
$lang['test']						= array('Open','Normal','Heroic','Mythic');
?>