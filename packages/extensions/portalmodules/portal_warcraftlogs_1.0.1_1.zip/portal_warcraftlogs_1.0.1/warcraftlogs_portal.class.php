<?php
/*	Project:			EQdkp-Plus
 *	Package:			Warcraftlogs.com - Last Logs - Portal
 *	CreatorsLink:		https://www.useemetrollin.de
 *	Usagelink:			https://www.dieaufgehendesonne.eu
 *
 *	Copyright (C) 2018 Domekologe/USeeMeTrollin Community
 *
 */

if ( !defined('EQDKP_INC') ){
	header('HTTP/1.0 404 Not Found');exit;
}

class warcraftlogs_portal extends portal_generic {

	protected static $path		= 'warcraftlogs';
	protected static $data		= array(
		'name'			=> 'Warcraftlogs.com Last Logs',
		'version'		=> '1.0.1',
		'author'		=> 'Domekologe',
		'icon'			=> 'fa-code',
		'contact'		=> 'domekologe@useemetrollin.de',
		'description'	=> 'Shows the last Logs from Warcraftlogs.com',
		'multiple'		=> false,
		'lang_prefix'	=> 'warcraftlogs_'
	);
	
	protected static $positions = array( 'left1', 'left2', 'right');
	protected $settings = array(
		'region'	=> array(
			'type'		=> 'text',
			'size'		=> '2',
		),
		'realm'	=> array(
			'type'		=> 'text',
			'size'		=> '20',
		),
		'guild'	=> array(
			'type'		=> 'text',
			'size'		=> '30',
		),
		'api_key'	=> array(
			'type'		=> 'text',
			'size'		=> '40',
		),
		'count'	=> array(
			'type'		=> 'int',
			'size'		=> '2',
		),			
	);
	protected static $install	= array(
		'autoenable'		=> '0',
		'defaultposition'	=> 'left',
		'defaultnumber'		=> '7',
	);
	
	protected static $apiLevel = 20;

	public function output() {
		//Start Caching check
		$Logtable=$this->pdc->get('portal.warcraftlogs_com');
		if($Logtable == null){ //When nothing is in cache or the cache is expired, cache the actual Logs
			$Reports=json_decode(file_get_contents("https://www.warcraftlogs.com:443/v1/reports/guild/".urlencode($this->config('guild'))."/".$this->config('realm')."/".$this->config('region')."?api_key=".$this->config('api_key')),true);
			$this->pdc->put('portal.warcraftlogs_com',$Reports,60*10); // Caches the Array for 10 minutes
		}
		
		$Counter=0;
		$out="<table class='table fullwidth colorswitch'>";
		foreach(array_reverse($this->pdc->get('portal.warcraftlogs_com')) as $Report){
			if($Counter < $this->config('count')){
				$out.="<tr><td><a href='https://www.warcraftlogs.com/reports/".sanitize($Report['id'])."' target='_blank'>".sanitize($Report['title'])."</a></td></tr>";
			}
			$Counter++;
		}
		$out.="</table>";
		return $out;
	}
}
?>
