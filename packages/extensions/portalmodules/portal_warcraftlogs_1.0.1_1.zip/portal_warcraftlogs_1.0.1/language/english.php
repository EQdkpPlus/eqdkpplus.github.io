<?php
/*	Project:			EQdkp-Plus
 *	Package:			Warcraftlogs.com - Last Logs - Portal
 *	CreatorsLink:		https://www.useemetrollin.de
 *	Usagelink:			https://www.dieaufgehendesonne.eu
 *
 *	Copyright (C) 2018 Domekologe/USeeMeTrollin Community
 *
 */

if ( !defined('EQDKP_INC') ){
	header('HTTP/1.0 404 Not Found');exit;
}

$lang['warcraftlogs']				= 'Last Raidlogs';
$lang['warcraftlogs_name']			= 'Warcraftlogs.com logs';
$lang['warcraftlogs_desc']			= 'Show you last logs from Warcraftlogs.com.';
$lang['warcraftlogs_f_api_key']		= 'API Key from Warcraftlogs.com';
$lang['warcraftlogs_f_region']		= 'Region like EU';
$lang['warcraftlogs_f_realm']		= 'Enter here your realm';
$lang['warcraftlogs_f_guild']		= 'Name of your guild';
$lang['warcraftlogs_f_count']		= 'Last logs to see';
?>