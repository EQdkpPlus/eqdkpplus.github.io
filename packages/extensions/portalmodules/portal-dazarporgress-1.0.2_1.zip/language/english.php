<?php
/*	Project:			EQdkp-Plus
 *	Package:			Dazaralor Progress Module - Portal
 *	CreatorsLink:		https://www.therisingphoenix.eu
 *	Usagelink:			https://www.therisingphoenix.eu
 *
 *	Copyright (C) 2018 Quinteras	
 *
 */

if ( !defined('EQDKP_INC') ){
	header('HTTP/1.0 404 Not Found');exit;
}

$lang['dazarprogress']				= 'Dazar\'alor progress';
$lang['dazarprogress_name']			= 'Dazar\'alor progress';
$lang['dazarprogress_desc']			= 'Take here the right value of your progress for each boss.';
$lang['dazarprogress_f_boss1']		= 'Champions of the Light';
$lang['dazarprogress_f_boss2']		= 'Jadefire Masters';
$lang['dazarprogress_f_boss3']		= 'Grong the Revenant';
$lang['dazarprogress_f_boss4']		= 'Opulence';
$lang['dazarprogress_f_boss5']		= 'Conclave of the Chosen';
$lang['dazarprogress_f_boss6']		= 'King Rastakhan';
$lang['dazarprogress_f_boss7']		= 'High Tinker Mekkatorque';
$lang['dazarprogress_f_boss8']		= 'Stormwall Blockade';
$lang['dazarprogress_f_boss9']		= 'Lady Jaina Proudmoore';
$lang['dazar_no']					= 'open';
$lang['dazar_nhc']					= 'normal';
$lang['dazar_hc']					= 'heroic';
$lang['dazar_myth']					= 'mythic';
$lang['test']						= array('Open','Normal','Heroic','Mythic');
?>