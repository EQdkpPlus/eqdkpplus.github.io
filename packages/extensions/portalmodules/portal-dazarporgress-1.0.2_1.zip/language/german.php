<?php
/*	Project:			EQdkp-Plus
 *	Package:			Dazaralor Progress Module - Portal
 *	CreatorsLink:		https://www.therisingphoenix.eu
 *	Usagelink:			https://www.therisingphoenix.eu
 *
 *	Copyright (C) 2018 Quinteras	
 *
 */

if ( !defined('EQDKP_INC') ){
	header('HTTP/1.0 404 Not Found');exit;
}

$lang['dazarprogress']				= 'Dazar\'alor Fortschritt';
$lang['dazarprogress_name']			= 'Dazar\'alor Progress';
$lang['dazarprogress_desc']			= 'Stelle hier den aktuellen Raidfortschritt ein.';
$lang['dazarprogress_f_boss1']		= 'Champions des Lichts';
$lang['dazarprogress_f_boss2']		= 'Jadefeuermeister';
$lang['dazarprogress_f_boss3']		= 'Grong';
$lang['dazarprogress_f_boss4']		= 'Opulenz';
$lang['dazarprogress_f_boss5']		= 'Konklave der Auserwählten';
$lang['dazarprogress_f_boss6']		= 'König Rastakhan';
$lang['dazarprogress_f_boss7']		= 'Hochtüftler Mekkadrill';
$lang['dazarprogress_f_boss8']		= 'Sturmwallblockade';
$lang['dazarprogress_f_boss9']		= 'Jaina Prachtmeer';
$lang['dazar_no']					= 'Offen';
$lang['dazar_nhc']					= 'Normal';
$lang['dazar_hc']					= 'Heroisch';
$lang['dazar_myth']					= 'Mythisch';
$lang['test']						= array('Open','Normal','Heroisch','Mythisch');
?>