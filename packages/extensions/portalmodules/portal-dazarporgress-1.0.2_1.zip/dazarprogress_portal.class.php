<?php
/*	Project:			EQdkp-Plus
 *	Package:			Dazaralor Progress Module - Portal
 *	CreatorsLink:		https://www.therisingphoenix.eu
 *	Usagelink:			https://www.therisingphoenix.eu
 *
 *	Copyright (C) 2019 Quinteras	
 *
 */

if ( !defined('EQDKP_INC') ){
	header('HTTP/1.0 404 Not Found');exit;
}

class dazarprogress_portal extends portal_generic {

	protected static $path		= 'dazarprogress';
	protected static $data		= array(
		'name'			=> 'WoW Dazaralor Progress',
		'version'		=> '1.0.2',
		'author'		=> 'Quinteras',
		'icon'			=> 'fa-code',
		'contact'		=> 'aexis@outlook.de',
		'description'	=> 'Shows the actual progress of the Dazar\'alor Raid',
		'multiple'		=> false,
		'lang_prefix'	=> 'dazarprogress_'
	);
	
	protected static $positions = array( 'left1', 'left2', 'right');
	public function get_settings($state){
		$settings	= array(
			'boss1'	=> array(
				'type'		=> 'dropdown',
				'class'		=> 'js_reload',
				'options'	=> array(
					'no'	=> $this->user->lang('dazar_no'),
					'nhc'	=> $this->user->lang('dazar_nhc'),
					'hc'	=> $this->user->lang('dazar_hc'),
					'myth'	=> $this->user->lang('dazar_myth'),
				),
			),
			'boss2'	=> array(
				'type'		=> 'dropdown',
				'class'		=> 'js_reload',			
				'options'	=> array(
					'no'	=> $this->user->lang('dazar_no'),
					'nhc'	=> $this->user->lang('dazar_nhc'),
					'hc'	=> $this->user->lang('dazar_hc'),
					'myth'	=> $this->user->lang('dazar_myth'),				),
			),
			'boss3'	=> array(
				'type'		=> 'dropdown',		
				'class'		=> 'js_reload',
				'options'	=> array(
					'no'	=> $this->user->lang('dazar_no'),
					'nhc'	=> $this->user->lang('dazar_nhc'),
					'hc'	=> $this->user->lang('dazar_hc'),
					'myth'	=> $this->user->lang('dazar_myth'),				),
			),
			'boss4'	=> array(
				'type'		=> 'dropdown',	
				'class'		=> 'js_reload',			
				'options'	=> array(
					'no'	=> $this->user->lang('dazar_no'),
					'nhc'	=> $this->user->lang('dazar_nhc'),
					'hc'	=> $this->user->lang('dazar_hc'),
					'myth'	=> $this->user->lang('dazar_myth'),
				),
			),
			'boss5'	=> array(
				'type'		=> 'dropdown',	
				'class'		=> 'js_reload',			
				'options'	=> array(
					'no'	=> $this->user->lang('dazar_no'),
					'nhc'	=> $this->user->lang('dazar_nhc'),
					'hc'	=> $this->user->lang('dazar_hc'),
					'myth'	=> $this->user->lang('dazar_myth'),
				),
			),
			'boss6'	=> array(
				'type'		=> 'dropdown',	
				'class'		=> 'js_reload',			
				'options'	=> array(
					'no'	=> $this->user->lang('dazar_no'),
					'nhc'	=> $this->user->lang('dazar_nhc'),
					'hc'	=> $this->user->lang('dazar_hc'),
					'myth'	=> $this->user->lang('dazar_myth'),
				),
			),
			'boss7'	=> array(
				'type'		=> 'dropdown',	
				'class'		=> 'js_reload',			
				'options'	=> array(
					'no'	=> $this->user->lang('dazar_no'),
					'nhc'	=> $this->user->lang('dazar_nhc'),
					'hc'	=> $this->user->lang('dazar_hc'),
					'myth'	=> $this->user->lang('dazar_myth'),
				),
			),
			'boss8'	=> array(
				'type'		=> 'dropdown',	
				'class'		=> 'js_reload',			
				'options'	=> array(
					'no'	=> $this->user->lang('dazar_no'),
					'nhc'	=> $this->user->lang('dazar_nhc'),
					'hc'	=> $this->user->lang('dazar_hc'),
					'myth'	=> $this->user->lang('dazar_myth'),
				),			
			),
			'boss9'	=> array(
				'type'		=> 'dropdown',	
				'class'		=> 'js_reload',			
				'options'	=> array(
					'no'	=> $this->user->lang('dazar_no'),
					'nhc'	=> $this->user->lang('dazar_nhc'),
					'hc'	=> $this->user->lang('dazar_hc'),
					'myth'	=> $this->user->lang('dazar_myth'),
				),
			),					);
		
		return $settings;
	}
	protected static $install	= array(
		'autoenable'		=> '0',
		'defaultposition'	=> 'left',
		'defaultnumber'		=> '7',
	);
	
	protected static $apiLevel = 20;

	public function output() {
		$Imagepath=$this->server_path."portal/dazarprogress/media/images/";
		$arrSettingsArray=array();
		$out="<table style='width:240px;background:url(".$Imagepath."dazar.jpg);background-size:cover;'>";
		$actualBoss=1;		
		while($this->config('boss'.$actualBoss)){
			$arrSettingsArray .= $this->config('boss'.$actualBoss);
			if($this->config('boss'.$actualBoss) == "no"){$Down="<font color='red'>".$this->user->lang('dazar_no')."</font>";}
			if($this->config('boss'.$actualBoss) == "nhc"){$Down="<font color='lime'>".$this->user->lang('dazar_nhc')."</font>";}
			if($this->config('boss'.$actualBoss) == "hc"){$Down="<font color='violet'>".$this->user->lang('dazar_hc')."</font>";}
			if($this->config('boss'.$actualBoss) == "myth"){$Down="<font color='aqua'>".$this->user->lang('dazar_myth')."</font>";}
			$out.="<tr style='border-bottom: 1px solid white;'><td style='text-shadow:1px 1px 1px black;'><font color='white'>".$this->user->lang("dazarprogress_f_boss".$actualBoss)."</font></td><td>".$Down."</td></tr>";
			$actualBoss++;
		}		
		$out.="</table>";
		return $out;
	}
}
?>
