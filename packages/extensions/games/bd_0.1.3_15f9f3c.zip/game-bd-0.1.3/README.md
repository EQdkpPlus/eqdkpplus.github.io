# game-bd

Changelog:

0.1.2
- Added Kunoichi and Ninja Classes

0.1.1
- Added Maehwa and Musa Classes
- Fixed Professions 
