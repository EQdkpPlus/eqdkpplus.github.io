<?php
/*	Project:	EQdkp-Plus
 *	Package:	Star Wars - The Old Republic game package
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

if ( !defined('EQDKP_INC') ){
	header('HTTP/1.0 404 Not Found');exit;
}
$german_array = array(
	'factions' => array(
		'' => 'Wähle Fraktion', //use "" or "_select" as key for selection entries - nothing else!
		'republic'	=> 'Republik',
		'imperial'	=> 'Imperium'
	),
	'classes' => array(
		0	=> 'Wähle Klasse',

		#republic
		1	=> 'Frontkämpfer',
		2	=> 'Kommando',
		3	=> 'Schurke',
		4	=> 'Revolverheld',
		5	=> 'Gelehrter',
		6	=> 'Schatten',
		7	=> 'Wächter',
		8	=> 'Hüter',

		#imperium
		9	=> 'Powertech',
		10	=> 'Söldner',
		11	=> 'Saboteur',
		12	=> 'Scharfschütze',
		13	=> 'Hexer',
		14	=> 'Attentäter',
		15	=> 'Marodeur',
		16	=> 'Juggernaut',
	),
	'races' => array(
		0	=> 'Wähle Rasse',
		1	=> 'Mensch',
		2	=> 'Rattataki',
		3	=> 'Twi\'lek',
		4	=> 'Chiss',
		5	=> 'Reinblut Sith',
		6	=> 'Miraluka',
		7	=> 'Mirialan',
		8	=> 'Zabrak',
		9	=> 'Cyborg',
		10	=> 'Cathar',
		11	=> 'Togruta',
		12	=> 'Nautolaner',
	),
	'skills'=> array(
		0 	=> 'Schildspezialist', 	//Frontkaempfer
		1 	=> 'Taktiker',			//Frontkaempfer
		2 	=> 'Angriffsspezialist',//Kommando
		3 	=> 'Gefechtssanitäter', //Kommando
		4 	=> 'Artillerist',		//Kommando
		5 	=> 'Seher',				//Gelehrter
		6 	=> 'Telekinese',		//Gelehrter
		7 	=> 'Gleichgewicht',		//Gelehrter
		8 	=> 'Kinetikkampf',		//Schatten
		9 	=> 'Infiltration',		//Schatten
		10 	=> 'Wachmann',			//Wächter
		11 	=> 'Kampf',				//Wächter
		12 	=> 'Konzentration',		//Wächter
		13 	=> 'Verteidigung',		//Hüter
		14 	=> 'Wachsamkeit',		//Hüter
		15 	=> 'Knochenflicker',	//Schurke
		16 	=> 'Schläger',			//Schurke
		17 	=> 'Fieser Kämpfer',	//Revolverheld
		18 	=> 'Meisterschütze',	//Revolverheld
		19 	=> 'Sabotage',			//Revolverheld
		20  => 'Wähle Klasse',		//platzhalter
		21  => 'Leibwache',			//Soeldner
		22  => 'Arsenal',			//Soeldner
		23  => 'Pyrotech',			//Powertech
		24  => 'Schildtechnologie',	//Powertech
		25  => 'Spezialprototyp',	//Powertech
		26  => 'Vernichtung',		//Marodeur
		27  => 'Blutbad',			//Marodeur
		28  => 'Raserei',			//Marodeur
		29  => 'Unstreblich',		//Juggernaut
		30  => 'Korrumpierung',		//Hexer
		31  => 'Blitzschlag',		//Hexer
		32  => 'Wahnsinn',			//Hexer
		33  => 'Dunkelheit',		//Attentaeter
		34  => 'Täuschung',			//Attentaeter
		35  => 'Treffsicherheit',	//Scharfschuetze
		36  => 'Ingenieur',			//Scharfschuetze
		37  => 'Tödlichkeit',		//Saboteur
		38  => 'Medizin',			//Saboteur
		39  => 'Verborgenheit',		//Saboteur
		40  => 'Vergeltung',		//Juggernaut
		41	=> 'Wut',				//juggernaut
		42	=> 'Fokus',				//Hüter
		43	=> 'Gelassenheit',		//Schatten
		44	=> 'Hass',				//Attentäter
		45	=> 'Grobian',			//Schurke
		46	=> 'Giftigkeit',		//Scharfschuetze
		47	=> 'Innovative Bewaffnung', //Söldner
		48 	=> 'Plasmatech', 		//Frontkaempfer


	),
	'roles' => array(
		1	=> 'Heiler',
		2	=> 'Tank',
		3	=> 'Schaden',
		4	=> 'PVP',
	),
	'professions' => array(
		'0'								=> 'Unbekannt',
		'biochem'						=> 'Biochemie', //
		'cybertech'						=> 'Cybertech', //
		'artifice'						=> 'Kunstfertigkeit', //
		'armormech'						=> 'Rüstungsbau',
		'armstech'						=> 'Waffenbau',
		'synthweaving'					=> 'Synth-Fertigung', //
		'bioanalysis'					=> 'Bioanalyse', //
		'scavenging'					=> 'Plündern', //
		'archaeolgy'					=> 'Archäologie', //
		'diplomacy'						=> 'Diplomatie', //
		'underworldtrading'				=> 'Unterwelthandel', //
		'slicing'						=> 'Hacken', //
		'investigation'					=> 'Ermittlung', //
		'treasurehunting'				=> 'Schatzsuche', //
	),

	'lang' => array(
		'swtor'						=> 'Star Wars: The Old Republic',
		//Reputation
		'uc_cat_reputation'			=> 'Ruf',
		'reputation'				=> 'Ruf',
		'head_reputation_perc'		=> 'Wert',
		'head_reputation_name'		=> 'Fraktion',
		'tab_reputation'			=> 'Ruf',
		'ruflevel'					=> 'Stufe',
		'repuname0'					=> 'Ohne',
		'repuname1'					=> 'Fremdling',
		'repuname2'					=> 'Neuling',
		'repuname3'					=> 'Freund',
		'repuname4'					=> 'Held',
		'repuname5'					=> 'Streiter',
		'repuname6'					=> 'Legende',

		'ruf1'	=> 'D.H.O.R.N.',
		'ruf2'	=> 'Die Gree-Enklave',
		'ruf3'	=> 'Die Schmugglerwaren-Wiederverkaufsgesellschaft',
		'ruf4'	=> 'Die Schreckenshenker',
		'ruf5'	=> 'Die Voss',
		'ruf6'	=> 'Doppelstern-Immobilien',
		'ruf7'	=> 'Galactic Solutions Industries',
		'ruf8'	=> 'Imperiale Garde auf Belsavis',
		'ruf9'	=> 'Imperiale Streitkräfte auf Makeb',
		'ruf10'	=> 'Imperiales Frontkommando',
		'ruf11'	=> 'Kopfgeld-Vermittlungsgesellschaft',
		'ruf12'	=> 'Kopfgeld-Versorgungsunternehmen',
		'ruf13'	=> 'Waffensicherheitskorps',
		'ruf14'	=> '1. imperiale Flotte',
		'ruf15'	=> 'Interplanetare Komponentenbörse',
		'ruf16'	=> 'Stoßtrupp Oricon',
		'ruf17' => 'Republikanische Hyperraum-Armada',
		'ruf18'	=> 'Koalitionstruppen auf Yavin 4',
		'ruf19'	=> 'Freibeuter-Gewerkschaft',
		'ruf20'	=> 'Bewohner von Rishi',
		'ruf21'	=> 'Unterweltbörse',
		'ruf22'	=> 'Republikanische Iokath-Initiative',
		'ruf23'	=> 'OSSUS-Angriffsbattalion',
		'ruf24'	=> 'Die Dantooine-Initiative',

		// guildbank_money
		'gb_currency_credits'		=> 'Credits',
		'gb_currency_credits_s'		=> 'C',

		//Admin Settings
		'core_sett_fs_gamesettings'	=> 'SWToR Einstellungen',
		'servername'				=> 'Servername',
		'uc_one_faction'			=> 'Klassenauswahl auf bestimmte Fraktion einschränken?',
		'uc_faction'				=> 'Fraktion',
		'uc_faction_help'			=> 'Die Klassen der gegnerischen Fraktion können nicht mehr ausgewählt werden.',

		// Profile information
		'uc_gender'							=> 'Geschlecht',
		'uc_male'								=> 'Männlich',
		'uc_female'							=> 'Weiblich',
		'uc_guild'							=> 'Gilde',
		'uc_race'								=> 'Rasse',
		'uc_class'							=> 'Klasse',
		'uc_skill'		  				=> 'Skillung',
		'uc_servername'					=> 'Realm',
		'uc_prof1_value'				=> 'Stufe',
		'uc_prof1_name'					=> 'Hauptberuf',
		'uc_prof2_value'				=> 'Stufe',
		'uc_prof2_name'					=> 'Sekundärberuf',
		'uc_prof3_value'				=> 'Stufe',
		'uc_prof3_name'					=> 'Sekundärberuf',
		'uc_prof_professions'		=> 'Berufe',
		'uc_level'							=> 'Stufe',

		//Operation
		'sm_ewigekammer'			=> 'Ewige Kammer (Story)',
		'hc_ewigekammer'			=> 'Ewige Kammer (Veteran)',
		'sm_karaggaspalast'		=> 'Karaggas Palast (Story)',
		'hc_karaggaspalast'		=> 'Karaggas Palast (Veteran)',
		'sm_explosivkonflikt'	=> 'Explosiv Konflikt (Story)',
		'hc_explosivkonflikt'	=> 'Explosiv Konflikt (Veteran)',
		'nm_explosivkonflikt'	=> 'Explosiv Konflikt (Meister)',
		'sm_abschaum'					=> 'Abschaum und Verkommenheit (Story)',
		'hc_abschaum'					=> 'Abschaum und Verkommenheit (Veteran)',
		'nm_abschaum'					=> 'Abschaum und Verkommenheit (Meister)',
		'sm_schrecken'				=> 'Schrecken aus der Tiefe (Story)',
		'hc_schrecken'				=> 'Schrecken aus der Tiefe (Veteran)',
		'nm_schrecken'				=> 'Schrecken aus der Tiefe (Meister)',
		'sm_s_festung'				=> 'Schreckensfestung (Story)',
		'hc_s_festung'				=> 'Schreckensfestung (Veteran)',
		'nm_s_festung'				=> 'Schreckensfestung (Meister)',
		'sm_s_palast'					=> 'Schreckenspalast (Story)',
		'hc_s_palast'					=> 'Schreckenspalast (Veteran)',
		'nm_s_palast'					=> 'Schreckenspalast (Meister)',
		'sm_tbh'							=> 'Toborro\'s Hof (Story)',
		'hc_tbh'							=> 'Toborro\'s Hof (Veteran)',
		'nm_tbh'							=> 'Toborro\'s Hof (Meister)',
		'sm_wueter'						=> 'Die Wüter (Story)',
		'hc_wueter'						=> 'Die Wüter (Veteran)',
		'nm_wueter'						=> 'Die Wüter (Meister)',
		'sm_tempel'						=> 'Tempel des Opfers (Story)',
		'hc_tempel'						=> 'Tempel des Opfers (Veteran)',
		'nm_tempel'						=> 'Tempel des Opfers (Meister)',
		'sm_mono'							=> 'Gewaltiger Monolith (Story)',
		'hc_mono'							=> 'Gewaltiger Monolith (Veteran)',
		'nm_mono'							=> 'Gewaltiger Monolith (Meister)',
		'sm_gods'							=> 'Götter aus der Maschiene (Story)',
		'hc_gods'							=> 'Götter aus der Maschiene (Veteran)',
		'sm_queen'						=> 'Mutierte Genosianische Königin (Story)',
		'hc_queen'						=> 'Mutierte Genosianische Königin (Veteran)',
		'sm_dxun'							=> 'Dxun (Story)',
		'hc_dxun'							=> 'Dxun (Veteran)',

		//realms
	),
	'realmlist' => array(
		'Star Forge',
		'Satele Shan',
		'Tulak Hord',
		'Darth Malgus',
		'The Leviathan')
);

?>
