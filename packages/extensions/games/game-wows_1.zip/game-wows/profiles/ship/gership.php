<?php
/*	Project:	EQdkp-Plus
 *	Package:	World of Warships game package
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
if ( !defined('EQDKP_INC') ){
	header('HTTP/1.0 404 Not Found');exit;
}
	
	$gerdestroyername =  array(
		1		=>	'',
		2		=>	'',
		3		=>	'',
		4		=>	'',
		5		=>	'',
		6		=>	'',
		7		=>	'',
		8		=>	'',
		9		=>	'',
		10		=>	'',
		);
	
 	$gercruisername =  array( // Namen i.o.
		1		=>	'Hermelin',
		2		=>	'Dresden',
		3		=>	'Kolberg',
		4		=>	'Karlsruhe',
		5		=>	'Königsberg',
		6		=>	'Nürnberg',
		7		=>	'Yorck',
		8		=>	'Hipper',
		9		=>	'Roon',
		10		=>	'Hindenburg',
		11		=>	'Emden',//
		);

	$gerbattleshipname =  array( // Namen i.o.
		3		=>	'Nassau',
		4		=>	'Kaiser',
		5		=>	'König Albert',
		6		=>	'Bayern',
		7		=>	'Gneisenau',
		8		=>	'Bismarck',
		9		=>	'Friedrich der Große',
		10		=>	'Großer Kurfürst',
		11		=>	'Scharnhorst',//
		12		=>	'Tirpitz',//
		);

	$gercarriername =  array( // Namen i.o.

		);
 ?>