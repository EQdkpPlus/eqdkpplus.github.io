Installation of this game: 

 - create a new subfolder called 'lostark' in folder 'games' - extract the downloaded files in this new created folder. The game class and the language folder must be directly in this subfolder - go to the settings area of your EQdkp Plus Adminpanel and select your game