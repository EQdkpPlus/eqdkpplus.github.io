<?php

if ( !defined('EQDKP_INC') ){
	header('HTTP/1.0 404 Not Found');exit;
}

if(!class_exists('lostark')) {
	class lostark extends game_generic {	
		public $version			= '1.0.0';
		protected $this_game	= 'lostark';
		protected $types		= array('classes', 'archetype', 'crafts', 'roles', 'filters');
		public $langs			= array('russian');	
		protected static $apiLevel = 20;
					
		protected $class_dependencies = array(
array (
  'name' => 'class',
  'type' => 'classes',
  'primary' => true,
  'admin' => false,
  'decorate' => true,
  'colorize' => true,
  'roster' => true,
  'recruitment' => true,
  'parent' => 
  array (
    'archetype' => 
    array (
      1 => 
      array (
        0 => 1,
        1 => 6,
        2 => 7,
      ),
      2 => 
      array (
        0 => 8,
        1 => 9,
        2 => 10,
      ),
      3 => 
      array (
        0 => 11,
        1 => 12,
        2 => 13,
      ),
      4 => 
      array (
        0 => 14,
        1 => 15,
        2 => 16,
      ),
    ),
  ),
), 
array (
  'name' => 'archetype',
  'type' => 'archetype',
  'primary' => false,
  'admin' => false,
  'decorate' => false,
  'colorize' => false,
  'roster' => false,
  'recruitment' => false,
  'parent' => false,
), 
array (
  'name' => 'craft',
  'type' => 'crafts',
  'primary' => false,
  'admin' => false,
  'decorate' => true,
  'colorize' => false,
  'roster' => true,
  'recruitment' => false,
  'parent' => false,
), 
			
		); //end $class_dependencies
		
		public $default_roles = array (
  1 => 
  array (
    0 => 1,
  ),
  2 => 
  array (
    0 => 6,
  ),
  3 => 
  array (
    0 => 2,
    1 => 3,
    2 => 7,
    3 => 8,
    4 => 9,
  ),
  4 => 
  array (
    0 => 4,
    1 => 5,
    2 => 10,
    3 => 11,
    4 => 12,
  ),
);
		
		protected $class_colors = array (
);
		
		
		protected $glang		= array();
		protected $lang_file	= array();
		protected $path		= '';
		protected $filters		= array();
		public $lang			= false;
		//Primary Classtype
		protected $classes = false;
		
				
		/* Constructor */
		public function __construct() {
			parent::__construct();
		}
				
		/* Install or Game Change Information */
		public function install($install=false){
		
			$info = array();
			return $info;
		}
		
		public function profilefields(){
			$arrFields = array (
  'profilefield_1' => 
  array (
    'type' => 'int',
    'category' => 'character',
    'lang' => 'uc_profilefield_1',
    'size' => 40,
    'undeletable' => false,
    'sort' => 1,
    'options' => 
    array (
      0 => '',
    ),
  ),
  'profilefield_2' => 
  array (
    'type' => 'int',
    'category' => 'character',
    'lang' => 'uc_profilefield_2',
    'size' => 40,
    'undeletable' => false,
    'sort' => 2,
    'options' => 
    array (
      0 => '',
    ),
  ),
);
			
			return $arrFields;
		}

		/**
		* Initialises filters
		*
		* @param array $langs
		*/
		protected function load_filters($langs){
			if(!$this->classes) {
				$this->load_type('classes', $langs);
			}
			foreach($langs as $lang) {
				$names = $this->classes[$this->lang];
				$this->filters[$lang][] = array('name' => '-----------', 'value' => false);
				foreach($names as $id => $name) {
					$this->filters[$lang][] = array('name' => $name, 'value' => 'class:'.$id);
				}
			}
		}
					
	}#class
}
?>