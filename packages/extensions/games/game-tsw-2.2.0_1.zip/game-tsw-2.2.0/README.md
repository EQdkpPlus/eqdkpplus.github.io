# The Secret World Game


See also the [Wiki Entry](https://eqdkp-plus.eu/wiki/The_Secret_World "EQDKPPlus Wiki")
Contact me ingame RedEyeEagle

# Changelog
##2.2.0
####Requires EQdkp 2.3

+ new function for hide roles in the calendar 
+ new roles and icons (and source to create own)
+ fix for some items
+ add modules item
+ add Muesum drop from NYR elite
+ add itempictures from Eidolon nm
+ add new Event Icons
+ add and adjust new events/Itempools and the MultiDKP Pool

**load default roles in Roles Managment** 

**Purge Item Cache** 

##2.1.9

+ add Shamabala
+ 18h Raidcooldown
+ Items (NM Raids, PVP Signets, Aegis Stuff)
+ some Items fixes

**load default profile fields in Profile fields Managment** 

##2.1.8
####Requires EQdkp 2.1

Only infotooltip Update:

+ add Flappy Loot
+ add some missing Imgaes
+ 3d heroic still with placeholder, but nicer

In case of Issues, purge the itemtooltip Cache.


##2.1.7
####Requires EQdkp 2.1

Add issue 12 Information's:

+ rename "Tokio" Placeholder Event to "Flappy" and give them an new Icon
+ change Items from Eidolon from 10.1 to 10.3
+ add the 3. heroic Item (without Img)

Character:

+ Add the Wings, PVP Zones, TL Access


##2.1.6
+ Add Augment Resonator Items(DE/EN/FR)
+ Add Informations for Guildbank (DE/EN/FR)

