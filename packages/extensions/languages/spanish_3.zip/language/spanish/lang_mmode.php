<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Spanish	
//Created by EQdkp Plus Translation Tool on  2019-11-11 18:52
//File: language/spanish/lang_mmode.php
//Source-Language: english

$lang = array( 
	"click2show" => '(Click para mostrar)',
	"maintenance_mode" => 'Modo de Mantenimiento',
	"task_manager" => 'Administrador de Tareas',
	"admin_acp" => 'Panel de Administración',
	"activate_info" => '<h1>Activate Maintenance Mode</h1><br />With this maintenance tool, you can easily update your EQdkp and import Data from an older Version.<br />An Update or Import is only possible, if the maintenance mode is enabled and denies the Login of users to prevent Errors and Problems.<br /><br />Reason, shown to the users (not required):<br />',
	"activate_mmode" => 'Activar Modo de Mantenimiento',
	"deactivate_mmode" => 'Cerrar Modo de Mantenimientop',
	"leave_mmode" => 'Cancelar',
	"home" => 'Inicio',
	"no_leave" => 'Imposible para desactivar el modo de mantenimiento, siempre y cuando las tareas requeridas deben ser ejecutados.',
	"no_leave_accept" => 'Imposible para desactivar el modo de mantenimiento, siempre y cuando las tareas requeridas deben ser ejecutados.',
	"maintenance_message" => '<b>The EQdkp Plus-system is currently running in maintenance mode.</b> A login actually is only possible for administrators.',
	"reason" => '<br /><b>Reason:</b> ',
	"admin_login" => 'Conexión de Administrador',
	"login" => 'Conectar',
	"username" => 'Usuario',
	"password" => 'Contraseña',
	"remember_password" => '¿Recordar Contraseña?',
	"invalid_login_warning" => '¡Login incorrecto! - Porfavor verifica tu Usuario y Contraseña. Solo los Administradores están permitido logearse.',
	"is_necessary" => '¿Necesario?',
	"is_applicable" => '¿Aplicable?',
	"name" => 'Nombre',
	"version" => 'Versión',
	"author" => 'Autor',
	"link" => 'Proceso Tarea',
	"description" => 'Descripción',
	"type" => 'Tipo de Tarea',
	"yes" => 'Si',
	"no" => 'No',
	"click_me" => 'Proceso Tarea',
	"mmode_info" => 'Su sistema actualmente está en modo de mantenimiento y niega el acceso a los usuarios normales hasta que desactive el modo de mantenimiento.',
	"necessary_tasks" => 'Tareas necesarias',
	"applicable_tasks" => 'Not necessary/already processed tasks',
	"not_applicable_tasks" => 'Tareas no aplicables',
	"no_nec_tasks" => 'Tareas Innecesarias',
	"nec_tasks" => 'Las siguientes tareas son necesarias. Por favor, procesarlos para que su sistema al estado real.',
	"nec_tasks_available" => 'Por favor, procesar las tareas necesarias para llevar su sistema al estado real.',
	"applicable_warning" => 'Esta tarea no es aplicable! El tratamiento puede causar la pérdida de datos! Procesar esta tarea sólo si está absolutamente seguro!',
	"executed_tasks" => 'Las siguientes acciones se han procesado para la tarea %s',
	"stepend_info" => 'La tarea se ha terminado. El EQDKP Plus se encuentra todavía en modo de mantenimiento para que pueda probar todo. Sólo después de que el modo de mantenimiento se ha cerrado, los usuarios podrán conectarse de nuevo.',
	"mmode_pfh_error" => 'Se produjeron algunos errores. Es necesario para corregir estos errores para cerrar el modo de mantenimiento.',
	"lib_cache_notwriteable" => 'No se puede escribir en la carpeta data. Por favor, establecer permisos de carpeta para CHMOD 777!',
	"fix" => 'Fijar',
	"update" => 'Core update',
	"import" => 'Importar',
	"plugin_update" => 'Actualizar Plugin',
	"game_update" => 'Game update',
	"worker" => 'Worker',
	"unknown_task_warning" => 'Tarea desconocida.',
	"application_warning" => 'No se puede procesar la tarea debido a un error de la aplicación!',
	"dependency_warning" => 'Esta tarea depende de los demás. Por favor, procesarlos primero!',
	"start_here" => '¡Comenzar aquí!',
	"following_updates_necessary" => 'Los siguientes cambios son necesarios:',
	"start_update" => 'Procesar todas las actualizaciones necesarias!',
	"only_this_update" => 'Procesar sólo esta actualización:',
	"start_single_update" => 'Proceso de actualización',
	"backup" => 'Copia de Base de Datos',
	"backup_note" => 'Una copia de la base de datos fue creada en %s.',
	"support_eqdkplus" => 'A project like EQdkp Plus can only exist, if we can get back some of the effort, time and love we invest in EQdkp Plus. You can give something back on the following ways:
						<ul>
							<li><i class="fa fa-puzzle-piece"></i> <a href="http://eqdkp-plus.eu/repository/">Publish a plugin or template, so every EQdkp Plus user can use it</a></li>
							<li><i class="fa fa-comments"></i> <a href="http://eqdkp-plus.eu/forum/">Support us at our board</a></li>
							<li><i class="fa fa-cogs"></i> <a href="http://eqdkp-plus.eu/en/development.html">Take part actively in the development of EQdkp Plus</a></li>
							<li><i class="fa fa-usd"></i> <a href="http://eqdkp-plus.eu/en/donate.html">Support us financially so we can continue offering you our services</a></li>
						</ul>
						So if you love EQdkp Plus as much as we do, think about supporting us!',
	
);

?>