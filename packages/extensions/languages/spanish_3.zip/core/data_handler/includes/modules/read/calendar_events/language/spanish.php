<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Spanish	
//Created by EQdkp Plus Translation Tool on  2019-11-11 18:52
//File: core/data_handler/includes/modules/read/calendar_events/language/spanish.php
//Source-Language: english

$module_lang = array(
	"roleid" => 'Rol-ID',
	"duration" => 'Duración',
	"date" => 'Fecha',
	"html_weekday" => 'Día de la semana',
	"name" => 'Nombre',
	"creator" => 'Creador',
	"calendar" => 'Calendario',
	"edit" => '',
	"html_time_start" => 'Empezar',
	"html_time_end" => 'Final',
	"raid_event" => 'Evento',
	"notes" => 'Nota',
	"detailslink" => '',
	);
	$preset_lang = array(
	"calevents_id" => 'ID del evento de calendario',
	"calevents_date" => 'Fecha del evento de calendario',
	"calevents_weekday" => 'Día de la semana del evento de calendario',
	"calevents_duration" => 'Duración del evento de calendario',
	"calevents_name" => 'Nombre del evento de calendario',
	"calevents_creator" => 'Creador de eventos del Calendario',
	"calevents_calendar" => 'Eventos de Calendario del Calendario',
	"calevents_edit" => 'Editar eventos del Calendario',
	"calevents_start_time" => 'Hora de inicio del evento del calendario',
	"calevents_end_time" => 'Hora de finalización del evento del Calendario',
	"calevents_raid_event" => 'Evento de Bandas del Calendario',
	"calevents_note" => 'Evento de Notas del Calendario',
	"calevents_detailslink" => 'Enlace detallado del evento del Calendario',
	);
	

?>