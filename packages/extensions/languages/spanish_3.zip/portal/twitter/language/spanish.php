<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Spanish	
//Created by EQdkp Plus Translation Tool on  2019-11-11 18:52
//File: portal/twitter/language/spanish.php
//Source-Language: english

$lang = array( 
	"twitter" => 'Twitter',
	"twitter_name" => 'Twitter',
	"twitter_desc" => 'Seguir una cuenta específica de twitter',
	"twitter_f_account" => 'Cuenta de Twitter',
	"twitter_f_maxitems" => 'Máximo numero de tuits a mostrar (Vacio = sin límite)',
	"twitter_f_cachetime" => 'Tiempo de Caché en horas (por defecto: 1 hora)',
	"twitter_f_hideuserreplys" => 'Hide Replys to Users',
	"twitter_f_hideretweets" => 'Hide Retweets',
	"pm_twitter_follow" => 'Seguidores en twitter',
	"pm_twitter_period" => array(
	0 => 'segundo',
	1 => 'minuto',
	2 => 'hora',
	3 => 'día',
	4 => 'semana',
	5 => 'mes',
	6 => 'año',
	7 => 'década',
	),
	"pm_twitter_periods" => array(
	0 => 'segundos',
	1 => 'minutos',
	2 => 'horas',
	3 => 'días',
	4 => 'semanas',
	5 => 'meses',
	6 => 'años',
	7 => 'décadas',
	),
	"pm_twitter_tense" => array(
	0 => 'desde ahora',
	1 => 'hace',
	),
	"pm_twitter_format" => 'niputaidea',
	"pm_twitter_answer" => 'Responder',
	"pm_twitter_retweet" => 'Retweet',
	"pm_twitter_favorit" => 'Favorito',
	
);

?>