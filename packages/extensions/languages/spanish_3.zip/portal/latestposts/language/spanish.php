<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Spanish	
//Created by EQdkp Plus Translation Tool on  2019-11-11 18:52
//File: portal/latestposts/language/spanish.php
//Source-Language: english

$lang = array( 
	"latestposts" => 'Últimos mensajes del foro',
	"latestposts_name" => 'Últimos mensajes del foro',
	"latestposts_desc" => 'Mostrar los últimos mensajes de su tablón de anuncios',
	"portal_latestposts_nomodule" => 'Sin módulo de la placa seleccionada. Por favor, vaya a la configuración del módulo y configurar este módulo.',
	"portal_latestposts_invmodule" => 'Módulo BB incorrecto',
	"portal_latestposts_noselectedboards" => 'No hay foros han sido seleccionados para ser visualizado.',
	"latestposts_f_bbmodule" => 'Módulo Foro',
	"latestposts_f_dbmode" => 'Seleccione el modo de conexión de base de datos',
	"latestposts_f_help_dbmode" => 'La información de conexión de base de datos sólo es necesario si se selecciona "Otro BD que EQDKP"',
	"latestposts_dbmode_same" => 'El Foro se encuentra en la misma base de datos como EQDKP',
	"latestposts_dbmode_new" => 'El Foro está en otra base de datos como EQDKP',
	"latestposts_dbmode_bridge" => 'Utilice los ajustes de conexión de puente',
	"latestposts_dbmode_none" => 'None',
	"latestposts_f_dbname" => 'Base de datos',
	"latestposts_f_dbuser" => 'Usuario',
	"latestposts_f_dbpassword" => 'Contraseña',
	"latestposts_f_dbhost" => 'HOST',
	"latestposts_f_dbprefix" => 'Prefijo',
	"latestposts_f_url" => 'URL para la BOARD',
	"latestposts_f_amount" => 'Ver los últimos "x" los comentarios',
	"latestposts_f_trimtitle" => 'Recorte títulos de los temas largos después de "x" caracteres',
	"latestposts_f_help_trimtitle" => 'Only when in left/right Module block',
	"latestposts_f_linktype" => '¿Cómo se deben abrir los enlaces para los temas?',
	"latestposts_f_blackwhitelist" => 'Listas de Karma',
	"latestposts_f_help_blackwhitelist" => 'Rechazar los identificadores del Foro insertados (-) o aceptarlos (+)',
	"latestposts_f_privateforums" => 'Black-/Whitelist for Usergroup: ',
	"latestposts_f_help_privateforums" => 'Insert here the forum IDs used by Black-/Whitelist, seperated by commas',
	"latestposts_f_help_privateforums2" => 'Select the forums for the shown usergroup used by Black-/Whitelist',
	"latestposts_noentries" => 'No hay entradas disponibles',
	"latestposts_connerror" => 'Error de conexión',
	"latestposts_lastpost" => 'Last Answer',
	"latestposts_starter" => 'Motor de arranque',
	"latestposts_posts" => 'Respuestas',
	"latestposts_title" => 'Topic',
	"latestposts_forum" => 'Board',
	"latestposts_display_normal" => 'Normal',
	"latestposts_display_accordion" => 'Accordion',
	"latestposts_f_showcontent" => 'Show Preview of post',
	"latestposts_f_style" => 'Display',
	
);

?>