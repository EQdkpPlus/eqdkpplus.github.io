<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Spanish	
//Created by EQdkp Plus Translation Tool on  2019-11-11 18:52
//File: games/ffxiv/language/spanish.php
//Source-Language: english

$spanish_array = array( 
	"classes" => array(
	0 => 'Desconocido',
	1 => 'Black Mage',
	2 => 'Guerrero',
	3 => 'Dragoon',
	4 => 'Monje',
	5 => 'Paladín',
	6 => 'Bardo',
	7 => 'White Mage',
	8 => 'Invocador',
	9 => 'Sabio',
	10 => 'Ninja',
	11 => 'Caballero negro',
	12 => 'Astrólogo',
	13 => 'Maquinista',
	14 => 'Samurai',
	15 => 'Red Mage',
	),
	"races" => array(
	0 => 'Desconocido',
	1 => 'Elezen',
	2 => 'Roegadyn',
	3 => 'Hyuran',
	4 => 'Miqote',
	5 => 'Lalafell',
	6 => 'Au Ra',
	),
	"factions" => array(
	"twin_adder" => 'Order of the Twin Adder',
	"maelstrom" => 'Maelstrom',
	"flames" => 'The Immortal Flames',
	),
	"lang" => array(
	"ffxiv" => 'Final Fantasy XIV',
	"tank" => 'Tanque',
	"support" => 'Sanador',
	"damage_dealer" => 'Distribuidor de daño',
	"uc_gender" => 'Género',
	"uc_male" => 'Masculino',
	"uc_female" => 'Femenino',
	"uc_guild" => 'Free Company',
	"uc_race" => 'Raza',
	"uc_class" => 'Clase',
	"uc_cat_berufe" => 'Professions',
	"uc_level" => 'Level',
	"uc_grandcompany" => 'Grand Company',
	"uc_twinadder" => 'Order of the Twin Adder',
	"uc_maelstrom" => 'Maelstrom',
	"uc_flames" => 'The Immortal Flames',
	"uc_city" => 'City-state',
	"uc_uldah" => 'Ul\'dah',
	"uc_limsa" => 'Limsa Lominsa ',
	"uc_gridania" => 'Gridania',
	"up_alchemist" => 'Alchemist',
	"up_leatherworker" => 'Leatherworker',
	"up_goldsmith" => 'Goldsmith',
	"up_culinarian" => 'Culinarian',
	"up_blacksmith" => 'Blacksmith',
	"up_armorer" => 'Armorer',
	"up_weaver" => 'Weaver',
	"up_carpenter" => 'Carpenter',
	"up_fisher" => 'Fisher',
	"up_botanist" => 'Botanist',
	"up_miner" => 'Miner',
	"core_sett_fs_gamesettings" => 'Final Fantasy XIV Settings',
	"uc_faction" => 'Grand Company',
	"uc_faction_help" => 'Select the Grand Company for your Free Company.',
	),
	
);

?>