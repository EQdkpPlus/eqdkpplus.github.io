<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2019-11-11 18:52
//File: plugins/discord/language/russian/lang_main.php
//Source-Language: english

$lang = array( 
	"discord" => 'Дискорд',
	"discord_short_desc" => 'Init Discord',
	"discord_long_desc" => 'Инициирование соединения между EQdkp Plus и Discord',
	"discord_plugin_not_installed" => 'Плагин Дискорда не установлен',
	"discord_fs_general" => 'Общее',
	"discord_f_guild_id" => 'ID гильдии',
	"discord_f_help_guild_id" => 'Вы можете получить URL гильдии из URL сервера. Это первое большое число в URL.',
	"discord_f_bot_client_id" => 'ID клиента вашего бота',
	"discord_f_help_bot_client_id" => 'Для получения дополнительной информации и инструкций перейдите по ссылке https://eqdkp-plus.eu/wiki/Discord',
	"discord_f_bot_token" => 'Токен доступа для пользовательского бота',
	"discord_f_help_bot_token" => 'Для получения дополнительной информации и инструкций перейдите по ссылке https://eqdkp-plus.eu/wiki/Discord',
	"discord_autorize_bot" => 'Добавить бота на сервер',
	"discordlatestposts" => 'Последние сообщения Discord',
	"discordlatestposts_name" => 'Последние сообщения Discord',
	"discordlatestposts_desc" => 'Показывает последние сообщения с выбранных вами каналов Discord',
	"discord_f_amount" => 'Количество отображаемых сообщений',
	"discord_f_blackwhitelist" => 'Черный - или Белый список',
	"discord_f_help_blackwhitelist" => 'Reject the inserted Forum IDs (blacklisting) or accept them (whitelisting)',
	"discord_f_cachetime" => 'Кэширование времени постов',
	"discord_f_help_privateforums2" => 'Select the forums for the shown usergroup used by Black-/Whitelist',
	"discordlatestposts_noselectedboards" => 'Нет выбранных каналов',
	"discordlatestposts_noentries" => 'Нет доступных сообщений',
	
);

?>