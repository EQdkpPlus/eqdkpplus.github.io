<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2019-11-11 18:52
//File: games/bs/language/russian.php
//Source-Language: english

$russian_array = array( 
	"factions" => array(
	"cerulean_order" => 'Лазурный Орден',
	"crimson_legion" => 'Багровый Легион',
	),
	"races" => array(
	0 => 'Неизвестно',
	1 => 'Ван',
	2 => 'Лин',
	3 => 'Фэн',
	4 => 'Шэн',
	),
	"classes" => array(
	0 => 'Неизвестно',
	1 => 'Мастер Клинка',
	2 => 'Мастер Секиры',
	3 => 'Мастер Призыва',
	4 => 'Мастер Стихий',
	5 => 'Мастер Кунг-фу',
	6 => 'Мастер Тени',
	7 => 'Мастер Клинка Лин',
	8 => 'Мастер Духов',
	9 => 'Мастер Ци',
	10 => 'Gunslinger',
	11 => 'Warden',
	12 => 'Zen Archer',
	),
	"genders" => array(
	0 => 'Мужчина',
	1 => 'Женщина',
	),
	"lang" => array(
	"bs" => 'Blade & Soul',
	"core_sett_fs_gamesettings" => 'Настройки Blade & Soul',
	"uc_faction" => 'Фракция',
	"uc_gender" => 'Пол',
	"uc_guild" => 'Клан',
	"uc_race" => 'Раса',
	"uc_class" => 'Класс',
	"uc_level" => 'Уровень',
	"uc_hongmoon" => 'Уровень Hongmoon',
	),
	
);

?>