<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2019-11-11 18:52
//File: games/ffxiv/language/russian.php
//Source-Language: english

$russian_array = array( 
	"classes" => array(
	0 => 'Неизвестно',
	1 => 'Чёрный маг',
	2 => 'Воин',
	3 => 'Драгун',
	4 => 'Монах',
	5 => 'Паладин',
	6 => 'Бард',
	7 => 'Белый маг',
	8 => 'Чернокнижник',
	9 => 'Учёный',
	10 => 'Ниндзя',
	11 => 'Темный рыцарь',
	12 => 'Астролог',
	13 => 'Механик',
	14 => 'Самурай',
	15 => 'Красный маг',
	),
	"races" => array(
	0 => 'Неизвестно',
	1 => 'Элезен',
	2 => 'Роэгадин',
	3 => 'Хьюр',
	4 => 'Мико\'те',
	5 => 'Лалафелль',
	6 => 'Ау Ра',
	),
	"factions" => array(
	"twin_adder" => 'Order of the Twin Adder',
	"maelstrom" => 'Maelstrom',
	"flames" => 'The Immortal Flames',
	),
	"lang" => array(
	"ffxiv" => 'Final Fantasy XIV',
	"tank" => 'Танк',
	"support" => 'Лекарь',
	"damage_dealer" => 'Боец',
	"uc_gender" => 'Пол',
	"uc_male" => 'Мужской',
	"uc_female" => 'Женский',
	"uc_guild" => 'Свободная компания',
	"uc_race" => 'Раса',
	"uc_class" => 'Класс',
	"uc_cat_berufe" => 'Профессии',
	"uc_level" => 'Уровень',
	"uc_grandcompany" => 'Grand Company',
	"uc_twinadder" => 'Order of the Twin Adder',
	"uc_maelstrom" => 'Maelstrom',
	"uc_flames" => 'The Immortal Flames',
	"uc_city" => 'Положение города',
	"uc_uldah" => 'Ul\'dah',
	"uc_limsa" => 'Limsa Lominsa',
	"uc_gridania" => 'Gridania',
	"up_alchemist" => 'Алхимик',
	"up_leatherworker" => 'Кожевник',
	"up_goldsmith" => 'Ювелир',
	"up_culinarian" => 'Кулинар',
	"up_blacksmith" => 'Кузнец',
	"up_armorer" => 'Оружейник',
	"up_weaver" => 'Портной',
	"up_carpenter" => 'Плотник',
	"up_fisher" => 'Рыбак',
	"up_botanist" => 'Ботаник',
	"up_miner" => 'Рудокоп',
	"core_sett_fs_gamesettings" => 'Настройки Final Fantasy XIV',
	"uc_faction" => 'Grand Company',
	"uc_faction_help" => 'Выберите Grand Company вашей свободной компании.',
	),
	
);

?>