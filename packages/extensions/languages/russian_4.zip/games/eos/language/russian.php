<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2019-11-11 18:52
//File: games/eos/language/russian.php
//Source-Language: english

$russian_array = array( 
	"classes" => array(
	0 => 'Неизвестно',
	1 => 'Rogue',
	2 => 'Warrior',
	3 => 'Guardian',
	4 => 'Archer',
	5 => 'Sorceress',
	),
	"skills" => array(
	0 => 'Неизвестно',
	1 => 'Duelist',
	2 => 'Assassin',
	3 => 'Protector',
	4 => 'Berserker',
	5 => 'Stormguard',
	6 => 'Earthguard',
	7 => 'Huntress',
	8 => 'Bard',
	9 => 'Firemage',
	10 => 'Frostmage',
	),
	"races" => array(
	0 => 'Human',
	),
	"roles" => array(
	1 => 'Танк',
	2 => 'Боец',
	3 => 'Поддержка',
	4 => 'PVP',
	),
	"professions" => array(
	0 => 'Неизвестно',
	"juwel" => 'Jewelcrafting',
	"collect" => 'Collector',
	"alchem" => 'Alchemy',
	),
	"professions2" => array(
	0 => 'Неизвестно',
	"cook" => 'Cooking',
	"spirit" => 'Soul Expert',
	),
	"lang" => array(
	"eos" => 'Echo of Soul',
	"uc_prof1_name" => 'Основная профессия',
	"uc_prof_value" => 'Значение',
	"uc_prof2_name" => 'Вторая профессия',
	"uc_class" => 'Класс',
	"uc_skill" => 'Умение',
	"uc_level" => 'Уровень',
	"dryadenwald" => 'Dryad Forest',
	"hc_dryadenwald" => 'Dryad Forest(Hard)',
	"tr_dryadenwald" => 'Dryad Forest(Training)',
	),
	
);

?>