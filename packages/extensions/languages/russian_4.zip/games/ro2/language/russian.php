<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2019-11-11 18:52
//File: games/ro2/language/russian.php
//Source-Language: english

$russian_array = array( 
	"classes" => array(
	0 => 'Неизвестно',
	1 => 'Прислужник',
	2 => 'Лучник',
	3 => 'Маг',
	4 => 'Мечник',
	5 => 'Вор',
	),
	"races" => array(
	0 => 'Неизвестно',
	1 => 'Норман',
	2 => 'Эллр',
	3 => 'Димаго',
	),
	"lang" => array(
	"ro2" => 'Ragnarok Online 2',
	"tank" => 'Танк',
	"damage_dealer" => 'Дамагер',
	"healer" => 'Лекарь',
	"uc_gender" => 'Пол',
	"uc_male" => 'Мужской',
	"uc_female" => 'Женский',
	"uc_guild" => 'Гильдия',
	"uc_advanced_class" => 'Расширенный класс',
	"uc_prof1_name" => 'Профессия',
	"uc_prof1_value" => 'Уровень профессии',
	"uc_race" => 'Раса',
	"uc_class" => 'Класс ',
	"uc_ac_0" => '-',
	"uc_ac_1" => 'Прислужник - Монах',
	"uc_ac_2" => 'Прислужник - Священик',
	"uc_ac_3" => 'Лучник - Повелитель зверей',
	"uc_ac_4" => 'Лучник - Рейнджер',
	"uc_ac_5" => 'Маг - Волшебник',
	"uc_ac_6" => 'Маг - Колдун',
	"uc_ac_7" => 'Мечник - Рыцарь',
	"uc_ac_8" => 'Мечник - Воин',
	"uc_ac_9" => 'Вор - Убийца',
	"uc_ac_10" => 'Вор - Разбойник',
	"uc_job_0" => '-',
	"uc_job_1" => 'Алхимик',
	"uc_job_2" => 'Портной',
	"uc_job_3" => 'Кузнец',
	"uc_job_4" => 'Повар',
	),
	
);

?>