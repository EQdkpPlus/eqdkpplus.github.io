<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2019-11-11 18:52
//File: games/eq2/language/russian.php
//Source-Language: english

$russian_array = array( 
	"classes" => array(
	0 => 'Неизвестно',
	1 => 'Убийца',
	25 => 'Повелитель зверей',
	2 => 'Берсерк',
	3 => 'Разбойник',
	4 => 'Громила',
	26 => 'Медиум',
	5 => 'Гипнотизер',
	6 => 'Заклинатель',
	7 => 'Осквернитель',
	8 => 'Менестрель',
	9 => 'Фурия',
	10 => 'Страж',
	11 => 'Иллюзионист',
	12 => 'Инквизитор',
	13 => 'Монах',
	14 => 'Мистик',
	15 => 'Некромант',
	16 => 'Паладин',
	17 => 'Следопыт',
	18 => 'Темный рыцарь',
	19 => 'Головорез',
	20 => 'Храмовник',
	21 => 'Трубадур',
	22 => 'Хранитель',
	23 => 'Чернокнижник',
	24 => 'Волшебник',
	),
	"races" => array(
	0 => 'Неизвестно',
	21 => 'Эйракин',
	18 => 'Арасай',
	4 => 'Варвар',
	7 => 'Темный эльф',
	5 => 'Дворф',
	14 => 'Эрудит',
	19 => 'Фея',
	20 => 'Вампир',
	13 => 'Фроглок',
	2 => 'Гном',
	9 => 'Полуэльф',
	17 => 'Полурослик',
	6 => 'Высший эльф',
	3 => 'Человек',
	15 => 'Иксар',
	10 => 'Керра',
	12 => 'Огр',
	16 => 'Ратонга',
	1 => 'Сарнак',
	11 => 'Тролль',
	8 => 'Лесной эльф',
	),
	"factions" => array(
	"good" => 'Добро',
	"evil" => 'Добро',
	"neutral" => 'Изгои',
	),
	"roles" => array(
	1 => 'Жрецы',
	2 => 'Воины',
	3 => 'Маги',
	4 => 'Разведчики',
	),
	"realmlist" => array(
	0 => 'Antonia Bayle',
	1 => 'Halls of Fate',
	2 => 'Maj\'Dul',
	3 => ' Skyfire',
	4 => 'Thurgadin',
	5 => 'Stormhold',
	6 => 'Тест',
	7 => 'Бета',
	),
	"lang" => array(
	"eq2" => 'EverQuest II',
	"very_light" => 'Ткань',
	"light" => 'Кожа',
	"medium" => 'Кольчуга',
	"heavy" => 'Латы',
	"healer" => 'Лекарь',
	"fighter" => 'Боец',
	"mage" => 'Маг',
	"scout" => 'Разведчик',
	"uc_gender" => 'Пол',
	"uc_male" => 'Мужской',
	"uc_female" => 'Женский',
	"uc_guild" => 'Гильдия',
	"uc_race" => 'Раса',
	"uc_class" => 'Класс',
	"uc_import_guild" => 'Импортировать гильдию',
	"uc_import_guild_help" => 'Импортировать всех персонажей в гильдии',
	"servername" => 'Название сервера',
	"uc_lockserver" => 'Запретить пользователям менять название сервера',
	"uc_update_all" => 'Обновить всех персонажей',
	"uc_importer_cache" => 'Очистить кэш импорта',
	"uc_importer_cache_help" => 'Удалить весь кэщ импорта',
	"achievements" => 'Достижения',
	"uc_class_filter" => 'Только персонажи этого класса',
	"uc_class_nofilter" => 'Без фильтра',
	"uc_guild_name" => 'Название гильдии',
	"uc_filter_name" => 'Фильтр',
	"uc_level_filter" => 'Все персонажи с уровнем выше, чем',
	"uc_imp_novariables" => 'Сначала укажите название сервера и его местонахождение',
	"uc_imp_noguildname" => 'Не указано название гильдии.',
	"uc_gimp_loading" => 'Загрузка персонажей в гильдии, пожалуйста, подождите...',
	"uc_gimp_header_fnsh" => 'Импорт гильдии завершён',
	"uc_importcache_cleared" => 'Кэш импорта успешно очищен.',
	"uc_delete_chars_onimport" => 'Удалить всех персонажей, покинувших гильдию',
	"uc_achievements" => 'Достижения',
	"uc_critchance" => 'Минимальное требование критического удара',
	"core_sett_f_uc_resists" => 'Минимальное требование стойкости',
	"gachievements" => 'Достижения гильдии',
	"graidready" => 'Готовность рейда',
	"heraldry" => 'Символика гильдии',
	"uc_noprofile_found" => 'Профиль не найден',
	"uc_profiles_complete" => 'Профили успешно обновлены',
	"uc_notyetupdated" => 'Нет новых данных (персонаж неактивен)',
	"uc_notactive" => 'Персонаж не будет обработан, т.к. помечен, как неактивный',
	"uc_error_with_id" => 'Ошибка ID персонажа',
	"uc_notyourchar" => 'ВНИМАНИЕ: Вы пытаетесь импортировать персонажа, который уже существует в БД, но не принадлежит вам. Для решения проблемы свяжитесь с администратором или укажите другое имя.',
	"uc_lastupdate" => 'Последнее обновление',
	"uc_prof_import" => 'импорт',
	"uc_import_forw" => 'продолжить',
	"uc_imp_succ" => 'Данные успешно импортированы',
	"uc_upd_succ" => 'Данные успешно обновлены',
	"uc_imp_failed" => 'Ошибка при обновлении данных. Попробуйте повторить процедуру.',
	"uc_updat_armory" => 'Refresh from Daybreak',
	"uc_charname" => 'Имя персонажа',
	"uc_charfound" => 'Персонаж <b>%1$s</b> был найден в оружейной.',
	"uc_charfound2" => 'Этот персонаж был обновлен  <b>%1$s</b>.',
	"uc_charfound3" => 'ВНИМАНИЕ: импорт перезапишет все существующие данные!',
	"uc_armory_confail" => 'Нет подключения к оружейной. Данные не переданы.',
	"uc_armory_imported" => 'Импортировано',
	"uc_armory_impfailed" => 'Ошибка',
	"uc_armory_impduplex" => 'уже существует',
	"eqclassic" => 'The Shattered Lands',
	"splitpaw" => 'The Splitpaw Saga',
	"desert" => 'Desert of Flames',
	"kingdom" => 'Kingdom of Sky',
	"fallen" => 'The Fallen Dynasty',
	"faydwer" => 'Echoes of Faydwer',
	"kunark" => 'Rise of Kunark',
	"shadow" => 'The Shadow Odyssey',
	"sentinel" => 'Sentinel\'s of Fate',
	"velious" => 'Destiny of Velious',
	"chains" => 'Chains of Eternity',
	"tears" => 'Tears of Veeshan',
	"malice" => 'Altar of Malice',
	"general" => 'Общее',
	"avatar" => 'Аватары',
	"rum" => 'F.S. Distillery',
	"tot" => 'Ужасы Таламбры',
	"zek" => 'Зек, Пустоши Бедствия',
	"kas" => 'Вознесение Кунарка',
	"healermage" => 'Жрец и Маг',
	"fighterscout" => 'Воин и Разведчик',
	"no_data" => 'Нет данных.',
	"total_completed" => 'Итого завершено',
	"uc_level" => 'Уровень',
	"uc_showachieve" => 'Показать Достижения гильдии на главной странице? (Может увеличить время загрузки)',
	"core_sett_fs_gamesettings" => 'Настройки EverQuest II',
	"uc_faction" => 'Фракция',
	"uc_faction_help" => 'Выберите фракцию по умолчанию',
	),
	
);

?>