<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2019-11-11 18:52
//File: games/fw/language/russian.php
//Source-Language: english

$russian_array = array( 
	"classes" => array(
	0 => 'Неизвестно',
	1 => 'Воин',
	2 => 'Защитник',
	3 => 'Убийца',
	4 => 'Стрелок',
	5 => 'Маг',
	6 => 'Жрец',
	7 => 'Вампир',
	8 => 'Бард',
	9 => 'Жнец',
	10 => 'Душегуб',
	11 => 'Ranger',
	12 => 'Warden',
	13 => 'Dragoon',
	),
	"races" => array(
	0 => 'Неизвестно',
	1 => 'Дворф',
	2 => 'Эльф',
	3 => 'Человек',
	4 => 'Киндред',
	5 => 'Стоунмен',
	6 => 'Веспериан',
	7 => 'Демон',
	),
	"roles" => array(
	1 => 'Лекарь',
	2 => 'Танк',
	3 => 'Боец',
	4 => 'Поддержка',
	),
	"lang" => array(
	"fw" => 'Forsaken World',
	"plate" => 'Латы',
	"heavy" => 'Тяжелая броня',
	"light" => 'Ткань',
	"medium" => 'Легкая броня',
	"uc_gender" => 'Пол',
	"uc_male" => 'Мужской',
	"uc_female" => 'Женский',
	"uc_guild" => 'Гильдия',
	"uc_race" => 'Раса',
	"uc_class" => 'Класс',
	"core_sett_fs_gamesettings" => 'Настройки Forsaken World',
	),
	
);

?>