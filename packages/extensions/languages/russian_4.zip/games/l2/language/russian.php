<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2019-11-11 18:52
//File: games/l2/language/russian.php
//Source-Language: english

$russian_array = array( 
	"classes" => array(
	0 => 'Неизвестно',
	1 => 'Лучник',
	2 => 'Заклинатель',
	3 => 'Целитель',
	4 => 'Рыцарь',
	5 => 'Разбойник',
	6 => 'Призыватель',
	7 => 'Воин',
	8 => 'Волшебник',
	),
	"races" => array(
	0 => 'Неизвестно',
	1 => 'Тёмный эльф',
	2 => 'Гном',
	3 => 'Эльф',
	4 => 'Человек',
	5 => 'Камаэль',
	6 => 'Орк',
	),
	"roles" => array(
	1 => 'Целитель',
	2 => 'Танк',
	3 => 'Боец',
	4 => 'Поддержка',
	),
	"lang" => array(
	"l2" => 'Lineage II',
	"plate" => 'Латы',
	"heavy" => 'Тяжёлая броня',
	"light" => 'Ткань',
	"medium" => 'Кожа',
	"uc_gender" => 'Пол',
	"uc_male" => 'Мужской',
	"uc_female" => 'Женский',
	"uc_guild" => 'Гильдия',
	"uc_class_path" => 'Путь класса',
	"uc_race" => 'Раса',
	"uc_class" => 'Класс',
	"uc_level" => 'Уровень',
	"uc_path_1" => 'Воин',
	"uc_path_2" => 'Солдат',
	"uc_path_3" => 'Мистик',
	"uc_path_4" => 'Разбойник',
	"uc_path_5" => 'Разведчик',
	"uc_path_6" => 'Ассасин',
	"uc_path_7" => 'Надзиратель',
	"uc_path_8" => 'Клерик',
	"uc_path_9" => 'Рыцарь',
	"uc_path_10" => 'Шаман',
	"uc_path_11" => 'Оракл',
	"uc_path_12" => 'Собиратель',
	"uc_path_13" => 'Волшебник',
	"uc_path_14" => 'Воин',
	"uc_path_15" => 'Ремесленник ',
	"uc_path_16" => 'Налетчик',
	"uc_path_17" => 'Монах',
	"uc_path_18" => 'Солдат',
	"uc_path_19" => 'Снайпер',
	"uc_path_20" => 'Серебряный Рейнджер',
	"uc_path_21" => 'Призрачный Рейнджер',
	"uc_path_22" => 'Арбалетчик',
	"uc_path_23" => 'Проповедник',
	"uc_path_24" => 'Менестрель',
	"uc_path_25" => 'Танцор смерти',
	"uc_path_26" => 'Верховный шаман',
	"uc_path_27" => 'Вестник Войны',
	"uc_path_28" => 'Инспектор',
	"uc_path_29" => 'Еписком',
	"uc_path_30" => 'Мудрец евы',
	"uc_path_31" => 'Паладин',
	"uc_path_32" => 'Мститель',
	"uc_path_33" => 'Рыцарь Евы',
	"uc_path_34" => 'Рыцарь Шилен',
	"uc_path_35" => 'Кладоискатель',
	"uc_path_36" => 'Следопыт',
	"uc_path_37" => 'Странник Бездны',
	"uc_path_38" => 'Охотник За Наградой',
	"uc_path_39" => 'Чернокнижник',
	"uc_path_40" => 'Последователь стихий',
	"uc_path_41" => 'Последователь тьмы',
	"uc_path_42" => 'Копейщик',
	"uc_path_43" => 'Гладиатор',
	"uc_path_44" => 'Кузнец',
	"uc_path_45" => 'Разрушитель',
	"uc_path_46" => 'Деспот',
	"uc_path_47" => 'Берсерк',
	"uc_path_48" => 'Волшебник',
	"uc_path_49" => 'Некромант 	',
	"uc_path_50" => 'Певец заклинаний',
	"uc_path_51" => 'Заклинатель ветра',
	"uc_path_52" => 'Палач',
	"uc_path_53" => 'Стрелок',
	"uc_path_54" => ' 	Страж Лунного Света',
	"uc_path_55" => 'Страж Теней',
	"uc_path_56" => 'Диверсант',
	"uc_path_57" => 'Апостол',
	"uc_path_58" => 'Виртуоз',
	"uc_path_59" => 'Призрачный Танцор',
	"uc_path_60" => 'Деспот',
	"uc_path_61" => 'Глас судьбы',
	"uc_path_62" => 'Арбитр',
	"uc_path_63" => 'Кардинал',
	"uc_path_64" => 'Рыцарь Евы',
	"uc_path_65" => 'Мудрец Шилен',
	"uc_path_66" => ' 	Рыцарь Феникса',
	"uc_path_67" => 'Рыцарь ада',
	"uc_path_68" => 'Храмовник Евы',
	"uc_path_69" => 'Жрец Шилен',
	"uc_path_70" => 'Авантюрист',
	"uc_path_71" => 'Странник Ветра',
	"uc_path_72" => 'Призрачный Охотник',
	"uc_path_73" => 'Кладоискатель',
	"uc_path_74" => 'Чернокнижник',
	"uc_path_75" => 'Мастер стихий',
	"uc_path_76" => 'Владыка теней',
	"uc_path_77" => 'Полководец',
	"uc_path_78" => 'Дуэлист 	',
	"uc_path_79" => 'Виртуоз',
	"uc_path_80" => 'Титан',
	"uc_path_81" => 'Аватар',
	"uc_path_82" => 'Каратель',
	"uc_path_83" => 'Архимаг',
	"uc_path_84" => 'Пожиратель душ',
	"uc_path_85" => 'Магистр магии',
	"uc_path_86" => 'Повелитель бури',
	"uc_path_87" => 'Инквизитор',
	"uc_path_88" => 'Лучник Эура',
	"uc_path_89" => 'Заклинатель Иса',
	"uc_path_90" => 'Целитель Альгиза',
	"uc_path_91" => 'Рыцарь Сигеля',
	"uc_path_92" => 'Разбойник Одала ',
	"uc_path_93" => 'Призыватель Веньо',
	"uc_path_94" => 'Воин Тира',
	"uc_path_95" => 'Волшебник Фео',
	),
	
);

?>