<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2019-11-11 18:52
//File: games/nwo/language/russian.php
//Source-Language: english

$russian_array = array( 
	"classes" => array(
	0 => 'Неизвестно',
	1 => 'Бесстрашный воин',
	2 => 'Истовый Клирик',
	3 => 'Плут-ловкач',
	4 => 'Волшебник-повелитель',
	5 => 'Воин-страж',
	6 => 'Охотник-следопыт',
	),
	"races" => array(
	0 => 'Неизвестно',
	1 => 'Дроу',
	2 => 'Дворф',
	3 => 'Лесной эльф',
	4 => 'Полуэльф',
	5 => 'Полурослик',
	6 => 'Человек',
	7 => 'Тифлинг',
	8 => 'Мензоберранзанский ренегат',
	9 => 'Лунный эльф',
	10 => 'Солнечный эльф',
	11 => 'Полуорк',
	),
	"lang" => array(
	"nwo" => 'Neverwinter Online',
	"plate" => 'Латы',
	"scale" => 'Масштаб',
	"heavy" => 'Тяжелая броня',
	"medium" => 'Кожа',
	"light" => 'Ткань',
	"uc_gender" => 'Пол',
	"uc_male" => 'Мужской',
	"uc_female" => 'Женский',
	"uc_guild" => 'Гильдия',
	"uc_race" => 'Раса',
	"uc_class" => 'Класс',
	),
	
);

?>