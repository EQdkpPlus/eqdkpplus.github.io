<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2019-11-11 18:52
//File: language/russian/lang_mmode.php
//Source-Language: english

$lang = array( 
	"click2show" => '(нажмите, чтобы показать)',
	"maintenance_mode" => 'Режим технического обслуживания',
	"task_manager" => 'Диспетчер задач',
	"admin_acp" => 'Панель управления',
	"activate_info" => 'h1>Активировать режим техобслуживания</h1><br />С помощью этого инструмента обслуживания вы можете легко обновить свой EQdkp и импортировать данные из более старой версии.<br />Обновление или импорт возможны только в том случае, если включен режим обслуживания и закрыт вход пользователей в систему для предотвращения ошибок и проблем.<br /><br />Причина, показанная пользователям (необязательно):<br />',
	"activate_mmode" => 'Включить режим технического обслуживания',
	"deactivate_mmode" => 'Закрыть режим обслуживания',
	"leave_mmode" => 'Отмена',
	"home" => 'Главная',
	"no_leave" => 'Невозможно отключить режим обслуживания до тех пор, пока требуемые задачи не будут выполнены.',
	"no_leave_accept" => 'Назад к обзору задач',
	"maintenance_message" => '<b>Система EQdkp Plus в настоящее время работает в режиме технического обслуживания.</b> Вход в систему возможен только для администраторов.',
	"reason" => '<br /><b>Причина:</b>',
	"admin_login" => 'Вход администратора',
	"login" => 'Войти',
	"username" => 'Пользователь',
	"password" => 'Пароль',
	"remember_password" => 'Запомнить пароль?',
	"invalid_login_warning" => 'Ошибка! Пожалуйста, проверьте правильность введённых данных. Войти в систему могут только администраторы!',
	"is_necessary" => 'Обязательно?',
	"is_applicable" => 'Подходит?',
	"name" => 'Название',
	"version" => 'Версия',
	"author" => 'Автор',
	"link" => 'Задача процессов',
	"description" => 'Описание',
	"type" => 'Тип задачи',
	"yes" => 'Да',
	"no" => 'Нет',
	"click_me" => 'Задача процессов',
	"mmode_info" => 'Ваша система в данный момент находится в режиме обслуживания и отказывает в доступе обычным пользователям, пока вы не отключите режим обслуживания.',
	"necessary_tasks" => 'Необходимые задачи',
	"applicable_tasks" => 'Не обязательные/обработанные задачи',
	"not_applicable_tasks" => 'Завершенные задачи',
	"no_nec_tasks" => 'Нет необходимых задач.',
	"nec_tasks" => 'Необходимо выполнить следующие задачи. Пожалуйста, обработайте их, чтобы привести вашу систему в актуальное состояние.',
	"nec_tasks_available" => 'Пожалуйста, выполните необходимые задачи чтобы довести систему до актуального состояния.',
	"applicable_warning" => 'Недопустимая задача! Выполнение данной задачи может привести к потере данных! Запускайте данную задачу, только если вы абсолютно уверены!',
	"executed_tasks" => 'Следующие действия были выполнены в рамках задачи "%s"',
	"stepend_info" => 'Задача была выполнена. EQdkp Plus еще находится в режиме технического обслуживания, поэтому вы можете все протестировать. Только после закрытия режима техобслуживания, пользователи снова смогут авторизоватся.',
	"mmode_pfh_error" => 'Произошли некоторые ошибки. Вы должны исправить эти ошибки, чтобы закрыть режим обслуживания.',
	"lib_cache_notwriteable" => 'Невозможно записать в папку "Data". Пожалуйста, установите разрешения папки CHMOD 777!',
	"fix" => 'Исправления',
	"update" => 'Обновление ядра',
	"import" => 'Импорт',
	"plugin_update" => 'Обновление плагинов',
	"game_update" => 'Обновление игр',
	"worker" => 'Worker',
	"unknown_task_warning" => 'Неизвестная задача!',
	"application_warning" => 'Не удалось обработать задание из-за ошибки приложения!',
	"dependency_warning" => 'Эта задача зависит от других. Пожалуйста, обрабатывайте ее в первую очередь!',
	"start_here" => 'Начать здесь!',
	"following_updates_necessary" => 'Необходимо выполнить следующие обновления:',
	"start_update" => 'Выполните все необходимые обновления!',
	"only_this_update" => 'Обновлены только данные процессы:',
	"start_single_update" => 'Процесс обновления',
	"backup" => 'Резервная копия базы данных',
	"backup_note" => 'Резервная копия базы данных была создана в  %s.',
	"support_eqdkplus" => 'Такой проект, как EQdkp Plus может существовать только если мы получаем что-то взамен потраченного нами времени, усилий и внимания, которые мы инвестируем в разработку. Вы можете отблагодарить нас одним из следующих способов: <ul> <li><i class="fa fa-puzzle-piece"></i> <a href="http://eqdkp-plus.eu/repository/">Опубликовать плагин или шаблон, чтобы каждый пользователь EQdkp Plus мог воспользоваться ими</a></li> <li><i class="fa fa-comments"></i> <a href="http://eqdkp-plus.eu/forum/">Поддержать нас на форуме</a></li> <li><i class="fa fa-cogs"></i> <a href="http://eqdkp-plus.eu/en/development.html">Принять активное участие в разработке</a></li> <li><i class="fa fa-usd"></i> <a href="http://eqdkp-plus.eu/en/donate.html">Поддержать нас финансово, чтобы мы могли и впредь развивать нашу систему</a></li> </ul> Если вам нравится EQdkp Plus так же, как нам - поддержите нас!',
	
);

?>