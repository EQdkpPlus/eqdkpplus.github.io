<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2019-08-22 13:35
//File: games/daoc/language/french.php
//Source-Language: english

$french_array = array( 
	"classes" => array(
	0 => 'Inconnue',
	1 => 'Animiste',
	2 => 'Maître d\'armes',
	3 => 'Bainshee',
	4 => 'Barde',
	5 => 'Berserker',
	6 => 'Finelame',
	7 => 'Prêtre de Bogdar',
	8 => 'Cabaliste',
	9 => 'Champion',
	10 => 'Clerc',
	11 => 'Druide',
	12 => 'Eldritch',
	13 => 'Enchanteur',
	14 => 'Moine',
	15 => 'Guérisseur',
	16 => 'Hérétique',
	17 => 'Protecteur',
	18 => 'Chasseur',
	19 => 'Sicaire',
	20 => 'Empathe',
	21 => 'Mercenaire',
	22 => 'Ménestrel',
	23 => 'Nécromancien',
	24 => 'Ombre',
	25 => 'Paladin',
	26 => 'Ranger',
	27 => 'Fléau d\'Arawn',
	28 => 'Prêtre d\'Odin',
	29 => 'Sauvage',
	30 => 'Eclaireur',
	31 => 'Assassin',
	32 => 'Chaman',
	33 => 'Skald',
	34 => 'Sorcier',
	35 => 'Prêtre de Hel',
	36 => 'Thane',
	37 => 'Théurgiste',
	38 => 'Faucheur',
	39 => 'Valkyrie',
	40 => 'Séide de Leanansidhe',
	41 => 'Sentinelle',
	42 => 'Helhaxa',
	43 => 'Guerrier',
	44 => 'Thaumaturge',
	),
	"races" => array(
	0 => 'Inconnue',
	1 => 'Avalonien',
	2 => 'Breton',
	3 => 'Demi-ogre',
	4 => 'Highlander',
	5 => 'Nécrite',
	6 => 'Sarrasin',
	7 => 'Celte',
	8 => 'Elfe',
	9 => 'Firbolg',
	10 => 'Lurikeen',
	11 => 'Shar',
	12 => 'Sylvain',
	13 => 'Nain',
	14 => 'Frostalf',
	15 => 'Kobold',
	16 => 'Viking',
	17 => 'Troll',
	18 => 'Valkyn',
	19 => 'Minotaure',
	),
	"factions" => array(
	"albion" => 'Albion',
	"hibernia" => 'Hibernia',
	"midgard" => 'Midgard',
	),
	"lang" => array(
	"daoc" => 'Dark Age of Camelot',
	"uc_race" => 'Race',
	"uc_class" => 'Classe',
	"core_sett_fs_gamesettings" => 'Paramètres de Dark Age of Camelot',
	"uc_faction" => 'Faction',
	"uc_faction_help" => 'Choisissez la faction par défaut',
	),
	
);

?>