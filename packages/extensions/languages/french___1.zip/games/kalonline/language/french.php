<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2019-08-22 13:35
//File: games/kalonline/language/french.php
//Source-Language: english

$french_array = array( 
	"classes" => array(
	0 => 'Inconnue',
	1 => 'Voleur',
	2 => 'Chevalier',
	3 => 'Magicien',
	4 => 'Archer',
	),
	"races" => array(
	0 => 'Inconnue',
	1 => 'Humain',
	),
	"roles" => array(
	1 => array(
	0 => '3',
	),
	2 => array(
	0 => '2',
	),
	3 => array(
	0 => '2',
	1 => '3',
	),
	4 => array(
	0 => '1',
	1 => '4',
	),
	5 => array(
	0 => '1',
	1 => '4',
	),
	),
	"lang" => array(
	"kalonline" => 'KalOnline',
	"role1" => 'Guérisseur',
	"role2" => 'Tank',
	"role3" => 'Attaquent',
	"role4" => 'Débuffeur',
	"role5" => 'Dégat',
	"uc_race" => 'Race',
	"uc_class" => 'Classe',
	"core_sett_fs_gamesettings" => 'Paramètres de KalOnline',
	),
	
);

?>