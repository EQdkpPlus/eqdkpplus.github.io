<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2019-08-22 13:35
//File: games/rift/language/french.php
//Source-Language: english

$french_array = array( 
	"classes" => array(
	0 => 'Inconnu',
	1 => 'Guerrier',
	2 => 'Voleur',
	3 => 'Clerc',
	4 => 'Mage',
	5 => 'Primaliste',
	),
	"races" => array(
	0 => 'Inconnu',
	1 => 'Mathosien',
	2 => 'Haut-Elfes',
	3 => 'Nains',
	4 => 'Bahmi',
	5 => 'Eth',
	6 => 'Kelari',
	7 => 'Elus',
	),
	"factions" => array(
	"default" => 'Défaut',
	"guardians" => 'Les Gardiens',
	"defiant" => 'Les Renégats',
	),
	"roles" => array(
	1 => 'Guérisseur',
	2 => 'Tank',
	3 => 'DPS',
	4 => 'Support',
	),
	"lang" => array(
	"rift" => 'RIFT',
	"plate" => 'Plaque',
	"heavy" => 'Lourde',
	"light" => 'Tissu',
	"medium" => 'Cuir',
	"import_ranks" => 'Importer le classement',
	"guild_xml" => 'Guilde-XML',
	"uc_import_forw" => 'Importer',
	"uc_import_guild" => 'Import/Update Guild',
	"uc_import_guild_help" => 'Import/Update all Guild-Members with a Guild-XML-File',
	"guild_xml_lang" => 'Language de Guilde-XML',
	"uc_gimp_header_fnsh" => 'Les données ont été correctement importées. Cette fenêtre peut être fermée.',
	"import_status_true" => 'Imported/Updated',
	"import_status_false" => 'Erreur',
	"guild_xml_error" => 'Le fichier XML de Guilde n\'est pas valide.',
	"uc_delete_chars_onimport" => 'Supprimer les personnages qui ont quitté la guilde',
	"uc_race" => 'Race',
	"uc_class" => 'Classe',
	"core_sett_fs_gamesettings" => 'Paramètres RIFT',
	"uc_faction" => 'Faction',
	"uc_faction_help" => 'Sélectionner la faction par défaut',
	),
	
);

?>