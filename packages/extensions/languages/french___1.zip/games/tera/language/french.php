<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2019-08-22 13:35
//File: games/tera/language/french.php
//Source-Language: english

$french_array = array( 
	"classes" => array(
	0 => 'Inconnue',
	1 => 'Archer',
	2 => 'Berserker',
	3 => 'Lancier',
	4 => 'Mystique',
	5 => 'Prêtre',
	6 => 'Pourfandeur',
	7 => 'Sorcier',
	8 => 'Guerrier',
	9 => 'Faucheuse',
	),
	"races" => array(
	0 => 'Inconnue',
	1 => 'Aman',
	2 => 'Baraka',
	3 => 'Castanic',
	4 => 'Haut-Elfe',
	5 => ' Humain',
	6 => 'Popori',
	7 => 'Baraka',
	),
	"roles" => array(
	1 => 'Défense',
	2 => 'Mélée offensive',
	3 => 'Distance offensive',
	4 => 'Soutien',
	),
	"lang" => array(
	"tera" => 'Tera Online',
	"uc_race" => 'Race',
	"uc_class" => 'Classe',
	"tera_event_bastion" => 'Bastion de Lok',
	"tera_event_sinestral" => 'Manoir sinistre',
	"tera_event_cultistrefuge" => 'Refuge des cultistes',
	"tera_event_necromancer" => 'Tombe du Nécromancien',
	"tera_event_sigiladstringo" => 'Sceau d\'Adstringo',
	"tera_event_goldenlaby" => 'Labyrinthe d’or',
	"tera_event_akashashide" => 'Repaire d\'Akasha',
	"tera_event_acentsaravash" => 'Ascension de Saravash',
	"tera_event_saleronsky" => 'Jardin céleste de Saleron',
	"tera_event_suryatis" => 'Pic de Suryati',
	"tera_event_ebontower" => 'Tour d\'ébène',
	"tera_event_labyterror" => 'Labyrinthe de la terreur',
	"tera_event_kelsaiksnest" => 'Nid de Kelsaik',
	"tera_event_fanekaprima" => 'Temple de Kaprima',
	"tera_event_balderstemple" => 'Temple de Balder',
	"tera_event_templetemerity" => 'Temple de la témérité',
	"tera_event_sirjukas" => 'Galerie de Sirjuka',
	"tera_event_crucibleflame" => 'Creuset de la flamme',
	"tera_event_argoncorpus" => 'Corpus Argon',
	"tera_event_manayascore" => 'Noyau de Manaya',
	"tera_event_layansprison" => 'La Prison de Lakan',
	"tera_event_ghillieglade" => 'Clairière dérobée',
	),
	
);

?>