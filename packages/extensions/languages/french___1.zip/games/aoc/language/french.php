<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2019-08-22 13:35
//File: games/aoc/language/french.php
//Source-Language: english

$french_array = array( 
	"classes" => array(
	0 => 'Inconnue',
	1 => 'Assassin',
	2 => 'Barbare',
	3 => 'Eclaireur',
	4 => 'Conquérant',
	5 => 'Templier Noir',
	6 => 'Gardien',
	7 => 'Démonologue',
	8 => 'Hérault de Xolti',
	9 => 'Nécromancien',
	10 => 'Chaman Ours',
	11 => 'Prêtre de Mitra',
	12 => 'Fléau de Set',
	),
	"races" => array(
	0 => 'Inconnue',
	1 => 'Aquiloniens',
	2 => 'Cimmériens',
	3 => 'Stygiens',
	4 => 'Khitan',
	),
	"roles" => array(
	0 => 'Unknown',
	1 => 'Soldier',
	2 => 'Priest',
	3 => 'Rogue',
	4 => 'Mage',
	),
	"factions" => array(
	"good" => 'Bien',
	"evil" => 'Mal',
	),
	"lang" => array(
	"aoc" => 'Age of Conan',
	"uc_race" => 'Race',
	"uc_class" => 'Classe',
	"core_sett_fs_gamesettings" => 'Réglages d\'Age of Conan',
	"uc_faction" => 'Faction',
	"uc_faction_help" => 'Choisissez la faction par défaut',
	),
	
);

?>