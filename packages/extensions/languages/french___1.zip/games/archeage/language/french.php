<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2019-08-22 13:35
//File: games/archeage/language/french.php
//Source-Language: english

$french_array = array( 
	"classes" => array(
	0 => 'Inconnue',
	1 => 'Tank',
	2 => 'Guérisseur',
	3 => 'Soutien',
	4 => 'Mélée',
	5 => 'Distant',
	),
	"races" => array(
	0 => 'Inconnue',
	1 => 'Nuien',
	2 => 'Elfe',
	3 => 'Harani',
	4 => 'Firran',
	),
	"lang" => array(
	"archeage" => 'ArcheAge',
	"uc_gender" => 'Sexe',
	"uc_male" => 'Mâle',
	"uc_female" => 'Femelle',
	"uc_guild" => 'Guilde',
	"uc_ability_1" => '1. Capacité',
	"uc_ability_2" => '2. Capacité',
	"uc_ability_3" => '3. Capacité',
	"uc_race" => 'Race',
	"uc_class" => 'Classe',
	"core_sett_fs_gamesettings" => 'Paramètres d\'ArcheAge',
	"uc_faction" => 'Faction',
	"uc_faction_help" => 'Choisissez la faction par défaut',
	"uc_ab_0" => '-',
	"uc_ab_1" => 'Art des guerriers',
	"uc_ab_2" => 'Art des sorciers',
	"uc_ab_3" => 'Art des protecteurs',
	"uc_ab_4" => 'Art des spirites',
	"uc_ab_5" => 'Art des nécromants',
	"uc_ab_6" => 'Art des archers',
	"uc_ab_7" => 'Art des mages',
	"uc_ab_8" => 'Art des assassins',
	"uc_ab_9" => 'Art des virtuoses',
	"uc_ab_10" => 'Art des animistes',
	),
	
);

?>