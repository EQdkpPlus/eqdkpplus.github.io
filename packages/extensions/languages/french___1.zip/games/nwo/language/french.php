<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2019-08-22 13:35
//File: games/nwo/language/french.php
//Source-Language: english

$french_array = array( 
	"classes" => array(
	0 => 'Inconnue',
	1 => 'Guerrier Offensif',
	2 => 'Prêtre Dévoué',
	3 => 'Voleur Fourbe',
	4 => 'Magicien Manipulateur',
	5 => 'Guerrier défensif',
	6 => 'Rôdeur Archer',
	),
	"races" => array(
	0 => 'Inconnue',
	1 => 'Drow',
	2 => 'Nain',
	3 => 'Elfe des bois',
	4 => 'Demi-Elfe',
	5 => 'Halfelin',
	6 => 'Humain',
	7 => 'Tieffelin',
	8 => 'Renégat de Menzoberranzan',
	9 => 'Elfe de la lune',
	10 => 'Elfe du Soleil',
	11 => 'Demi-Orc',
	),
	"lang" => array(
	"nwo" => 'Neverwinter Online',
	"plate" => 'Plaque',
	"scale" => 'Écaille',
	"heavy" => 'Lourde',
	"medium" => 'Cuir',
	"light" => 'Tissu',
	"uc_gender" => 'Sexe',
	"uc_male" => 'Mâle',
	"uc_female" => 'Femelle',
	"uc_guild" => 'Guilde',
	"uc_race" => 'Race',
	"uc_class" => 'Classe',
	),
	
);

?>