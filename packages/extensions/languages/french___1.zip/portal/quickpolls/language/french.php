<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2019-08-22 13:35
//File: portal/quickpolls/language/french.php
//Source-Language: english

$lang = array( 
	"quickpolls" => 'Sondage rapide',
	"quickpolls_name" => 'Sondage rapide',
	"quickpolls_desc" => 'Créer un sondage',
	"quickpolls_f_title" => 'Titre du sondage',
	"quickpolls_f_question" => 'Description',
	"quickpolls_f_question_help" => 'Les descriptions et questions de ce Sondage rapide apparaîtront sous le titre',
	"quickpolls_f_closedate" => 'Visible jusqu\'à',
	"quickpolls_f_help_closedate" => 'Passé cette date, les votes ne seront plus possibles et seuls les résultats seront visibles.',
	"quickpolls_f_showresults" => 'Liens des résultats',
	"quickpolls_f_help_showresults" => 'Les résultats seront visibles, indépendament du statut des votes',
	"quickpolls_f_showstatistics" => 'Afficher les statistiques en dessous des résultats',
	"quickpolls_f_help_showstatistics" => 'Inclus le nombre de vote reçu au total et pour chaque option ainsi que le nombre des participants (Hors visiteurs)',
	"quickpolls_f_options" => 'Options',
	"quickpolls_f_help_options" => 'Insérer une option par ligne',
	"quickpolls_f_resetvotes" => 'Réinitialiser les votes',
	"quickpolls_vote" => 'Voter',
	"quickpolls_resuls" => 'Résultats',
	"quickpolls_total_votes" => 'Total des votes',
	"quickpolls_participants" => 'Participants (Hors visiteurs)',
	"quickpolls_f_multiple" => 'Autoriser plusieurs choix',
	
);

?>