<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2019-08-22 13:35
//File: plugins/shoutbox/language/french/lang_main.php
//Source-Language: english

$lang = array( 
	"shoutbox" => 'Chat',
	"sb_shoutbox" => 'Chat',
	"shoutbox_name" => 'Chat',
	"shoutbox_desc" => 'Chat est un Plugin permettant aux utilisateurs de s\'échanger de courts messages.',
	"sb_short_desc" => 'Chat',
	"sb_long_desc" => 'Chat est un Plugin permettant aux utilisateurs de s\'échanger de courts messages.',
	"sb_plugin_not_installed" => 'Le Plugin Chat n\'est pas installé',
	"sb_php_version" => 'Le Chat requiert PHP %1$s ou supérieur. Votre serveur utilise PHP %2$s',
	"sb_plus_version" => 'Le Chat requiert EQDKP-PLUS %1$s ou supérieur. Votre serveur installée est %2$s',
	"sb_no_view_permission" => 'Vous n\'avez pas la permission de lire le Chat.',
	"sb_manage_archive" => 'Gérer les archives',
	"sb_written_by" => 'écrit par',
	"sb_written_at" => 'à',
	"sb_delete_success" => 'Messages supprimés avec succès',
	"sb_settings_info" => 'Further Shoutbox settings could be found within the <a href='.registry::get_const('root_path').'admin/manage_portal.php'.registry::get_const('SID').'">Portalmodule settings</a>',
	"sb_use_users" => 'Utiliser les noms d\'utilisateurs à la place des noms des membres',
	"sb_use_users_help" => 'On changing membernames to usernames all entries will be updated.<br/>On changing usernames to membernames all entries will be deleted!',
	"sb_convert_member_user_success" => 'Tous les noms de membres et leurs messages ont été mis à jour vers les noms d\'utilisateurs.',
	"sb_convert_user_member_success" => 'Tous les messages ont été supprimés.',
	"sb_config_saved" => 'Paramètres sauvegardés',
	"sb_header_general" => 'Paramètres généraux du Chat',
	"sb_f_output_count_limit" => 'Nombre maximum de messages visibles
',
	"sb_show_date" => 'Montrer la date ?',
	"sb_f_show_archive" => 'Montrer les Archives ?',
	"sb_f_max_text_length" => 'Longueur maximale des messages',
	"sb_f_input_box_location" => 'Position de la zone de saisie',
	"sb_location_top" => 'Saisies au-dessus',
	"sb_location_bottom" => 'Saisie en-dessous',
	"sb_f_autoreload" => 'Nombre de secondes entre chaque rafraichissement automatique du Chat (Défaut 0 = Off)',
	"sb_f_help_autoreload" => 'Mettre à 0 pour désactiver le raffraîchissement automatique.',
	"sb_no_character_assigned" => 'Personne n\'est connecté pour l\'instant. Il faut au moins une personne de connectée pour pouvoir poster.',
	"sb_submit_text" => 'Envoyer',
	"sb_save_wait" => 'Enregistrement, patientez...',
	"sb_reload" => 'Recharger',
	"sb_no_entries" => 'Pas de message',
	"sb_archive" => 'Archive',
	"sb_shoutbox_archive" => 'Archive du Chat',
	"sb_missing_char_id" => 'L\'ID de membre entrée est invalide',
	"sb_missing_text" => 'Texte manquant à insérer',
	
);

?>