<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2019-08-22 13:35
//File: plugins/feedposter/language/french/lang_main.php
//Source-Language: english

$lang = array( 
	"feedposter" => 'FeedPoster',
	"feedposter_short_desc" => 'FeedPoster',
	"feedposter_long_desc" => 'FeedPoster publie automatiquement des données de flux RSS ou Atom.',
	"fp_manage_feeds" => 'Gestion des flux',
	"fp_plugin_not_installd" => 'Le module d\'extension FeedPoster n\'est pas installé.',
	"fp_new_feed" => 'Ajouter un flux',
	"fp_confirm_delete_feed" => 'Souhaitez-vous réellement supprimer les flux ? %s',
	"fp_url" => 'URL du flux',
	"fp_last_updated" => 'Dernière recherche de flux',
	"fp_last_status" => 'État de la dernière recherche',
	"fp_enable_suc" => 'Le flux %s a bien été activé',
	"fp_enable_nosuc" => 'Une erreur s\'est produite pendant l\'activation du flux %s',
	"fp_disable_suc" => 'Le flux %s a bien été désactivé',
	"fp_disable_nosuc" => 'Une erreur s\'est produite pendant la désactivation du flux %s',
	"fp_delete_suc" => 'Les flux sélectionnés ont bien été supprimés.',
	"fp_delete_nosuc" => 'Une erreur s\'est produite pendant la suppression des flux sélectionnés.',
	"fp_repeat_inveral" => array(
	600 => 'Toutes les 10 minutes',
	1200 => 'Toutes les 20 minutes',
	1800 => 'Toutes les 30 minutes',
	3600 => 'Toutes les 60 minutes',
	7200 => 'Toutes les 2 heures',
	21600 => 'Toutes les 6 heures',
	86400 => 'Toutes les 24 heures',
	),
	"fp_article_data" => 'Données d\'article',
	"fp_interval" => 'Fréquence de rafraichissement des flux',
	"fp_maxposts" => 'Nombre d\'entrées importées',
	"fp_maxlength" => 'Longueur maximum des entrées importées',
	"fp_maxposts_help" => 'Saisissez 0 pour tout importer',
	"fp_maxlength_help" => 'Saisissez 0 pour importer la totalité du texte',
	"fp_entries" => 'Entrées',
	"fp_chars" => 'Caractères',
	"fp_source" => 'Source',
	"fp_showdays" => 'Nombre de Jours pendant lequel les articles seront affichés',
	"fp_showdays_help" => 'Saisissez 0 pour les afficher en permanence',
	"fp_days" => 'Jours',
	"fp_remove_html" => 'Remove HTML',
	"fp_feed_info" => 'Seuls les flux dont le format RSS ou ATOM est valide seront acceptés. Les flux de format non valide peuvent perturber l\'affichage de vos pages. L\'API de récupération d\'EQdkp Plus peut également ramener les derniers articles d\'une autre installation d\'EQdkp Plus.',
	
);

?>