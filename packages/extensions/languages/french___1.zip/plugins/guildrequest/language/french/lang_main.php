<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2019-08-22 13:35
//File: plugins/guildrequest/language/french/lang_main.php
//Source-Language: english

$lang = array( 
	"guildrequest" => 'Recrutement',
	"guildrequest_short_desc" => 'Recrutement',
	"guildrequest_long_desc" => 'Recrutement est un plugin permettant de gérer les candidatures.',
	"gr_manage_form" => 'Gérer le formulaire',
	"gr_vote" => 'Voter',
	"gr_view" => 'Voir les candidatures',
	"gr_view_closed" => 'Voir les candidatures fermées',
	"gr_add" => 'Postuler',
	"gr_applications" => 'Open applications',
	"gr_archive" => 'Archive',
	"gr_internal_comment" => 'Ecrire un commentaire interne',
	"gr_comment" => 'Ecrire un commentaire public',
	"gr_plugin_not_installed" => 'Le plugin Recrutement n\'est pas installé',
	"gr_select_options" => 'Options (1 par ligne)',
	"gr_required" => 'Obligatoire',
	"gr_delete_selected_fields" => 'Supprimer les champs selectionnés',
	"gr_types" => array(
	0 => 'Ligne de texte',
	1 => 'Bloc de texte',
	2 => 'Menu déroulant',
	3 => 'Label de groupe',
	4 => 'Libellé',
	5 => 'Cases à cocher',
	6 => 'Boutons radio',
	7 => 'Éditeur',
	),
	"gr_add_field" => 'Ajouter un nouveau champ',
	"gr_delete_field" => 'Supprimer le champ',
	"gr_default_grouplabel" => 'Information',
	"gr_personal_information" => 'Informations personnelles',
	"gr_submit_request" => 'Soumettre la candidature',
	"gr_email_help" => 'Merci de fournir une adresse email valide. Celle-ci sera utilisée pour vous envoyer toutes les notifications concernant votre candidature.',
	"gr_activationmail_subject" => 'Activer votre candidature',
	"gr_viewlink_subject" => 'Votre candidature',
	"gr_request_success" => 'Votre candidature est enregistrée. Un email avec un lien vers cette page a été envoyé à votre adresse.',
	"gr_request_success_msg" => 'Votre candidature est enregistrée. Vous pouvez la suivre à n\'importe quel moment en utilisant le lien:',
	"gr_internal_comments" => 'Commentaires internes',
	"gr_newcomment_subject" => 'Nouveau commentaire sur votre candidature',
	"gr_status" => array(
	0 => 'Nouveau',
	1 => 'En cours',
	2 => 'Acceptée',
	3 => 'Rejetée',
	),
	"gr_status_text" => 'Your applications has the following status: <b>%s</b>',
	"gr_vote_button" => 'Voter',
	"gr_manage_request" => 'Gérer les candidatures',
	"gr_status_help" => 'Le candidat reçoit un email automatique pour un changement de statut. Pour ajouter quelque chose à cet email, merci d\'utiliser le champ suivant.',
	"gr_change_status" => 'Changer le statut',
	"gr_close" => 'Clôturer la candidature',
	"gr_open_request" => 'Ré-ouvrir la candidature',
	"gr_closed_subject" => 'Votre candidature a été clôturée',
	"gr_status_subject" => 'Votre candidature : changement de statut',
	"gr_footer" => 'found %1$s applications / %2$s per page',
	"gr_in_list" => 'Montrer dans la liste des candidatures',
	"gr_confirm_delete_requests" => 'Voulez-vous vraiment supprimer la candidature de %s ?',
	"gr_delete_selected_requests" => 'Supprimer les candidatures selectionnées',
	"gr_delete_success" => 'Les candidatures sélectionnées ont été correctement supprimées.',
	"gr_notification" => '%s new Applications/Comments',
	"gr_notification_open" => '%s candidature(s) ouverte(s)',
	"gr_mark_all_as_read" => 'Marquer toutes les candidatures comme lues',
	"gr_send_notification_mails" => 'Envoyer un email de notification pour chaque nouvelle candidature',
	"gr_closed" => 'Cette candidature est close.',
	"gr_notification_subject" => 'Nouvelle candidature',
	"gr_jgrowl_notifications" => 'Afficher les popups de notifications',
	"gr_viewrequest" => 'Voir la candidature',
	"gr_dependency" => 'Dépendance (Champs - Option)',
	"gr_customcheck_info" => 'You can add your own dependecy checks, if you select "_Custom" and enter your expression the field on the right.<br />Example: ((FIELD1 == "MyValueOne" && FIELD2 == "MyValueTwo") || FIELD3 == "MyValueThree")<br />Please not that the required-check will not work correctly for custom dependencies.',
	"user_sett_fs_guildrequest" => 'Recrutement',
	"user_sett_tab_guildrequest" => '<i class="fa fa-pencil-square-o"></i> GuildRequest',
	"gr_preview" => 'Aperçu',
	"gr_preview_info" => 'Cet aperçu est généré à partir du dernier formulaire sauvegardé. Pour obtenir le formulaire actuel, veuillez enregistrer votre formulaire modifié et cliquer sur le bouton d\'Aperçu en bas de la page.',
	"user_sett_f_ntfy_guildrequest_new_application" => 'Recrutement: Nouvelle candidature',
	"user_sett_f_ntfy_guildrequest_new_update" => 'Recrutement: Nouveau commentaire',
	"user_sett_f_ntfy_guildrequest_open_applications" => 'Recrutement: Ouverture des candidatures',
	"user_sett_f_ntfy_guildrequest_new_update_own" => 'Recrutement: Mises à jour de mes propres candidatures',
	"gr_notify_new_application" => '{PRIMARY} a ajouté une nouvelle candidature',
	"gr_notify_new_application_grouped" => '{PRIMARY} a ajouté une nouvelle candidature',
	"gr_notify_new_update" => 'La candidature de {ADDITIONAL} a été commentée',
	"gr_notify_new_update_grouped" => '{COUNT} candidatures ont été commentées',
	"gr_notify_new_update_own" => 'Votre candidature a été actualisée',
	"gr_notify_new_update_own_grouped" => 'Il y a eu {COUNT} actualisation de votre candidature',
	"gr_fs_general" => 'Général',
	"gr_f_create_account" => 'Créer un compte EQdkp Plus si la candidature est acceptée',
	"gr_f_help_create_account" => 'Cette option est disponible s\'il n\'existe pas de passerelle vers un CMS',
	"gr_f_archive" => 'Move all closed applications into an archive',
	"gr_f_help_archive" => 'This will pre-sort all closed applications for better overwiew',
	"gr_myapplications" => 'Mes candidatures',
	"plugin_statistics_guildrequest_applications" => 'Recrutement: Candidatures',
	"gr_voted_users" => 'The following users have already voted',
	
);

?>