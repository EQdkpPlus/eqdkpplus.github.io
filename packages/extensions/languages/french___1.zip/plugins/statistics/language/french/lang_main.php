<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2019-08-22 13:35
//File: plugins/statistics/language/french/lang_main.php
//Source-Language: english

$lang = array( 
	"statistics" => 'Statistiques',
	"sb_statistics" => 'Statistiques',
	"statistics_name" => 'Statistiques',
	"statistics_desc" => 'Montrer les statistiques de clics et de visites.',
	"st_f_view" => 'Choisissez les données à montrer',
	"st_short_desc" => 'Statistiques',
	"st_long_desc" => 'Enregistre les statistiques comme les visites et les clics',
	"st_plugin_not_installed" => 'Le plugins Statistique n\'est pas installé.',
	"st_view_statistics" => 'Montrer les statistiques',
	"st_clicks" => 'Clics',
	"st_visits" => 'Visites',
	"st_user_regs" => 'Nouveaux utilisateurs',
	"st_raidsignups" => 'Inscriptions aux événements du calendrier',
	"st_total" => 'Total',
	"st_today" => 'Aujourd\'hui',
	"st_records" => 'Enregistrements',
	"st_timerange" => 'Période',
	
);

?>