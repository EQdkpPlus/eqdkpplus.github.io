<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2019-08-22 13:35
//File: core/data_handler/includes/modules/read/member/language/french.php
//Source-Language: english

$module_lang = array(
	"name" => 'Nom',
	"editbutton" => '',
	"memberlink" => 'Nom',
	"memberlink_detail_twink" => 'Nom',
	"rankname" => 'Rang',
	"rankname_sortid" => 'Rang',
	"rankimage" => 'Image de rang',
	"rankname_detail_twink" => 'Rang',
	"active" => 'Etat',
	"active_detail_twink" => 'Etat',
	"classname" => 'Classe',
	"classname_detail_twink" => 'Classe',
	"racename" => 'Race',
	"racename_detail_twink" => 'Race',
	"level" => 'Niveau',
	"level_detail_twink" => 'Niveau',
	"twink" => 'Type',
	"twink_detail_twink" => 'Type',
	"mainname" => 'Main',
	"summed_up" => 'Total',
	"char_defrole" => 'Rôle par défaut',
	"member_menu" => '',
	"mainchar_radio" => '<i class="fa fa-star fa-lg not-sortable" title="Mainchar"></i>',
	"name_decorated" => 'Nom du personnage',
	"memberlink_decorated" => 'Nom du personnage',
	"last_update" => 'Dernière mise à jour',
	"defaultrole" => 'Rôle',
	"raidgroups" => 'Groupes de Raid',
	"picture" => 'Avatar',
	);
	$preset_lang = array(
	"mname" => 'Nom du personnage',
	"mlink" => 'Lien du personnage',
	"mlevel" => 'Niveau du personnage',
	"mrace" => 'Race du personnage',
	"mrank" => 'Rang du personnage',
	"mrankimg" => 'Image du rang du personnage',
	"mactive" => 'Statut de l\'activité du personnage',
	"mcname" => 'Nom de la classe du personnage',
	"mtwink" => 'Type de personnage',
	"mlink_dt" => 'Lien du personnage',
	"mlevel_dt" => 'Niveau du personnage',
	"mrace_dt" => 'Race du personnage',
	"mrank_dt" => 'Rang du personnage',
	"mactive_dt" => 'Statut de l\'activité du personnage',
	"mcname_dt" => 'Nom de la classe du personnage',
	"mlink_decorated" => 'Lien du personnage (decoré)',
	"last_update" => 'Dernière mise à jour du personnage',
	"medit" => 'Lien d\'édition du personnage',
	"cdefrole" => 'Sélection du rôle par défaut du personnage',
	"mrank_sortid" => 'Rang du personnage (trié par ID)',
	"charname" => 'Nom du personnage (décoré)',
	"mmainname" => 'Nom du personnage principal',
	"picture" => 'Image du personnage',
	"note" => 'Note du personnage',
	"muser" => 'Nom d\'utilisateur du personnage',
	"charmenu" => 'Menu du personnage',
	"cmainchar" => 'bouton radio personnage principal',
	"mrole" => 'Rôle du personnage',
	"mraidgroups" => 'Groupes de raid du personnage',
	);
	

?>