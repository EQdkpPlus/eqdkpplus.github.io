<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Spanish	
//Created by EQdkp Plus Translation Tool on  2019-08-22 13:41
//File: games/eq/language/spanish.php
//Source-Language: english

$spanish_array = array( 
	"classes" => array(
	0 => 'Unknown',
	1 => 'Bard',
	2 => 'Beastlord',
	3 => 'Berserker',
	15 => 'Cleric',
	16 => 'Druid',
	4 => 'Enchanter',
	5 => 'Magician',
	6 => 'Monk',
	7 => 'Necromancer',
	8 => 'Paladin',
	9 => 'Ranger',
	10 => 'Rogue',
	11 => 'Shadow Knight',
	12 => 'Shaman',
	13 => 'Warrior',
	14 => 'Wizard',
	),
	"races" => array(
	0 => 'Unknown',
	3 => 'Barbarian',
	6 => 'Dark Elf',
	16 => 'Drakkin',
	4 => 'Dwarf',
	14 => 'Erudite',
	12 => 'Froglok',
	1 => 'Gnome',
	15 => 'Halfling',
	8 => 'Half Elf',
	5 => 'High Elf',
	2 => 'Human',
	13 => 'Iksar',
	11 => 'Ogre',
	10 => 'Troll',
	9 => 'Vah Shir',
	7 => 'Wood Elf',
	),
	"lang" => array(
	"eq" => 'EverQuest',
	"tank" => 'Tank',
	"melee" => 'Melee',
	"priest" => 'Priest',
	"caster" => 'Caster',
	"uc_race" => 'Race',
	"uc_class" => 'Class',
	"uc_guild" => 'Guild',
	"uc_gender" => 'Gender',
	"uc_level" => 'Level',
	"uc_male" => 'Male',
	"uc_female" => 'Female',
	"core_sett_fs_gamesettings" => 'EverQuest Settings',
	"uc_faction" => 'Faction',
	"uc_faction_help" => 'Select the default faction',
	),
	
);

?>