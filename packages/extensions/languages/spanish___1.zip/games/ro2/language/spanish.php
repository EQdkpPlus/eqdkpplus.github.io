<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Spanish	
//Created by EQdkp Plus Translation Tool on  2019-08-22 13:41
//File: games/ro2/language/spanish.php
//Source-Language: english

$spanish_array = array( 
	"classes" => array(
	0 => 'Desconocido',
	1 => 'Acólito',
	2 => 'Arquero',
	3 => 'Mago',
	4 => 'Espadachín',
	5 => 'Ladrón',
	),
	"races" => array(
	0 => 'Desconocido',
	1 => 'Norman',
	2 => 'Ellr',
	3 => 'Dimago ',
	),
	"lang" => array(
	"ro2" => 'Ragnarok Online 2',
	"tank" => 'Tanque',
	"damage_dealer" => 'Damage Dealer',
	"healer" => 'Sanador',
	"uc_gender" => 'Género',
	"uc_male" => 'Hombre',
	"uc_female" => 'Mujer',
	"uc_guild" => 'Hermandad',
	"uc_advanced_class" => 'Clase avanzada',
	"uc_prof1_name" => 'Trabajo',
	"uc_prof1_value" => 'Nivel del trabajo',
	"uc_race" => 'Raza',
	"uc_class" => 'Clase',
	"uc_ac_0" => '-',
	"uc_ac_1" => 'Acólito - Monje',
	"uc_ac_2" => 'Acólito - Sacerdote',
	"uc_ac_3" => 'Arquero - Maestro de bestias',
	"uc_ac_4" => 'Arquero - A distancia',
	"uc_ac_5" => 'Mago - Hechicero',
	"uc_ac_6" => 'Mago - Brujo',
	"uc_ac_7" => 'Espadachín - Caballero',
	"uc_ac_8" => 'Espadachín - Guerrero',
	"uc_ac_9" => 'Ladrón - Asesino',
	"uc_ac_10" => 'Ladrón - Pícaro',
	"uc_job_0" => '-',
	"uc_job_1" => 'Alquimia',
	"uc_job_2" => 'Artesano',
	"uc_job_3" => 'Herrero',
	"uc_job_4" => 'Cocinero',
	),
	
);

?>