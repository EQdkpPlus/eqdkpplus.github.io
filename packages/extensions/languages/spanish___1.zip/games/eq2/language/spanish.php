<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Spanish	
//Created by EQdkp Plus Translation Tool on  2019-08-22 13:41
//File: games/eq2/language/spanish.php
//Source-Language: english

$spanish_array = array( 
	"classes" => array(
	0 => 'Desconocido',
	1 => 'Asesino',
	25 => 'Señor de las bestias',
	2 => 'Berserker',
	3 => 'Brigand',
	4 => 'Bruiser',
	26 => 'Canalizador',
	5 => 'Coercer',
	6 => 'Conjuror',
	7 => 'Defiler',
	8 => 'Dirge',
	9 => 'Furia',
	10 => 'Guardián',
	11 => 'Ilusionista',
	12 => 'Inquisidor ',
	13 => 'Monje',
	14 => 'Místico',
	15 => 'Nigromante',
	16 => 'Paladín',
	17 => 'Ranger',
	18 => 'Caballero de las sombras',
	19 => 'Swashbuckler',
	20 => 'Templario',
	21 => 'Troubador',
	22 => 'Warden',
	23 => 'Brujo',
	24 => 'Mago',
	),
	"races" => array(
	0 => 'Desconocido',
	21 => 'Aerakyn',
	18 => 'Arasai',
	4 => 'Bárbaro',
	7 => 'Elfo oscuro',
	5 => 'Enano',
	14 => 'Erudito',
	19 => 'Fae',
	20 => 'Freeblood',
	13 => 'Froglok',
	2 => 'Gnomo',
	9 => 'Medio elfo',
	17 => 'Halfling',
	6 => 'Alto elfo',
	3 => 'Humano',
	15 => 'Iksar',
	10 => 'Kerran',
	12 => 'Ogro',
	16 => 'Ratonga',
	1 => 'Sarnak',
	11 => 'Trol ',
	8 => 'Elfo de los bosques',
	),
	"factions" => array(
	"good" => 'Bueno',
	"evil" => 'Malvado',
	"neutral" => 'Neutral',
	),
	"roles" => array(
	1 => 'Sanadores',
	2 => 'Luchadores',
	3 => 'Magos',
	4 => 'Exploradores',
	),
	"realmlist" => array(
	0 => 'Antonia Bayle',
	1 => 'Halls of Fate',
	2 => 'Maj\'Dul',
	3 => 'Skyfire',
	4 => 'Thurgadin',
	5 => 'Stormhold',
	6 => 'Test',
	7 => 'Beta',
	),
	"lang" => array(
	"eq2" => 'EverQuest II',
	"very_light" => 'Tela',
	"light" => 'Cuero',
	"medium" => 'Malla',
	"heavy" => 'Placas',
	"healer" => 'Sanador',
	"fighter" => 'Luchador',
	"mage" => 'Mago',
	"scout" => 'Explorador',
	"uc_gender" => 'Género',
	"uc_male" => 'Masculino',
	"uc_female" => 'Femenino',
	"uc_guild" => 'Hermandad',
	"uc_race" => 'Raza',
	"uc_class" => 'Clase',
	"uc_import_guild" => 'Importar hermandad',
	"uc_import_guild_help" => 'Importar todos los personajes de una hermandad',
	"servername" => 'Nombre del servidor ',
	"uc_lockserver" => 'Bloquear el nombre del servidor para los usuarios',
	"uc_update_all" => 'Actualizar todos los personajes',
	"uc_importer_cache" => 'Restaurar la caché importada',
	"uc_importer_cache_help" => 'Eliminar todos los datos de la clase importada en caché',
	"achievements" => 'Logros',
	"uc_class_filter" => 'Solo personajes de la clase',
	"uc_class_nofilter" => 'Sin filtros',
	"uc_guild_name" => 'Nombre de la hermandad',
	"uc_filter_name" => 'Filtro',
	"uc_level_filter" => 'Todos los personajes con un nivel mayor que',
	"uc_imp_novariables" => 'Primero debes seleccionar un reino de servidor y su localización en los ajustes.',
	"uc_imp_noguildname" => 'No se ha dado el nombre de la hermandad.',
	"uc_gimp_loading" => 'Cargando personajes de la hermandad, por favor espere...',
	"uc_gimp_header_fnsh" => 'Importación de hermandad finalizada',
	"uc_importcache_cleared" => 'The cache of the importer was successfully cleared.',
	"uc_delete_chars_onimport" => 'Eliminar personajes que han abandonado la hermandad',
	"uc_achievements" => 'Logros',
	"uc_critchance" => 'Mínima probabilidad de crítico requerida',
	"core_sett_f_uc_resists" => 'Resistencias mínimas',
	"gachievements" => 'Logros de hermandad',
	"graidready" => 'Banda preparada',
	"heraldry" => 'Guild Heraldry',
	"uc_noprofile_found" => 'Perfil no encontrado',
	"uc_profiles_complete" => 'Perfiles actualizados satisfactoriamente ',
	"uc_notyetupdated" => 'Sin nuevos datos (personaje inactivo)',
	"uc_notactive" => 'Se saltará este personaje porque está marcado como inactivo',
	"uc_error_with_id" => 'Error con la id de este personaje, se ha dejado fuera',
	"uc_notyourchar" => 'ATENCIÓN: Estás intentando importar un personaje que ya existe en la base de datos pero no eres su propietario. Por razones de seguridad, esta acción no está permitida. Por favor contacta con un administrador para solventar este problema o inténtalo usando otro nombre de personaje.',
	"uc_lastupdate" => 'Última actualización',
	"uc_prof_import" => 'Importar',
	"uc_import_forw" => 'Continuar',
	"uc_imp_succ" => 'Los datos han sido importados satisfactoriamente ',
	"uc_upd_succ" => 'Los datos han sido actualizados satisfactoriamente',
	"uc_imp_failed" => 'Ha ocurrido un error cuando se estaban actualizando los datos. Por favor inténtelo de nuevo.',
	"uc_updat_armory" => 'Refresh from Daybreak',
	"uc_charname" => 'Nombre del personaje',
	"uc_charfound" => 'The character <b>%1$s</b> has been found in the armory.',
	"uc_charfound2" => 'This character was updated on <b>%1$s</b>.',
	"uc_charfound3" => 'ATENCIÓN: ¡La importación va a sobrescribir los datos existentes! ',
	"uc_armory_confail" => 'Sin conexión con la armería. Los datos pueden no haber sido transmitidos.',
	"uc_armory_imported" => 'Importado',
	"uc_armory_impfailed" => 'Fallido',
	"uc_armory_impduplex" => 'Ya existe',
	"eqclassic" => 'The Shattered Lands',
	"splitpaw" => 'The Splitpaw Saga',
	"desert" => 'Desierto de Llamas',
	"kingdom" => 'Reino de los Cielos',
	"fallen" => 'The Fallen Dynasty',
	"faydwer" => 'Echoes of Faydwer',
	"kunark" => 'Rise of Kunark',
	"shadow" => 'The Shadow Odyssey',
	"sentinel" => 'Sentinel\'s of Fate',
	"velious" => 'Destiny of Velious',
	"chains" => 'Chains of Eternity',
	"tears" => 'Tears of Veeshan',
	"malice" => 'Altar of Malice',
	"general" => 'General',
	"avatar" => 'Avatares',
	"rum" => 'F.S. Distillery',
	"tot" => 'Terrors of Thalumbra',
	"zek" => 'Zek, the Scourge Wastes',
	"healermage" => 'Healer & Mage',
	"fighterscout" => 'Fighter & Scout',
	"no_data" => 'Sin datos.',
	"total_completed" => 'Completo en su totalidad',
	"uc_level" => 'Nivel',
	"uc_showachieve" => 'Show Guild Achievements in Roster Page? (Can slow down loading time)',
	"core_sett_fs_gamesettings" => 'EverQuest II Settings',
	"uc_faction" => 'Facción',
	"uc_faction_help" => 'Seleccionar la facción por defecto',
	),
	
);

?>