<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Spanish	
//Created by EQdkp Plus Translation Tool on  2019-08-22 13:41
//File: portal/quickpolls/language/spanish.php
//Source-Language: english

$lang = array( 
	"quickpolls" => 'Encuesta Rápida',
	"quickpolls_name" => 'Encuesta Rápida',
	"quickpolls_desc" => 'Crear una encuesta',
	"quickpolls_f_title" => 'Título de una encuesta',
	"quickpolls_f_question" => 'Descripción',
	"quickpolls_f_question_help" => 'Description or Question for this Quickpoll, will be shown under the title',
	"quickpolls_f_closedate" => 'Mostrar hasta',
	"quickpolls_f_help_closedate" => 'After this date, only the results will be shown and votings are disabled.',
	"quickpolls_f_showresults" => 'Mostrar enlace a los resultados',
	"quickpolls_f_help_showresults" => 'El enlace a los resultados se mostrará, independientemente del estado de la votación',
	"quickpolls_f_showstatistics" => 'Display statistics below the results',
	"quickpolls_f_help_showstatistics" => 'This includes the total votes and additionally, for multiple options, the participants (without guests)',
	"quickpolls_f_options" => 'Opciones',
	"quickpolls_f_help_options" => 'Introduzca una opción por fila',
	"quickpolls_f_resetvotes" => 'Reset votes',
	"quickpolls_vote" => 'Voto',
	"quickpolls_resuls" => 'Resultados',
	"quickpolls_total_votes" => 'Total votes',
	"quickpolls_participants" => 'Participants (without guests)',
	"quickpolls_f_multiple" => 'Allow choosing multiple options',
	
);

?>