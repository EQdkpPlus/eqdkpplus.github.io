<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Spanish	
//Created by EQdkp Plus Translation Tool on  2019-08-22 13:41
//File: plugins/statistics/language/spanish/lang_main.php
//Source-Language: english

$lang = array( 
	"statistics" => 'Estadísticas',
	"sb_statistics" => 'Estadísticas',
	"statistics_name" => 'Estadísticas',
	"statistics_desc" => 'Mostrar estadísticas de Clicks y Visitas',
	"st_f_view" => 'Seleccionar datos a mostrar',
	"st_short_desc" => 'Estadísticas',
	"st_long_desc" => 'Guardar estadísticas como visitas y clicks.',
	"st_plugin_not_installed" => 'El plugin de Estadísticas no está instalado',
	"st_view_statistics" => 'Mostrar estadísticas',
	"st_clicks" => 'clicks',
	"st_visits" => 'visitas',
	"st_user_regs" => 'Nuevos usuarios',
	"st_raidsignups" => 'Asistencias a eventos del calendario',
	"st_total" => 'Total',
	"st_today" => 'Hoy',
	"st_records" => 'Records',
	"st_timerange" => 'Rango de Tiempo',
	
);

?>