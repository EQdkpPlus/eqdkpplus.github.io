<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Spanish	
//Created by EQdkp Plus Translation Tool on  2019-08-22 13:41
//File: plugins/shoutbox/language/spanish/lang_main.php
//Source-Language: english

$lang = array( 
	"shoutbox" => 'Chat',
	"sb_shoutbox" => 'Chat',
	"shoutbox_name" => 'Chat',
	"shoutbox_desc" => 'El chat es un plugin para que los usuarios hablen mediantes mensajes cortos.',
	"sb_short_desc" => 'Chat',
	"sb_long_desc" => 'El chat es un plugin para que los usuarios hablen mediantes mensajes cortos.',
	"sb_plugin_not_installed" => 'Plugin del Chat no instalado.',
	"sb_php_version" => 'Chat requiere PHP %1$s o mayor. Tu server corre PHP %2$s',
	"sb_plus_version" => 'Chat requiere EQDKP-PLUS %1$s o mayor. Tu versión instalada es %2$s',
	"sb_no_view_permission" => 'No tienes permiso para ver los mensajes.',
	"sb_manage_archive" => 'Gestionar Archivo',
	"sb_written_by" => 'escrito por',
	"sb_written_at" => 'en',
	"sb_delete_success" => 'Entradas borradas.',
	"sb_settings_info" => 'Further Shoutbox settings could be found within the <a href='.registry::get_const('root_path').'admin/manage_portal.php'.registry::get_const('SID').'">Portalmodule settings</a>',
	"sb_use_users" => 'Uso de Nombres de Usuario en vez de Nombres de Miembros',
	"sb_use_users_help" => 'On changing membernames to usernames all entries will be updated.<br/>On changing usernames to membernames all entries will be deleted!',
	"sb_convert_member_user_success" => 'Todos los Nombres de Usuarios con entradas han sido actualizadas a Nombres de Miembros.',
	"sb_convert_user_member_success" => 'Todas las entradas fueron borradas.',
	"sb_config_saved" => 'Opciones guardadas con éxito.',
	"sb_header_general" => 'Opciones generales del Chat.',
	"sb_f_output_count_limit" => 'Numero Máximo de entradas a mostrar.',
	"sb_show_date" => '¿Mostrar fecha?.',
	"sb_f_show_archive" => '¿Mostrar Archivo?',
	"sb_f_max_text_length" => 'Tamaño de téxto máximo en una entrada.',
	"sb_f_input_box_location" => 'Loalización de la caja.',
	"sb_location_top" => 'Sobre las entradas.',
	"sb_location_bottom" => 'Debajo de las Entradas.',
	"sb_f_autoreload" => 'Tiempo en segundos de espera para la recarga automática del Chat (Predeterminado 0 = Desactivado)',
	"sb_f_help_autoreload" => 'Establecer en 0 para desactivar la recarga automática',
	"sb_no_character_assigned" => 'No hay personajes todavía están conectados. Al menos uno de los personajes tiene que estar conectado para poder publicar.',
	"sb_submit_text" => 'Enviar',
	"sb_save_wait" => 'Guardando, espere por favor...',
	"sb_reload" => 'Recargar',
	"sb_no_entries" => 'Sin entradas',
	"sb_archive" => 'Archivo',
	"sb_shoutbox_archive" => 'Archivo del Chat',
	"sb_missing_char_id" => 'ID inválida de miembro.',
	"sb_missing_text" => 'Falta texto para insertar.',
	
);

?>