<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Spanish	
//Created by EQdkp Plus Translation Tool on  2019-08-22 13:41
//File: core/data_handler/includes/modules/read/member/language/spanish.php
//Source-Language: english

$module_lang = array(
	"name" => 'Nombre',
	"editbutton" => '',
	"memberlink" => 'Nombre',
	"memberlink_detail_twink" => 'Nombre',
	"rankname" => 'Rango',
	"rankname_sortid" => 'Rango',
	"rankimage" => 'Imagen del Rango',
	"rankname_detail_twink" => 'Rango',
	"active" => 'Estado',
	"active_detail_twink" => 'Estado',
	"classname" => 'Clase',
	"classname_detail_twink" => 'Clase',
	"racename" => 'Raza',
	"racename_detail_twink" => 'Raza',
	"level" => 'Nivel',
	"level_detail_twink" => 'Nivel',
	"twink" => 'Tipo',
	"twink_detail_twink" => 'Tipo',
	"mainname" => 'Principal',
	"summed_up" => 'Total',
	"char_defrole" => 'Rol por defecto',
	"member_menu" => '',
	"mainchar_radio" => '<i class="fa fa-star fa-lg not-sortable" title="Mainchar"></i>',
	"name_decorated" => 'Nombre personaje',
	"memberlink_decorated" => 'Nombre personaje',
	"last_update" => 'Ultima actualización',
	"defaultrole" => 'Rol',
	"raidgroups" => 'Grupos de banda',
	"picture" => 'Avatar',
	);
	$preset_lang = array(
	"mname" => 'Nombre personaje',
	"mlink" => 'Enlace del Personaje',
	"mlevel" => 'Nivel del Personaje',
	"mrace" => 'Clase del Personaje',
	"mrank" => 'Rango del personaje',
	"mrankimg" => 'Imágen del rango del personaje',
	"mactive" => 'Estado de actividad del personaje',
	"mcname" => 'Nombre de la Clase del personaje',
	"mtwink" => 'Character type',
	"mlink_dt" => 'Enlace del Personaje',
	"mlevel_dt" => 'Nivel del Personaje',
	"mrace_dt" => 'Clase del Personaje',
	"mrank_dt" => 'Rango del personaje',
	"mactive_dt" => 'Estado de actividad del personaje',
	"mcname_dt" => 'Nombre de la Clase del personaje',
	"mlink_decorated" => 'Enlace del Personaje (decolorado)',
	"last_update" => 'Última actualización del personaje.',
	"medit" => 'Editar enlace del personaje',
	"cdefrole" => 'Rol seleccionado por defecto del personaje.',
	"mrank_sortid" => 'Ordenar rangos de personajes por ID',
	"charname" => 'Nombre del personaje (Decolorado)',
	"mmainname" => 'Nombre principal del personaje.',
	"picture" => 'Imagen del personaje',
	"note" => 'Nota del personaje',
	"muser" => 'Nombre del personaje',
	"charmenu" => 'Menú del Personaje',
	"cmainchar" => 'Radiobox de Personaje Principal',
	"mrole" => 'Rol del personaje',
	"mraidgroups" => 'Grupos de banda del personaje',
	);
	

?>