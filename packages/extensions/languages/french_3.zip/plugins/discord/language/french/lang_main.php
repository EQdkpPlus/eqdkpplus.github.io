<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2019-11-11 18:51
//File: plugins/discord/language/french/lang_main.php
//Source-Language: english

$lang = array( 
	"discord" => 'Discord',
	"discord_short_desc" => 'Initialiser Discord',
	"discord_long_desc" => 'Initialise la connexion entre EQdkp Plus et Discord',
	"discord_plugin_not_installed" => 'Le plugin Discord n\'est pas installé.',
	"discord_fs_general" => 'Général',
	"discord_f_guild_id" => 'ID de Guilde',
	"discord_f_help_guild_id" => 'Vous pouvez prendre l\'URL de Guilde de votre serveur de Guilde. C\'est le premier long nombre de l\'URL.',
	"discord_f_bot_client_id" => 'ID du client de votre application de Bot',
	"discord_f_help_bot_client_id" => 'Pour plus d\'information et instructions, voir https://eqdkp-plus.eu/wiki/Discord',
	"discord_f_bot_token" => 'Jeton d\'accès à l\'utilisateur de l\'App de Bot',
	"discord_f_help_bot_token" => 'Pour plus d\'information et instructions, voir https://eqdkp-plus.eu/wiki/Discord',
	"discord_autorize_bot" => 'Ajouter le Bot au serveur de Guilde',
	"discordlatestposts" => 'Derniers messages sur Discord',
	"discordlatestposts_name" => 'Derniers messages sur Discord',
	"discordlatestposts_desc" => 'Affiche les derniers messages sur des canaux de Discord sélectionnés',
	"discord_f_amount" => 'Nombre de messages affichés',
	"discord_f_blackwhitelist" => 'Black - ou White listes',
	"discord_f_help_blackwhitelist" => 'Rejette les ID de forum insérés (blacklisting) ou les accepte (whitelisting)',
	"discord_f_cachetime" => 'Durée de mise en cache des messages',
	"discord_f_help_privateforums2" => 'Sélectionnez les forums pour le groupe d\'utilisateurs concerné par la liste Noir / Blanc.',
	"discordlatestposts_noselectedboards" => 'Aucun canal sélectionné',
	"discordlatestposts_noentries" => 'Aucun message n\'est disponible',
	
);

?>