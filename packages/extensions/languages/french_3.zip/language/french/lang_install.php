<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2019-11-11 18:51
//File: language/french/lang_install.php
//Source-Language: english

$lang = array( 
	"page_title" => 'Installation d\'EQDKP-PLUS %s',
	"back" => 'Sauvegarder et revenir',
	"continue" => 'Continuer',
	"language" => 'Langue',
	"inst_finish" => 'Terminer l\'installation',
	"error" => 'Erreur',
	"warning" => 'Avertissement',
	"success" => 'Bravo !',
	"yes" => 'Oui',
	"no" => 'Non',
	"retry" => 'Réessayer',
	"skip" => 'Ignorer',
	"step_order_error" => 'Erreur de déroulement : Étape non trouvée. Veuillez vous assurer que tous les fichiers sont correctement téléchargés. Pour plus d\'informations, veuillez visiter nos forums à <a href="http://eqdkp-plus.eu/forum">http://eqdkp-plus.eu/forum</a>.',
	"licence" => 'Accord de licence ',
	"php_check" => 'Vérification de Pré-installation',
	"file_permissions" => 'Permissions des fichiers et des dossiers',
	"encryptionkey" => 'Clef de chiffrement',
	"data_folder" => 'Dossier des données',
	"db_access" => 'Accès à la base de données',
	"inst_settings" => 'Paramètres',
	"admin_user" => 'Compte administrateur',
	"end" => 'Finalisation de l\'installation',
	"welcome" => 'Bienvenue dans l\'installation d\'EQdkp Plus. Nous avons travaillé dur pour rendre cette étape aussi simple et rapide que possible. Pour commencer, acceptez simplement notre licence d\'utilisation en cliquant ci-dessous sur \'Accepter & Commencer l\'installation\'.',
	"accept" => 'Accepter et commencer l\'installation',
	"license_text" => '<b>EQdkp Plus est publié sous licence AGPL v3.0. </b><br /><br /><br /> Le texte intégral de la licence se trouve à <a href="http://opensource.org/licenses/AGPL-3.0" target="_blank">http://opensource.org/licenses/AGPL-3.0</a>.<br /><br /> Voici un résumé des termes les plus importants de l\'AGPL v3.0 sans en garantir l\'exhaustivité et l\'exactitude.<br /><br /> <h3><strong>Vous êtes autorisé:</strong></h3> <ul> <li> à utiliser ce logiciel à des fins commerciales </li> <li> à distribuer ce logiciel </li> <li>à modifier ce logiciel</li> </ul> <h3><strong>Vous devez obligatoirement:</strong></h3> <ul><li>distribuer le code source complet de votre application qui utilise EQdkp Plus, lorsque vous la distribuerez </li> <li>divulguer le code source de votre application complète qui utilise EQdkp Plus, si vous ne la distribuez pas  mais des utilisateurs l\'utilisent via le réseau ("Hébergement", "SaaS")</li> <li> à laisser les mentions de copyright visibles et invisibles de ce projet et à inclure une copie de la licence AGPL dans votre application </li> <li> à indiquer les modifications apportées au code </li> </ul> <h3><strong>Il est interdit:</strong></h3> <ul><li>de tenir le(s) auteur(s) de ce logiciel responsable de tout dommage, le logiciel est fourni sans garantie.</li> <li>de licencier votre application sous une autre licence que l\'AGPL</li> </ul>.',
	"table_pcheck_name" => 'Nom',
	"table_pcheck_required" => 'Requis',
	"table_pcheck_installed" => 'Courant',
	"table_pcheck_rec" => 'Recommandé',
	"module_php" => 'Version PHP',
	"module_mysql" => 'Base de données MySQL',
	"module_zLib" => 'Module PHP zLib',
	"module_curl" => 'Module PHP cURL',
	"module_fopen" => 'Fonction PHP fopen',
	"module_soap" => 'Module PHP SOAP',
	"module_autoload" => 'Fonction PHP spl_autoload_register',
	"module_hash" => 'Fonction PHP hash',
	"module_memory" => 'limite de mémoire de PHP',
	"module_json" => 'Module PHP JSON',
	"module_gd" => 'Module PHP d\'Image GD',
	"module_pathinfo" => 'Support de PathInfo',
	"module_zip" => 'Module PHP Zip',
	"module_xml" => 'Module XML de PHP',
	"module_mb" => 'Module PHP MultiOctet',
	"module_crypto" => 'Cryptographic Methods',
	"phpcheck_success" => 'Les exigences minimales pour l\'installation d\'EQDKP-Plus sont satisfaites. L\'installation peut continuer.',
	"phpcheck_failed" => 'Les conditions minimales requises pour l\'installation d\'EQDKP-Plus ne sont pas remplies. <br />Une sélection de sociétés d\'hébergement appropriées peut être trouvée sur notre <a href="http://eqdkp-plus.eu" target="_blank">site web</a>.',
	"do_match_opt_failed" => 'Certaines exigences ne sont pas satisfaites.<br />EQdkp Plus fonctionnera malgré tout mais quelques fonctions pourraient être indisponibles.',
	"ftphost" => 'Hébergeur FTP',
	"ftpport" => 'Port FTP',
	"ftpuser" => 'Nom d\'utilisateur FTP',
	"ftppass" => 'Mot de passe FTP',
	"ftproot" => 'Repertoire de base FTP',
	"ftproot_sub" => '(Chemin vers le répertoire racine de l\'utilisateur FTP)',
	"useftp" => 'Utiliser le mode FTP comme gestionnaire de fichier.',
	"useftp_sub" => '(Vous pouvez le modifier plus tard en éditant le fichier config.php)',
	"ftp_connectionerror" => 'La connexion FTP ne peut pas être établie. Merci de vérifier le nom d\'Hôte FTP et le port.',
	"ftp_loginerror" => 'L\'authentification FTP a échoué. Merci de vérifier votre n\'om d\'utilisateur et votre mot de passe FTP.',
	"plain_config_nofile" => 'Le fichier <b>config.php</b> n\'est pas disponible et la création automatique a échoué. <br />Veuillez créer un fichier texte vierge avec le nom <b>config.php</b> et définir les permissions avec chmod 777',
	"plain_config_nwrite" => 'Le fichier <b>config.php</b> n\'est pas modifiable en écriture. <br /> Veuillez définir les permissions correctes. <b>chmod 0777 config.php</b>.',
	"plain_dataf_na" => 'Le dossier <b>'.registry::get_const('root_path').'data/</b> n\'est pas disponible.<br /> Veuillez créer ce dossier. <b>mkdir données</b>.',
	"plain_dataf_nwrite" => 'Le dossier <b>'.registry::get_const('root_path').'data/</b> n\'est pas modifiable en écriture.<br /> Veuillez définir les bonnes permissions. <b>chmod -R 0777 data</b>.',
	"ftp_datawriteerror" => 'Imposible de créer des fichiers dans le répertoire Data. Le chemin d\'accès vers la racine du FTP est-il correct ?',
	"ftp_info" => 'Plutôt que de configurer les permissions de fichiers et de dossiers requises, vous pouvez utiliser un compte ftp qui améliorera l’interaction sur le serveur. Pour utiliser cette option, veuillez indiquer un utilisateur ftp ayant les permissions d\'accès à votre installation et cochez \'Mode FTP\'. Si vous n\'utilisez pas le Mode FTP, vous pouvez simplement cliquer sur le bouton Procéder de cette page.',
	"ftp_tmpinstallwriteerror" => 'Le dossier <b>'.registry::get_const('root_path').'data/97384261b8bbf966df16e5ad509922db/tmp/</b> n\'est pas accessible en écriture.<br />Pour écrire le fichier de configuration, CHMOD 777 est nécessaire. Ce dossier sera supprimé après l\'installation.',
	"ftp_tmpwriteerror" => 'Le dossier <b>'.registry::get_const('root_path').'data/%s/tmp/</b> n\'est pas accessible en écriture.<br /> L\'utilisation du mode FTP nécessite CHMOD 777 pour ce dossier. C\'est le seul dossier nécessitant des droits d\'écriture.',
	"fp_data_folder" => 'Le dossier"data" existe et est modifiable',
	"fp_config_file" => 'Le fichier "config.php" existe et est modifiable',
	"fp_test_file" => 'Testfile créé et disponible',
	"dbtype" => 'Type de base de données',
	"dbhost" => 'Hôte de base de données',
	"dbname" => 'Nom de base de données',
	"dbuser" => 'Nom d\'utilisateur de base de données',
	"dbpass" => 'Mot de passe de base de données',
	"dbport" => 'Port de base de données',
	"dbport_help" => 'Le port par défaut est 3306',
	"table_prefix" => 'Préfixe pour les tables EQDKP-Plus',
	"test_db" => 'Tester la base de données',
	"prefix_error" => 'Aucun préfixe valide de base de données détecté ! Merci d\'en saisir un.',
	"INST_ERR_PREFIX" => 'Une installation de avec ce préfixe exiset déjà. Supprimez toutes les tables avec ce préfixe puis recommencez cette étape après avoir utilisé le bouton "Retour". Vous pouvez également choisir un autre préfixe si vous souhaitez installer plusieurs jeux de données dans une même base de données.',
	"INST_ERR_PREFIX_INVALID" => 'Le préfixe de table que vous avez indiqué est incorrect pour votre base de données. Merci d\'en essayer un autre en supprimant des caractères comme trait d\'union, apostrophe, slash ou anti-slash.',
	"dbcheck_success" => 'La base de données a bien été vérifiée. L\'installation peut continuer.',
	"encryptkey_info" => 'La clé de chiffrement fait partie du processus de chiffrement utilisé pour protéger les données sensibles de la base de données, telles que les adresses e-mail de vos utilisateurs. Même si votre base de données est compromise, sans la clé de cryptage vos données restent codées et sécurisées. Par conséquent, veuillez choisir une clé sécurisée, et vous assurer d\'en conserver une copie de sauvegarde. Personne d\'autre ne pourra jamais la récupérer si vous la perdez !',
	"encryptkey" => 'Clé de chiffrement',
	"encryptkey_help" => '(min. 6 caractères de long)',
	"encryptkey_repeat" => 'Confirmer la clé de chiffrement',
	"encryptkey_no_match" => 'La clé de chiffrement ne correspond pas',
	"encryptkey_too_short" => 'La clé de chiffrement est trop courte. 6 caractères de long minimum.',
	"inst_db" => 'Installer la base de données',
	"lang_config" => 'Paramètres de langue',
	"default_lang" => 'Langue par défaut',
	"default_locale" => 'Emplacement par défaut',
	"game_config" => 'Paramètres du jeu',
	"default_game" => 'Jeu par défaut',
	"server_config" => 'Paramètres du serveur',
	"server_path" => 'Chemin d\'accès des Scripts',
	"grp_guest" => 'Invités',
	"grp_super_admins" => 'Super administrateurs',
	"grp_admins" => 'administrateurs',
	"grp_officers" => 'officiers',
	"grp_writers" => 'Rédacteurs',
	"grp_member" => 'Membres',
	"grp_guest_desc" => 'Les Visiteurs sont des membres non enregistrés',
	"grp_super_admins_desc" => 'Les Super administrateurs ont tous les droits',
	"grp_admins_desc" => 'Les Administrateurs n\'ont pas tous les droits d\'administration',
	"grp_officers_desc" => 'Les Officiers peuvent gérer les raids',
	"grp_writers_desc" => 'Les Rédacteurs peuvent écrire et gérer les news',
	"grp_member_desc" => 'membre',
	"game_info" => 'D\'autres jeux pourront être pris en charge après l\'installation en utilisant la gestion des extensions pour les télécharger.',
	"timezone" => 'Fuseau horaire du serveur',
	"startday" => 'Premier jour de la semaine',
	"sunday" => 'Dimanche',
	"monday" => 'Lundi',
	"time_format" => 'H:i',
	"date_long_format" => 'j. F Y',
	"date_short_format" => 'd/m/y',
	"style_jsdate_nrml" => 'DD/MM/YYYY',
	"style_jsdate_short" => 'D.M',
	"style_jstime" => 'HH:mm',
	"welcome_news_title" => 'Bienvenue sur EQDKP-PLUS',
	"welcome_news" => '<p>L\'installation de votre EQdkp Plus s\'est bien déroulée - vous pouvez maintenant le configurer selon vos souhaits.</p> <p>Vous trouverez de l\'aide pour l\'administration et l\'utilisation générale sur notre <a href="http://eqdkp-plus.eu/wiki/" target="_blank">Wiki</a>.</p> <p>Pour plus d\'informations, veuillez visiter notre <a href="http://eqdkp-plus.eu/forum" target="_blank">Forum</a>.</p> <p>Amusez-vous bien avec EQdkp Plus ! Votre équipe EQdkp Plus </p>',
	"feature_news_title" => 'Nouvelles fonctionnalités d\'EQdkp Plus',
	"feature_news" => '<p>EQdkp Plus 2.3 contient beaucoup de nouvelles fonctionnalités. Cet article devrait en présenter les plus importantes.</p> <h3>Système d\'articles </h3> <p>Au lieu de pages de nouvelles et d\'informations, nous avons introduit un tout nouveau système d\'articles. Chaque nouvelle et chaque page est maintenant un article. Vous pouvez regrouper vos articles dans des catégories d\'articles. Ainsi, vous pouvez par exemple réaliser des blogs pour votre guilde et vos utilisateurs.</p> <p>Vous pouvez diviser un article en utilisant les méthodes Read more et Pagebreak. De plus, vous pouvez insérer des galeries d\'images, des objets ou du butin de raid à l\'aide des boutons  de l\'éditeur .</p> <h3>Gestion des médias </h3> <p>Avec la nouvelle gestion des médias dans le panneau d\'administration et l\'Editeur, vous pouvez maintenant insérer facilement les médias dans vos articles. Par exemple, les fichiers peuvent être téléchargés par glisser-déposer. De plus, vous pouvez aussi éditer des images dans le navigateur de fichiers.</p> <h3>Calendrier</h3><p>Planifier des raids n\'a jamais été aussi facile en utilisant le glisser-déposer. De plus, des événements publics et privés peuvent être créés, des personnes peuvent être invitées et vous dire si elles participent ou non.</p> <h3>Gestion des Menus</h3> <p>Nous avons supprimé tous les menus sauf un. Et celui-ci pourra être totalement configuré. Vous pouvez positionner les choix  sur 3 niveaux simplement avec un Glisser-Déposer, ce qui vous permet de créer des sous-menus. Vous pouvez toujours créer des liens vers des pages externes, mais aussi ajouter des liens directs vers des articles ou des catégories d\'articles.</p> <h3>Gestion du portail </h3> <p> Avant il n\'y avait qu\'une seule mise en page de portail, chaque page avait les mêmes modules de portail. C\'est pourquoi nous avons mis en place les mises en page du portail. Vous pouvez maintenant affecter une mise en page de portail à chaque catégorie d\'article.</p> <p>Par ailleurs, vous pouvez créer vos propres blocs de portail que vous pouvez intégrer dans votre modèle, par exemple pour éditer des liens dans votre pied de page.</p>.',
	"category1" => 'Système',
	"category2" => 'Actualités',
	"category3" => 'Evénements',
	"category4" => 'Objets',
	"category5" => 'Raids',
	"category6" => 'Calendrier',
	"category7" => 'Roster',
	"category8" => 'Points',
	"category9" => 'Personnage',
	"article5" => 'Personnage',
	"article6" => 'Roster',
	"article7" => 'Evénements',
	"article8" => 'Objets',
	"article9" => 'Points',
	"article10" => 'Raids',
	"article12" => 'Evénements de calendrier',
	"article13" => 'Calendrier',
	"article14" => 'Règles de la guilde',
	"article15" => 'Politique de confidentialité',
	"article16" => 'Mentions légales',
	"role_healer" => 'Guérisseur',
	"role_tank" => 'Tank',
	"role_range" => 'DPS distant',
	"role_melee" => 'DPS mêlée',
	"create_user" => 'Créer un accès',
	"username" => 'Nom d\'utilisateur Administrateur',
	"user_password" => 'Mot de passe Administrateur',
	"user_pw_confirm" => 'Confirmer le mot de passe Administrateur',
	"user_email" => 'Adresse e-mail Administrateur',
	"auto_login" => 'Se souvenir de moi (cookie)',
	"user_required" => 'Utilisateur, e-mail et mot de passe sont des champs obligatoires',
	"no_pw_match" => 'Le mot de passe ne correspond pas.',
	"install_end_text" => 'L\'installation peut maintenant se terminer correctement.',
	"windows_apache_hint" => 'Vous semblez utiliser le serveur Apache sous Windows. EQdkp Plus ne fonctionnera que si vous augmentez le ThreadStackSize à 8388608 dans votre fichier de configuration d\'Apache.',
	"install_support_h1" => 'Soutenez EQdkp Plus',
	"install_support_text" => 'A project like EQdkp Plus can only exist, if we can get back some of the effort, time and love we invest in EQdkp Plus. You can give something back on the following ways:
						<ul>
							<li><i class="fa fa-puzzle-piece"></i> <a href="http://eqdkp-plus.eu/repository/">Publish a plugin or template, so every EQdkp Plus user can use it</a></li>
							<li><i class="fa fa-comments"></i> <a href="http://eqdkp-plus.eu/forum/">Support us at our board</a></li>
							<li><i class="fa fa-cogs"></i> <a href="https://eqdkp-plus.eu/en/development.html">Take part actively in the development of EQdkp Plus</a></li>
							<li><i class="fa fa-usd"></i> <a href="https://eqdkp-plus.eu/en/donate.html">Support us financially so we can continue offering you our services like LiveUpdate</a></li>
						</ul>
						So if you love EQdkp Plus as much as we do, think about supporting us!<br /><a href="https://eqdkp-plus.eu/Donate.html?" style="background:orange;border-radius:5px;padding:7px;display:inline-block;color:black;"><i class="fa fa-paypal"></i> Donate now</a>',
	"additional_keys" => 'Caractéristiques supplémentaires',
	"additional_keys_info" => 'Nous utilisons des fonctionnalités d\'autres fournisseurs, comme la protection anti-spam. Pour utiliser ces fonctions, vous avez besoin de vos propres clés. Vous pouvez donc créer vos propres clés aux pages suivantes.<br /><b>Vous pouvez bien sûr sauter cette étape, et insérer les clés à tout moment dans les paramètres de EQdkp Plus.</b>.',
	"recaptcha_info" => 'reCATPCHA est une méthode de protection contre le spam. L\'activation de cette méthode réduit le spam et augmente la sécurité de votre EQdkp Plus. Vous pouvez créer vos propres clés sur cette page : <br /> <a href="https://www.google.com/recaptcha/admin/create" target="_blank"><i class="fa fa-lg fa-external-link"></i> https://www.google.com/recaptcha/admin/create</a>. Veuillez n\'utiliser que les types pris en charge lors de la création d\'une nouvelle clé.',
	"recaptcha_okey" => 'Clé du site de reCATPCHA',
	"recaptcha_pkey" => 'Clé privée du reCATPCHA',
	"recaptcha_type" => 'Type',
	"delete_ownership_file" => 'Par mesures de sécurité, veuillez supprimer le fichier "database_ownership_file.txt" du répertoire racine d\'EQdkp Plus avant de poursuivre l\'installation.',
	"module_externalconnection" => 'Connexions externes',
	
);

?>