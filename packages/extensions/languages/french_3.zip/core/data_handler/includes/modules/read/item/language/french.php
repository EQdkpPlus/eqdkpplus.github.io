<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2019-11-11 18:51
//File: core/data_handler/includes/modules/read/item/language/french.php
//Source-Language: english

$module_lang = array(
	"date" => 'Date',
	"buyer_name" => 'Acheteur',
	"buyer_link" => 'Acheteur',
	"value" => 'Valeur',
	"name" => 'Nom',
	"itempool_name" => 'Groupe d\'objets',
	"link" => 'Nom',
	"raidlink" => 'Raid',
	"m4igk4i" => 'Acheteurs',
	"raididlink" => 'Raid',
	"link_itt" => 'Nom',
	"editicon" => '',
	"droprate" => 'Chance d\'obtention',
	);
	$preset_lang = array(
	"idate" => 'Date de l\'objet',
	"ilink" => 'Lien de l\'objet',
	"ibuyers" => 'Acheteur de l\'objet',
	"ibuyerlink" => 'Acheteur de l\'objet (lié)',
	"iraididlink" => 'Raid de l\'objet (détailé)',
	"ivalue" => 'Valeur de l\'objet',
	"ipoolname" => 'Nom du groupe de l\'objet',
	"iraidlink" => 'Raid de l\'objet',
	"iname" => 'Nom de l\'objet',
	"ibuyername" => 'Acheteur de l\'objet',
	"ilink_itt" => 'Lien ITT de l\'objet',
	"itemsedit" => 'Bouton d\'édition de l\'objet',
	"idroprate" => 'Taux de lâcher (pour la liste d\'objets)',
	);
	

?>