<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2019-11-11 18:51
//File: core/data_handler/includes/modules/read/member_attendance/language/french.php
//Source-Language: english

$module_lang = array(
	"attendance" => 'Raids (%d jours)',
	"lifetime" => 'Raids (tous)',
	"attendance_fromto" => 'Participation aux raids',
	);
	$preset_lang = array(
	"attendance_30" => 'Participation aux raids (30 jours)',
	"attendance_60" => 'Participation aux raids (60 jours)',
	"attendance_90" => 'Participation aux raids (90 jours)',
	"attendance_30_real" => 'Participation au raid (30 jours, selon la durée de vie)',
	"attendance_60_real" => 'Participation au raid (60 jours, selon la durée de vie)',
	"attendance_90_real" => 'Participation au raid (90 jours, selon la durée de vie)',
	"attendance_lt" => 'Participation aux raids  (tous)',
	"attendance_lt_real" => 'Raid attendance (lifetime, base on creationtime)',
	"attendance_fromto_all" => 'Participation aux raids (def. jours)',
	);
	

?>