<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2019-11-11 18:51
//File: games/ffxi/language/french.php
//Source-Language: english

$french_array = array( 
	"classes" => array(
	0 => 'Inconnue',
	1 => 'Barde',
	2 => 'Dresseur',
	3 => 'Magicien Noir',
	4 => 'Mage Bleu',
	5 => 'Corsaire',
	6 => 'Danseur',
	7 => 'Chevalier Noir',
	8 => 'Chevalier Dragon',
	9 => 'Moine',
	10 => 'Ninja',
	11 => 'Paladin',
	12 => 'Marionnettiste',
	13 => 'Rôdeur',
	14 => 'Mage Rouge',
	15 => 'Samuraï',
	16 => 'Érudit',
	17 => 'Invocateur',
	18 => 'Voleur',
	19 => 'Guerrier',
	20 => 'Mage Blanc',
	),
	"races" => array(
	0 => 'Inconnue',
	1 => 'Elvaan',
	2 => 'Galka',
	3 => 'Hume',
	4 => 'Mithra',
	5 => 'Tarutaru',
	),
	"factions" => array(
	"bastok" => 'Bastok',
	"sandoria" => 'San D\'Oria',
	"windurst" => 'Windurst',
	),
	"lang" => array(
	"ffxi" => 'Final Fantasy XI',
	"tank" => 'Tank',
	"support" => 'Soutien',
	"damage_dealer" => 'Dégats',
	"uc_gender" => 'Sexe',
	"uc_male" => 'Mâle',
	"uc_female" => 'Femelle',
	"uc_guild" => 'Guilde',
	"uc_race" => 'Race',
	"uc_class" => 'Classe',
	"core_sett_fs_gamesettings" => 'Paramètres de Final Fantasy XI',
	"uc_faction" => 'Faction',
	"uc_faction_help" => 'Choisissez la faction par défaut',
	),
	
);

?>