<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2019-11-11 18:51
//File: games/eq2/language/french.php
//Source-Language: english

$french_array = array( 
	"classes" => array(
	0 => 'Inconnue',
	1 => 'Assassin',
	25 => 'Seigneur bestial',
	2 => 'Berserk',
	3 => 'Brigand',
	4 => 'Baroudeur',
	26 => 'Canaliseur',
	5 => 'Subjugueur',
	6 => 'Invocateur',
	7 => 'Destructeur',
	8 => 'Chante-sort',
	9 => 'Furie',
	10 => 'Gardien',
	11 => 'Illusioniste',
	12 => 'Inquisiteur',
	13 => 'Moine',
	14 => 'Mystique',
	15 => 'Nécromancien',
	16 => 'Paladin',
	17 => 'Rôdeur',
	18 => 'Chevalier de l\'ombre',
	19 => 'Fier-à-bras',
	20 => 'Templier',
	21 => 'Troubadour',
	22 => 'Surveillant',
	23 => 'Envoûteur',
	24 => 'Sorcier',
	),
	"races" => array(
	0 => 'Inconnue',
	21 => 'Aerakyn',
	18 => 'Arasai',
	4 => 'Barbare',
	7 => 'Elfe noir',
	5 => 'Nain',
	14 => 'Erudit',
	19 => 'Fae',
	20 => 'Freeblood',
	13 => 'Grelok',
	2 => 'Gnome',
	9 => 'Semi-elfe',
	17 => 'Haleflin',
	6 => 'Haut-Elfe',
	3 => 'Humain',
	15 => 'Iksar',
	10 => 'Kerran',
	12 => 'Ogre',
	16 => 'Ratonga',
	1 => 'Sarnak',
	11 => 'Troll',
	8 => 'Elfe des bois',
	),
	"factions" => array(
	"good" => 'Bon',
	"evil" => 'Mauvais',
	"neutral" => 'Neutre',
	),
	"roles" => array(
	1 => 'Guérisseurs',
	2 => 'Combattants',
	3 => 'Mages',
	4 => 'Éclaireurs',
	),
	"realmlist" => array(
	0 => 'Antonia Bayle',
	1 => 'Halls of Fate',
	2 => 'Maj\'Dul',
	3 => 'Skyfire	',
	4 => 'Thurgadin	
',
	5 => 'Stormhold	
',
	6 => 'Teste	
',
	7 => 'Beta	
',
	),
	"lang" => array(
	"eq2" => 'EverQuest II',
	"very_light" => 'Tissu',
	"light" => 'Cuir',
	"medium" => 'Mailles',
	"heavy" => 'Plaques',
	"healer" => 'Guérisseur',
	"fighter" => 'Combattant',
	"mage" => 'Mage',
	"scout" => 'Éclaireur',
	"uc_gender" => 'Sexe',
	"uc_male" => 'Mâle',
	"uc_female" => 'Femelle',
	"uc_guild" => 'Guilde',
	"uc_race" => 'Race',
	"uc_class" => 'Classe',
	"uc_import_guild" => 'Importer la guilde',
	"uc_import_guild_help" => 'Importe tous les personnages d\'une guilde',
	"servername" => 'Nom du serveur',
	"uc_lockserver" => 'Verrouiller le nom de serveur pour les utilisateurs',
	"uc_update_all" => 'Actualiser tous les personnages',
	"uc_importer_cache" => 'Réinitialiser le cache d\'importation',
	"uc_importer_cache_help" => 'Supprimer toutes les données du cache d\'importation des classes',
	"achievements" => 'Succès',
	"uc_class_filter" => 'Seulement les personnages de la classe',
	"uc_class_nofilter" => 'Aucun filtre',
	"uc_guild_name" => 'Nom de la guilde',
	"uc_filter_name" => 'Filtre',
	"uc_level_filter" => 'Tous les personnage de niveau supérieur à',
	"uc_imp_novariables" => 'Vous devez d\'abord définir le serveur et son emplacement dans les paramètres.',
	"uc_imp_noguildname" => 'Le nom de la guilde n\'a pas été indiqué.',
	"uc_gimp_loading" => 'Chargement des personnages de la guilde, veuillez patienter...',
	"uc_gimp_header_fnsh" => 'Importation de la guilde terminée',
	"uc_importcache_cleared" => 'Le cache d’importation a bien été nettoyé',
	"uc_delete_chars_onimport" => 'Supprimer les personnages qui ont quitté la guilde',
	"uc_achievements" => 'Succès',
	"uc_critchance" => 'Minimum de chance crit requis',
	"core_sett_f_uc_resists" => 'Résistance minimum',
	"gachievements" => 'Succès de guilde',
	"graidready" => 'Raid prêt',
	"heraldry" => 'Guilde Héraldique',
	"uc_noprofile_found" => 'Aucun profil trouvé',
	"uc_profiles_complete" => 'Actualisation des profils réussie',
	"uc_notyetupdated" => 'Pas de nouvelle donnée (personnage inactif)',
	"uc_notactive" => 'Ce personnage sera passé car il est défini comme inactif',
	"uc_error_with_id" => 'Erreur avec l\'ID de ce personnage, il a été mis de côté',
	"uc_notyourchar" => 'ATTENTION: Vous essayez d\'importer un personnage existant déjà dans la base de données mais qui ne vous appartient pas. Par mesure de sécurité, ce n\'est pas autorisé. Veuillez contacter votre administrateur pour résoudre le problème ou essayer d\'utiliser un autre personnage.',
	"uc_lastupdate" => 'Dernière mise à jour',
	"uc_prof_import" => 'importer',
	"uc_import_forw" => 'continuer',
	"uc_imp_succ" => 'Les données ont été correctement importées',
	"uc_upd_succ" => 'Les données ont bien été actualisées',
	"uc_imp_failed" => 'Une erreur s\'est produite durant la mise à jour des données. Veuillez réessayer.',
	"uc_updat_armory" => 'Actualiser à partir de Daybreak',
	"uc_charname" => 'Nom du personnage',
	"uc_charfound" => 'The character <b>%1$s</b> has been found in the armory.',
	"uc_charfound2" => 'This character was updated on <b>%1$s</b>.',
	"uc_charfound3" => 'ATTENTION: L\'importation écrasera les données existantes !',
	"uc_armory_confail" => 'Pas de connexion vers l\'armurerie. Les données ne peuvent pas être transmises.',
	"uc_armory_imported" => 'Importé',
	"uc_armory_impfailed" => 'Echoué',
	"uc_armory_impduplex" => 'déjà présent',
	"eqclassic" => 'The Shattered Lands',
	"splitpaw" => 'The Splitpaw Saga',
	"desert" => 'Desert of Flames',
	"kingdom" => 'Kingdom of Sky',
	"fallen" => 'The Fallen Dynasty',
	"faydwer" => 'Echoes of Faydwer',
	"kunark" => 'Rise of Kunark',
	"shadow" => 'The Shadow Odyssey',
	"sentinel" => 'Sentinel\'s of Fate',
	"velious" => 'Destiny of Velious',
	"chains" => 'Chains of Eternity',
	"tears" => 'Tears of Veeshan',
	"malice" => 'Altar of Malice',
	"general" => 'Général',
	"avatar" => 'Avatars',
	"rum" => 'F.S. Distillery',
	"tot" => 'Terreurs de Thalumbra	
',
	"zek" => 'Zek, the Scourge Wastes',
	"kas" => 'Kunark Ascending',
	"healermage" => 'Guérisseur & Mage',
	"fighterscout" => 'Combattant & Éclaireur',
	"no_data" => 'Aucune donnée.',
	"total_completed" => 'Total terminé.',
	"uc_level" => 'Niveau',
	"uc_showachieve" => 'Montrer les succès de guilde dans le Roster ? (Cela peut ralentir son exécution)',
	"core_sett_fs_gamesettings" => 'Paramètres d\'EverQuest II',
	"uc_faction" => 'Faction',
	"uc_faction_help" => 'Choisissez la faction par défaut',
	),
	
);

?>