<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2019-11-11 18:52
//File: portal/twitter/language/french.php
//Source-Language: english

$lang = array( 
	"twitter" => 'Twitter',
	"twitter_name" => 'Twitter',
	"twitter_desc" => 'Suivre un compte Twitter spécifique',
	"twitter_f_account" => 'Compte Twitter',
	"twitter_f_maxitems" => 'Nombre max. de tweets affichés (Vide = illimité)',
	"twitter_f_cachetime" => 'Durée du cache en heure (défaut: 1 heure)',
	"twitter_f_hideuserreplys" => 'Masquer les réponses aux utilisateurs',
	"twitter_f_hideretweets" => 'Cacher les Retweets',
	"pm_twitter_follow" => 'Suivre %s sur Twitter',
	"pm_twitter_period" => array(
	0 => 'seconde',
	1 => 'minute',
	2 => 'heure',
	3 => 'jour',
	4 => 'semaine',
	5 => 'mois',
	6 => 'année',
	7 => 'Décennie',
	),
	"pm_twitter_periods" => array(
	0 => 'secondes',
	1 => 'minutes',
	2 => 'heures',
	3 => 'jours',
	4 => 'semaines',
	5 => 'mois',
	6 => 'années',
	7 => 'décennies',
	),
	"pm_twitter_tense" => array(
	0 => 'à partir de maintenant',
	1 => 'depuis',
	),
	"pm_twitter_format" => '%1$s %2$s	',
	"pm_twitter_answer" => 'Répondre',
	"pm_twitter_retweet" => 'Retweeter',
	"pm_twitter_favorit" => 'Favori',
	
);

?>