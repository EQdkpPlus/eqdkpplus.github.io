<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2016-06-15 09:50
//File: games/eq/language/russian.php
//Source-Language: english

$russian_array = array( 
	"classes" => array(
	0 => 'Неизвестно',
	1 => 'Бард',
	2 => 'Повелитель зверей',
	3 => 'Берсерк',
	15 => 'Клирик',
	16 => 'Друид',
	4 => 'Фокусник',
	5 => 'Маг',
	6 => 'Монах',
	7 => 'Некромант',
	8 => 'Паладин',
	9 => 'Рейнджер',
	10 => 'Жулик',
	11 => 'Темный рыцарь',
	12 => 'Шаман',
	13 => 'Воин',
	14 => 'Волшебник',
	),
	"races" => array(
	0 => 'Неизвестно',
	3 => 'Варвар',
	6 => 'Темный эльф',
	16 => 'Эйракины',
	4 => 'Дворф',
	14 => 'Эрудит',
	12 => 'Фроглок',
	1 => 'Гном',
	15 => 'Полурослик',
	8 => 'Полуэльф',
	5 => 'Высший эльф',
	2 => 'Человек',
	13 => 'Иксар',
	11 => 'Огр',
	10 => 'Тролль',
	9 => 'Ва Шир',
	7 => 'Лесной эльф',
	),
	"lang" => array(
	"eq" => 'EverQuest',
	"tank" => 'Танк',
	"melee" => 'Боец ближнего боя',
	"priest" => 'Жрец',
	"caster" => 'Боец дальнего боя',
	"uc_race" => 'Раса',
	"uc_class" => 'Класс',
	"uc_guild" => 'Гильдия',
	"uc_gender" => 'Пол',
	"uc_level" => 'Уровень',
	"uc_male" => 'Мужской',
	"uc_female" => 'Женский',
	"core_sett_fs_gamesettings" => 'Настройки EverQuest',
	"uc_faction" => 'Фракция',
	"uc_faction_help" => 'Выберите фракцию по умолчанию',
	),
	
);

?>