<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2016-06-15 09:50
//File: games/tsw/language/russian.php
//Source-Language: english

$russian_array = array( 
	"classes" => array(
	0 => 'Неизвестно',
	1 => 'Танк',
	2 => 'Лекарь',
	3 => 'Боец',
	4 => 'Ближний бой',
	5 => 'Кровопийца',
	),
	"races" => array(
	0 => 'Неизвестно',
	1 => 'Тамплиеры',
	2 => 'Драконы',
	3 => 'Иллюминаты',
	),
	"roles" => array(
	0 => 'Любая роль',
	1 => 'Fist-healer',
	2 => 'Blood-healer',
	3 => 'Leech/Rifle Heal',
	4 => 'Танк',
	5 => 'Buff-Tank',
	6 => 'Heal-Tank',
	7 => 'Leech-Tank',
	8 => 'DA/BS-Buffs',
	9 => 'Full-DPS',
	10 => 'SF-Buff',
	11 => 'Ближний бой',
	),
	"lang" => array(
	"tsw" => 'The Secret World',
	"uc_race" => 'Фракция',
	"uc_class" => 'предпочитаемый класс',
	"uc_faction" => 'Фракция',
	"uc_cat_misc" => 'разное',
	"uc_pvp" => 'PVP поле боя',
	"uc_pvp_help" => 'Боевая группа привязана к серверу',
	"uc_RP" => 'Роль игрока',
	"uc_RP_help" => '',
	"uc_yes" => 'Да',
	"uc_no" => 'Нет',
	"uc_unknown" => 'неизвестно',
	"uc_ED" => 'Эльдорадо',
	"uc_SH" => 'Стоунхендж',
	"uc_ShB" => 'Шамбала',
	"uc_BG" => 'Боевая группа',
	"uc_BG_A" => 'Fusang BG-A',
	"uc_BG_B" => 'Fusang BG-B',
	"uc_guild" => 'Cabal',
	"uc_level" => 'Effusion rating',
	"uc_testlive" => 'Доступ к Testlive',
	"uc_18h_Raid_cooldown" => '18-часовой рейдовый КД',
	"uc_wings" => 'Цвет крыльев',
	"uc_blue" => 'Синий',
	"uc_gold" => 'Золотой',
	"uc_purple" => 'Фиолетовый',
	"uc_nowings" => 'никто',
	"eidolon" => 'Eidolon',
	"ny_raid" => 'Нью-Йорк',
	"flappy" => 'Flappy',
	"core_sett_fs_gamesettings" => 'Настройки The Secret World',
	"Heroic" => 'Героическое',
	"Epic" => 'Эпическое',
	"Rare" => 'Редкое',
	"Normal" => 'Необычное',
	"Other" => 'Обычное',
	"Augments" => 'Усиленный резонатор',
	"Signets" => 'Символы',
	"Event-Items" => 'Предметы с эвентов',
	"Clothes" => 'Одежда',
	"Emotes" => 'Эмоции',
	"Token-Items" => 'Предметы за токены',
	"Material" => 'Материал',
	"Others" => 'Прочее',
	),
	
);

?>