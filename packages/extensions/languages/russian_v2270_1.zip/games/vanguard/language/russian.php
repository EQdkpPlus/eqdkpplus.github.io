<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2016-06-15 09:50
//File: games/vanguard/language/russian.php
//Source-Language: english

$russian_array = array( 
	"classes" => array(
	0 => 'Неизвестно',
	1 => 'Bard',
	2 => 'Blood Mage',
	3 => 'Cleric',
	4 => 'Disciple',
	5 => 'Dread Knight',
	6 => 'Druid',
	7 => 'Inquisitor',
	8 => 'Monk',
	9 => 'Necromancer',
	10 => 'Paladin',
	11 => 'Psionicist',
	12 => 'Ranger',
	13 => 'Rogue',
	14 => 'Shaman',
	15 => 'Sorcerer',
	16 => 'Warrior',
	),
	"races" => array(
	0 => 'Неизвестно',
	1 => 'Dark Elf',
	2 => 'Dwarf',
	3 => 'Gnome',
	4 => 'Goblin',
	5 => 'Half Elf',
	6 => 'Halfling',
	7 => 'High Elf',
	8 => 'Kojani',
	9 => 'Kurashasa',
	10 => 'Lesser Giant',
	11 => 'Mordebi',
	12 => 'Orc',
	13 => 'Qaliathari',
	14 => 'Raki',
	15 => 'Thestran',
	16 => 'Varanjar',
	17 => 'Varanthari',
	18 => 'Vulmane',
	19 => 'Wood Elf',
	),
	"roles" => array(
	1 => 'Лекарь',
	2 => 'Танк',
	3 => 'Дальний бой',
	4 => 'Ближний бой',
	),
	"lang" => array(
	"vanguard" => 'Vanguard: Saga of Heroes',
	"unknown" => 'Неизвестно',
	"cloth" => 'Ткань',
	"leather" => 'Кожа',
	"chain" => 'Кольчуга',
	"plate" => 'Латы',
	"uc_race" => 'Раса',
	"uc_class" => 'Класс',
	),
	
);

?>