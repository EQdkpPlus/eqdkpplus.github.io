plugin-feedposter
=================
[![Build Status](https://travis-ci.org/EQdkpPlus/plugin-feedposter.svg)](https://travis-ci.org/EQdkpPlus/plugin-feedposter)
