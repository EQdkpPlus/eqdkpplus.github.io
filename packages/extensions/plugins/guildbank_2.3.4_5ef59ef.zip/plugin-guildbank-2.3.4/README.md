plugin-guildbank
===================
[![Build Status](https://travis-ci.org/EQdkpPlus/plugin-guildbank.svg)](https://travis-ci.org/EQdkpPlus/plugin-guildbank)

Manage your guild bank, create an itemshop or auctions, and much more...
