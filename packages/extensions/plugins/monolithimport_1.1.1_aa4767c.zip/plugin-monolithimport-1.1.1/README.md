plugin-monolithimport
=================
[![Build Status](https://travis-ci.org/EQdkpPlus/plugin-monolithimport.svg)](https://travis-ci.org/EQdkpPlus/plugin-monolithimport)
