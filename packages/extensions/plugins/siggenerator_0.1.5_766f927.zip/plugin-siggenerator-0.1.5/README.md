plugin-siggenerator
===================
[![Build Status](https://travis-ci.org/EQdkpPlus/plugin-siggenerator.svg)](https://travis-ci.org/EQdkpPlus/plugin-siggenerator)
