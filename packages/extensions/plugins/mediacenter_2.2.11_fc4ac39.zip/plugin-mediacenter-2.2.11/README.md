plugin-mediacenter
==================
[![Build Status](https://travis-ci.org/EQdkpPlus/plugin-mediacenter.svg)](https://travis-ci.org/EQdkpPlus/plugin-mediacenter)
