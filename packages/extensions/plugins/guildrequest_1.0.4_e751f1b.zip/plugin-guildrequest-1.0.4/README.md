plugin-guildrequest
===================
[![Build Status](https://travis-ci.org/EQdkpPlus/plugin-guildrequest.svg)](https://travis-ci.org/EQdkpPlus/plugin-guildrequest)
