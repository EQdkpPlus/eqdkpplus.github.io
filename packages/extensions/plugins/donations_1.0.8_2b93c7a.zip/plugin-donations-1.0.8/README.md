EQdkp Plus Donation Plugin
==========================
[![Build Status](https://travis-ci.org/EQdkpPlus/plugin-donations.svg?branch=master)](https://travis-ci.org/EQdkpPlus/plugin-donations)
