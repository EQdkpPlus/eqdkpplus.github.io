plugin-statistics
===============
[![Build Status](https://travis-ci.org/EQdkpPlus/plugin-statistics.svg)](https://travis-ci.org/EQdkpPlus/plugin-statistics)
