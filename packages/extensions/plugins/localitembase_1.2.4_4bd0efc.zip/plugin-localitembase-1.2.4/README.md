plugin-localitembase
================
[![Build Status](https://travis-ci.org/EQdkpPlus/plugin-localitembase.svg)](https://travis-ci.org/EQdkpPlus/plugin-localitembase)
