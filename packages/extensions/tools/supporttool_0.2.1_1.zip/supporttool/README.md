tool-supporttoolkit
===================
The EQdkp Plus Supporttoolkit (STK) helps you to maintain your EQdkp Plus.

## Installation
* Download the STK
* Create a folder named `supporttool` in the root-directory of your EQdkp Plus Installation.
* Copy the files from the STK into this folder
* Navigate in your Browser to the supporttool folder.

## Included Tasks
* Moving (neccessary tasks when moving from one Host to another)
* Rename Configtable
* Repair Tables

## License
The EQdkp Plus Supportoolkit is licensed under AGPL v3.0.
